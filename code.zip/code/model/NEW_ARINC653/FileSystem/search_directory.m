function [ FILE_ID ] = search_directory(DIR_ID,FILE_NAME)
    global Directory_Set;
    global DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS;
    index = -1;
    for i = 3:2+DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS
        if Directory_Set{DIR_ID,i} == FILE_NAME
            index = i;
            break;
        end
    end
    FILE_ID = Directory_Set{DIR_ID,index + DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS};
    Directory_Set{DIR_ID,index} = "";
    Directory_Set{DIR_ID,index + DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS} = -1;
    return;
end