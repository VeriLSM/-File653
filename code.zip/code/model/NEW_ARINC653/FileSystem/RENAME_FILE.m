function  [RETURN_CODE,ERRNO] = RENAME_FILE(OLD_FILE_NAME,NEW_FILE_NAME,ERRNO)
    global RETURN_CODE_TYPE;
    global ERRNO_ERROR_TYPE;
    global CURRENT_PARTITION;
    global CurrentProcess;
    global ERROR_HANDLER_PROCESS_ID;
    global File_Set;
    global Directory_Set;
    
    %APEX_INTEGER Old_File_length_Flag;
    Old_File_length_Flag = Invalid_File_Length(OLD_FILE_NAME);
    if Old_File_length_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.ENAMETOOLONG;
        return;  
    end
    
    %APEX_INTEGER Old_File_Syntax_Flag;
    Old_File_Syntax_Flag = Invalid_File_Syntax(OLD_FILE_NAME);
    if  Old_File_Syntax_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EINVAL;
        return;  
    end
    
    %APEX_INTEGER Old_File_Path_Prefix_Flag;
    Old_File_Path_Prefix_Flag = Invalid_File_Path_Prefix(OLD_FILE_NAME);
    if Old_File_Path_Prefix_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.ENOTDIR;
        return;  
    end
    
    %APEX_INTEGER New_File_length_Flag;
    New_File_length_Flag = Invalid_File_Length(NEW_FILE_NAME);
    if New_File_length_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.ENAMETOOLONG;
        return;  
    end
    
    %APEX_INTEGER New_File_Syntax_Flag;
    New_File_Syntax_Flag = Invalid_File_Syntax(NEW_FILE_NAME);
    if New_File_Syntax_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EINVAL;
        return;  
    end
    
    %APEX_INTEGER New_File_Path_Prefix_Flag;
    New_File_Path_Prefix_Flag = Invalid_File_Path_Prefix(NEW_FILE_NAME);
    if New_File_Path_Prefix_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.ENOTDIR;
        return;  
    end
    
    %APEX_INTEGER Partition_Access_Rights_Flag;
    Partition_Access_Rights_Flag = Invalid_Partition_Read_Write_Access_Rights(OLD_FILE_NAME);
    if Partition_Access_Rights_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;  
    end
    
    %APEX_INTEGER File_Name_Operation_Flag;
    File_Name_Operation_Flag = Invalid_File_Name_has_Operation(OLD_FILE_NAME);
    if File_Name_Operation_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EBUSY;
        return;  
    end
    
    %APEX_INTEGER Device_Protected_Flag;
    Device_Protected_Flag = Invalid_Device_Is_Write_Protected();
    if Device_Protected_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EROFS;
        return;  
    end
    
    %APEX_INTEGER File_Name_Identical_Flag;
    File_Name_Identical_Flag = Invalid_OLD_New_File_Name_Volume_Identical(OLD_FILE_NAME,NEW_FILE_NAME);
    if File_Name_Identical_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EINVAL;
        return;  
    end
    
    %APEX_INTEGER Create_File_in_New_Directory_Flag;
    Create_File_in_New_Directory_Flag = Invalid_Create_File_in_New_Directory(NEW_FILE_NAME);
    if Create_File_in_New_Directory_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        ERRNO = ERRNO_ERROR_TYPE.ENOSPC;
        return;  
    end
    
    %APEX_INTEGER Old_Existing_Directory_Flag;
    Old_Existing_Directory_Flag = Invalid_Existing_Directory(OLD_FILE_NAME);
    if Old_Existing_Directory_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EPERM;
        return;  
    end
    
    %APEX_INTEGER New_Existing_Directory_Flag;
    New_Existing_Directory_Flag = Invalid_Existing_Directory(NEW_FILE_NAME);
    if  New_Existing_Directory_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EISDIR;
        return;  
    end
    
    %APEX_INTEGER Old_Existing_File_Flag;
    Old_Existing_File_Flag = Invalid_Existing_File(OLD_FILE_NAME);
    if Old_Existing_File_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.ENOENT;
        return;  
    end
    
    %APEX_INTEGER New_Existing_File_Flag;
    New_Existing_File_Flag = Invalid_Existing_File(NEW_FILE_NAME);
    if New_Existing_File_Flag == 1 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EEXIST;
        return;  
    end
    
    %APEX_INTEGER Old_File_Name_Open_Flag;
    Old_File_Name_Open_Flag = Invalid_File_Name_is_Open(OLD_FILE_NAME);
    if  Old_File_Name_Open_Flag > 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EBUSY;
        return;  
    end
    
    %APEX_INTEGER Old_Storage_Device_Contain_File_Name_Flag;
    Old_Storage_Device_Contain_File_Name_Flag = Invalid_Storage_Device_Contain_File_Name(OLD_FILE_NAME);
    if Old_Storage_Device_Contain_File_Name_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EIO;
        return;  
    end
    
    %APEX_INTEGER New_Storage_Device_Contain_File_Name_Flag;
    New_Storage_Device_Contain_File_Name_Flag = Invalid_Storage_Device_Contain_File_Name(NEW_FILE_NAME);
    if New_Storage_Device_Contain_File_Name_Flag == 0
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EIO;
        return;  
    end

    if CURRENT_PARTITION.LOCK_LEVEL > 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end

    if CurrentProcess == ERROR_HANDLER_PROCESS_ID
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    if Old_File_length_Flag~= 0 && Old_File_Syntax_Flag~=0 && Old_File_Path_Prefix_Flag~=0 && New_File_length_Flag~=0 && New_File_Syntax_Flag~=0 && New_File_Path_Prefix_Flag~=0 && Partition_Access_Rights_Flag~=0 && File_Name_Operation_Flag~=0 && Device_Protected_Flag~=0 && File_Name_Identical_Flag~=0 && Create_File_in_New_Directory_Flag~=0 && Old_Existing_Directory_Flag~=0 && New_Existing_Directory_Flag~=0 && Old_Existing_File_Flag~=0 && New_Existing_File_Flag~=1 && Old_File_Name_Open_Flag<=0 && Old_Storage_Device_Contain_File_Name_Flag~=0 && New_Storage_Device_Contain_File_Name_Flag~=0 && CURRENT_PARTITION.LOCK_LEVEL==0 && CurrentProcess ~= ERROR_HANDLER_PROCESS_ID
        % APEX_BYTE old_path_prefix[MAX_FILE_NAME_LENGTH];
        old_path_prefix = get_file_prefix(OLD_FILE_NAME);

        % APEX_BYTE new_path_prefix[MAX_FILE_NAME_LENGTH];
        new_path_prefix = get_file_prefix(NEW_FILE_NAME);

        % APEX_INTEGER OLD_DIR_ID,NEW_DIR_ID,FILE_ID;
        Directory_Name_Set = [Directory_Set{:,1}];
        [~,OLD_DIR_ID] = ismember(old_path_prefix,Directory_Name_Set);
        [~,NEW_DIR_ID] = ismember(new_path_prefix,Directory_Name_Set);

        FILE_ID = search_directory(OLD_DIR_ID,OLD_FILE_NAME);

        write_directory(NEW_DIR_ID,NEW_FILE_NAME,FILE_ID);

        File_Set{FILE_ID,1} = NEW_FILE_NAME;

        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        ERRNO = ERRNO_ERROR_TYPE.EUNCHANGE;
        return;  
    end
end