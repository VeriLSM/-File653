function  [RETURN_CODE,ERRNO] = SYNC_FILE(FILE_ID,ERRNO)
    global RETURN_CODE_TYPE;
    global ERRNO_ERROR_TYPE;
    global CurrentProcess;
    global ERROR_HANDLER_PROCESS_ID;
    global CURRENT_PARTITION;
    
    %APEX_INTEGER File_Id_In_Current_Partition_Flag;
    File_Id_In_Current_Partition_Flag = Invalid_File_Id_In_Current_Partition(FILE_ID);
    if File_Id_In_Current_Partition_Flag == 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EBADF;
        return;
    end
    
    %APEX_INTEGER File_Id_has_Operation_Flag;
    File_Id_has_Operation_Flag = Invalid_File_Id_has_Operation(FILE_ID);
    if File_Id_has_Operation_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EBUSY;
        return;
    end
    
    %APEX_INTEGER File_Id_has_Read_Write_Access_Mode_Flag;
    File_Id_has_Read_Write_Access_Mode_Flag = Invalid_File_Id_has_Read_Write_Access_Mode(FILE_ID);
    if  File_Id_has_Read_Write_Access_Mode_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    %APEX_INTEGER Storage_Device_Contain_File_Id_Flag;
    Storage_Device_Contain_File_Id_Flag = Invalid_Storage_Device_Contain_File_Id(FILE_ID);
    if Storage_Device_Contain_File_Id_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EIO;
        return;
    end

    if CURRENT_PARTITION.LOCK_LEVEL > 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    if CurrentProcess == ERROR_HANDLER_PROCESS_ID
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    if File_Id_In_Current_Partition_Flag~=0 && File_Id_has_Operation_Flag~=0 && File_Id_has_Read_Write_Access_Mode_Flag~=0 &&Storage_Device_Contain_File_Id_Flag~=0 && CURRENT_PARTITION.LOCK_LEVEL==0 && CurrentProcess ~= ERROR_HANDLER_PROCESS_ID 
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        ERRNO = ERRNO_ERROR_TYPE.EUNCHANGE;
        return;
    end
 
end