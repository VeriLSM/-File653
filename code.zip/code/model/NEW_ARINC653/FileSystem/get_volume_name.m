function [ path_prefix ] = get_volume_name(FILE_NAME)
    path = split(FILE_NAME,"\");
    path_length = length(path);
    path_prefix = path{1};
    return;
end