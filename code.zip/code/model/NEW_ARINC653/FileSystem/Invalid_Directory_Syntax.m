function [ index ] = Invalid_Directory_Syntax( DIRECTORY_NAME )

    % APEX_BYTE name[MAX_FILE_NAME_LENGTH];
    % APEX_INTEGER len,pos1,pos2,index;
    % APEX_BYTE* pattern;
    name = get_file_name(DIRECTORY_NAME);

    len = strlength(name);
    pattern = '[a-zA-Z_0-9][a-zA-Z0-9_-.]*';
    [pos1,pos2,~] = regexpi(name,pattern,'start','end','match');
    if pos1==1 && pos2==len
        index = 1;
    else
        index = 0;
    end

    return;

end