global SYSTEM_LIMIT_FILE_SIZE;
SYSTEM_LIMIT_FILE_SIZE = 512;

global MAX_FILE_SIZE;
MAX_FILE_SIZE = SYSTEM_LIMIT_FILE_SIZE;

global MAX_FILE_NAME_LENGTH;
MAX_FILE_NAME_LENGTH = 60;

global MAX_DIRECTORY_ENTRY_LENGTH;
MAX_DIRECTORY_ENTRY_LENGTH = 64;

global FILE_MODE_TYPE;
FILE_MODE_TYPE.READ = 0;
FILE_MODE_TYPE.READ_WRITE = 1;

global FILE_SEEK_TYPE;
FILE_SEEK_TYPE.SEEK_SET_TYPE = 0;
FILE_SEEK_TYPE.SEEK_CUR_TYPE = 1;
FILE_SEEK_TYPE.SEEK_END_TYPE = 2;

global ENTRY_KIND_TYPE;
ENTRY_KIND_TYPE.FILE_ENTRY = 0;
ENTRY_KIND_TYPE.DIRECTORY_ENTRY = 1;
ENTRY_KIND_TYPE.OTHER_ENTRY = 2;
ENTRY_KIND_TYPE.END_OF_DIRECTORY = 3;

global TIME_SET_TYPE;
TIME_SET_TYPE.UNSET = 0;
TIME_SET_TYPE.SET = 1;

global MEDIA_TYPE;
MEDIA_TYPE.VOLATILE = 0;
MEDIA_TYPE.NONVOLATILE = 1;
MEDIA_TYPE.REMOTE = 2;

global ERRNO_ERROR_TYPE;
ERRNO_ERROR_TYPE.EUNCHANGE = 0;
ERRNO_ERROR_TYPE.EPERM = 1;
ERRNO_ERROR_TYPE.ENOENT = 2;
ERRNO_ERROR_TYPE.EIO = 5;
ERRNO_ERROR_TYPE.EBADF = 9;
ERRNO_ERROR_TYPE.EACCES = 13;
ERRNO_ERROR_TYPE.EBUSY = 16;
ERRNO_ERROR_TYPE.EEXIST = 17;
ERRNO_ERROR_TYPE.ENOTDIR = 20;
ERRNO_ERROR_TYPE.EISDIR = 21;
ERRNO_ERROR_TYPE.EINVAL = 22;
ERRNO_ERROR_TYPE.EMFILE = 24;
ERRNO_ERROR_TYPE.EFBIG = 27;
ERRNO_ERROR_TYPE.ENOSPC = 28;
ERRNO_ERROR_TYPE.EROFS = 30;
ERRNO_ERROR_TYPE.ENAMETOOLONG = 78;
ERRNO_ERROR_TYPE.EOVERFLOW = 79;
ERRNO_ERROR_TYPE.ENOTEMPTY = 93;
ERRNO_ERROR_TYPE.ESTALE = 151;

%�Լ�����
global PARTION_LIMIT_OPEN_FILE_NUMBERS;
PARTION_LIMIT_OPEN_FILE_NUMBERS = SYSTEM_LIMIT_FILE_SIZE; %�ܴ򿪵��ļ�������������ļ�����

global PARTION_OPEN_FILES_NUMBERS;
PARTION_OPEN_FILES_NUMBERS = 0; %�Ѿ��򿪵��ļ�����

global PARTION_EXIT_FILES_NUMBERS;
PARTION_EXIT_FILES_NUMBERS = 0; %�Ѿ��������ļ�����

global DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS;
DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS = 8; % ÿ��Ŀ¼��������Ŀ¼���ļ�����Ϊ10

global MAX_DIRECTORY_NUMBER;
MAX_DIRECTORY_NUMBER = SYSTEM_LIMIT_FILE_SIZE;

global Directory_Set;
Directory_Set = cell(MAX_DIRECTORY_NUMBER,DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS * 2+2);

global Open_File_Set;
Open_File_Set = zeros(1,SYSTEM_LIMIT_FILE_SIZE);

global File_Set;
File_Set = cell(MAX_DIRECTORY_NUMBER,12);

for i = 1:MAX_DIRECTORY_NUMBER
    for j = 2:12
        File_Set{i,j} = -1;
    end
    File_Set{i,1} = "";
    File_Set{i,7} = "";
end

for i = 1:MAX_DIRECTORY_NUMBER
    Directory_Set{i,1} = "";
    Directory_Set{i,2} = -1;
    for j = 3:DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS +2
        Directory_Set{i,j} = "";
    end
    for k = DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS +3:DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS*2 +2
        Directory_Set{i,k} = -1;
    end
end

global MAX_CONFIGUATION_TABLE_NUMBER;
MAX_CONFIGUATION_TABLE_NUMBER = 100;

global File_System_Configuation_Table;
File_System_Configuation_Table = cell(MAX_CONFIGUATION_TABLE_NUMBER,8);

global MAX_ATOMIC_SIZE;
MAX_ATOMIC_SIZE = 5120;

for i = 1:MAX_CONFIGUATION_TABLE_NUMBER
    File_System_Configuation_Table{i,1} = "";
end

File_System_Configuation_Table{1,1} = "C:";
File_System_Configuation_Table{1,2} = 'PAR1';
File_System_Configuation_Table{1,3} = 2621400;
File_System_Configuation_Table{1,4} = 2621400;
File_System_Configuation_Table{1,5} = 512;
File_System_Configuation_Table{1,6} = 128;
File_System_Configuation_Table{1,7} = 512;
File_System_Configuation_Table{1,8} = 512;

Directory_Set{1,1} = "C:";
Directory_Set{1,2} = 1;
Directory_Set{1,3} = "C:\path";
Directory_Set{1,3+DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS} = 2;
Directory_Set{1,4} = "C:\path2";
Directory_Set{1,4+DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS} = 3;
Directory_Set{2,1} = "C:\path";
Directory_Set{2,2} = 2;
Directory_Set{3,1} = "C:\path2";
Directory_Set{3,2} = 3;

Open_File_Set(1) = 1;
Open_File_Set(2) = 1;
Open_File_Set(3) = 1;

File_Set{1,1} = "C:";
File_Set{1,2} = 1;
File_Set{1,3} = 0;
File_Set{1,4} = 0;
File_Set{1,5} = 0;
File_Set{1,6} = 0;
File_Set{1,7} = "";
File_Set{1,8} = 1;
File_Set{1,9} = FILE_MODE_TYPE.READ_WRITE;
File_Set{1,10} = ENTRY_KIND_TYPE.DIRECTORY_ENTRY;
File_Set{1,11} = 2;
File_Set{1,12} = 1;
File_Set{2,1} = "C:\path";
File_Set{2,2} = 2;
File_Set{2,3} = 0;
File_Set{2,4} = 0;
File_Set{2,5} = 0;
File_Set{2,6} = 0;
File_Set{2,7} = "";
File_Set{2,8} = 1;
File_Set{2,9} = FILE_MODE_TYPE.READ_WRITE;
File_Set{2,10} = ENTRY_KIND_TYPE.DIRECTORY_ENTRY;
File_Set{2,11} = 0;
File_Set{2,12} = 2;
File_Set{3,1} = "C:\path2";
File_Set{3,2} = 3;
File_Set{3,3} = 0;
File_Set{3,4} = 0;
File_Set{3,5} = 0;
File_Set{3,6} = 0;
File_Set{3,7} = "";
File_Set{3,8} = 1;
File_Set{3,9} = FILE_MODE_TYPE.READ_WRITE;
File_Set{3,10} = ENTRY_KIND_TYPE.DIRECTORY_ENTRY;
File_Set{3,11} = 0;
File_Set{3,12} = 3;

PARTION_EXIT_FILES_NUMBERS = 3;
PARTION_OPEN_FILES_NUMBERS = 3;

global CURRENT_DIRECTORY;
CURRENT_DIRECTORY = "C:";
global CURRENT_DIRECTORY_ID;
CURRENT_DIRECTORY_ID = 1;
global ROOT_DIRECTORY;
ROOT_DIRECTORY = "C:";
global ROOT_DIRECTORY_ID;
ROOT_DIRECTORY_ID = 1;



