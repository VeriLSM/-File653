function [ index ] = Invalid_OLD_New_File_Name_Volume_Identical( OLD_FILE_NAME,NEW_FILE_NAME )


    old_path = split(OLD_FILE_NAME,"\");
    old_volume = old_path{1};
    new_path = split(NEW_FILE_NAME,"\");
    new_volume = new_path{1};

    if old_volume == new_volume
        index = 1;
    else
        index = 0;
    end

    return;

end

