function  [DIRECTORY_ID,RETURN_CODE,ERRNO] = OPEN_DIRECTORY(DIRECTORY_NAME,ERRNO)
    global RETURN_CODE_TYPE;
    global ERRNO_ERROR_TYPE;
    global CURRENT_PARTITION;
    global FILE_MODE_TYPE;
    global File_Set;
    global CurrentProcess;
    global ERROR_HANDLER_PROCESS_ID;
    global CurrentDirectory;
    global Open_File_Set;
    global PARTION_OPEN_FILES_NUMBERS;
    
    %APEX_INTEGER Directory_index;
    Directory_index = CapacityofDirectory();
    if Directory_index ==0
        DIRECTORY_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        ERRNO = ERRNO_ERROR_TYPE.EMFILE;
        return;
    end
    
    %APEX_INTEGER Directory_length_Flag;
    Directory_length_Flag = Invalid_Directory_Length(DIRECTORY_NAME);
    if Directory_length_Flag == 0
        DIRECTORY_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.ENAMETOOLONG;
        return;
    end
    
    %APEX_INTEGER Directory_Syntax_Flag;
    Directory_Syntax_Flag = Invalid_Directory_Syntax(DIRECTORY_NAME);
    if Directory_Syntax_Flag == 0
        DIRECTORY_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EINVAL;
        return;
    end
    
    %APEX_INTEGER File_Path_Prefix_Flag;
    File_Path_Prefix_Flag = Invalid_File_Path_Prefix(DIRECTORY_NAME);
    if File_Path_Prefix_Flag == 0 
        DIRECTORY_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.ENOTDIR;
        return;
    end
    
    %APEX_INTEGER Existing_File_Flag;
    Existing_File_Flag = Invalid_Existing_File(DIRECTORY_NAME);
    if  Existing_File_Flag ~= 0
        DIRECTORY_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EEXIST;
        return;
    end
    
    %APEX_INTEGER Existing_Directory_Flag;
    Existing_Directory_Flag = Invalid_Existing_Directory(DIRECTORY_NAME);
    if Existing_Directory_Flag == 1 
        DIRECTORY_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EISDIR;
        return;
    end
    
    %APEX_INTEGER Partition_Access_Rights_Flag;
    Partition_Access_Rights_Flag = Invalid_Partition_Access_Rights(FILE_MODE_TYPE.READ_WRITE,DIRECTORY_NAME);
    if Partition_Access_Rights_Flag == 0 
        DIRECTORY_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    %APEX_INTEGER Storage_Device_Contain_File_Name_Flag;
    Storage_Device_Contain_File_Name_Flag = Invalid_Storage_Device_Contain_File_Name(DIRECTORY_NAME);
    if Storage_Device_Contain_File_Name_Flag == 0 
        DIRECTORY_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EIO;
        return;
    end
    
    if CURRENT_PARTITION.LOCK_LEVEL > 0
        DIRECTORY_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    if CurrentProcess == ERROR_HANDLER_PROCESS_ID
        DIRECTORY_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    if Directory_index~=0 && Directory_length_Flag~=0 && Directory_Syntax_Flag~=0 && File_Path_Prefix_Flag~=0 && Existing_File_Flag==0 && Existing_Directory_Flag~=1 && Partition_Access_Rights_Flag~=0 && Storage_Device_Contain_File_Name_Flag~=0 && CURRENT_PARTITION.LOCK_LEVEL==0 && CurrentProcess ~= ERROR_HANDLER_PROCESS_ID
        
        %APEX_INTEGER DIR_ID;
        Directory_Name_Set = [File_Set{:,1}];
        [~,DIR_ID] = ismember(DIRECTORY_NAME,Directory_Name_Set);
        DIRECTORY_ID = DIR_ID;

        %APEX_INTEGER tag;
        tag = Open_File_Set(DIR_ID);
        if tag == 0
            File_Set{DIR_ID,5} = 0;
            File_Set{DIR_ID,6} = 0;
        end
        Open_File_Set(DIR_ID) = 1;
        File_Set{DIR_ID,3} = 0;
        PARTION_OPEN_FILES_NUMBERS = PARTION_OPEN_FILES_NUMBERS + 1;
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        ERRNO = ERRNO_ERROR_TYPE.EUNCHANGE;
        return;
    end
    
end