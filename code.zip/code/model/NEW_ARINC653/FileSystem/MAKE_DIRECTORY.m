function  [RETURN_CODE,ERRNO] = MAKE_DIRECTORY(DIRECTORY_NAME,ERRNO)
    global RETURN_CODE_TYPE;
    global ERRNO_ERROR_TYPE;
    global CURRENT_PARTITION;
    global CurrentProcess;
    global ERROR_HANDLER_PROCESS_ID;
    global Directory_Set;
    global File_Set;
    global PARTION_EXIT_FILES_NUMBERS;
    global File_System_Configuation_Table;
    global FILE_MODE_TYPE;
    global ENTRY_KIND_TYPE;
    global MAX_ATOMIC_SIZE;
    
    %APEX_INTEGER Directory_length_Flag;
    Directory_length_Flag = Invalid_Directory_Length(DIRECTORY_NAME);
    if Directory_length_Flag == 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.ENAMETOOLONG;
        return;
    end
    
    %APEX_INTEGER Directory_Syntax_Flag;
    Directory_Syntax_Flag = Invalid_Directory_Syntax(DIRECTORY_NAME);
    if Directory_Syntax_Flag == 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EINVAL;
        return;
    end
    
    %APEX_INTEGER File_Path_Prefix_Flag;
    File_Path_Prefix_Flag = Invalid_File_Path_Prefix(DIRECTORY_NAME);
    if  File_Path_Prefix_Flag== 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.ENOTDIR;
        return;
    end
    
    %APEX_INTEGER Partition_Read_Write_Access_Rights_Flag;
    Partition_Read_Write_Access_Rights_Flag = Invalid_Partition_Read_Write_Access_Rights(DIRECTORY_NAME);
    if  Partition_Read_Write_Access_Rights_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    %APEX_INTEGER Device_Is_Write_Protected_Flag;
    Device_Is_Write_Protected_Flag = Invalid_Device_Is_Write_Protected();
    if Device_Is_Write_Protected_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EROFS;
        return;
    end
    
    %APEX_INTEGER Existing_Directory_Flag;
    Existing_Directory_Flag = Invalid_Existing_Directory(DIRECTORY_NAME);
    if Existing_Directory_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EISDIR;
        return;
    end
    
    %APEX_INTEGER Existing_File_Flag;
    Existing_File_Flag = Invalid_Existing_File(DIRECTORY_NAME);
    if Existing_File_Flag ~= 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EEXIST;
        return;
    end

    %APEX_INTEGER Volume_Space_Available_Flag;
    Volume_Space_Available_Flag = Invalid_Volume_Space_Available(DIRECTORY_NAME);
    if Volume_Space_Available_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        ERRNO = ERRNO_ERROR_TYPE.ENOSPC;
        return;
    end
    
    %APEX_INTEGER Volume_Storage_Device_Contain_Directory_Flag;
    Volume_Storage_Device_Contain_Directory_Flag = Invalid_Storage_Device_Contain_Directory(DIRECTORY_NAME);
    if Volume_Storage_Device_Contain_Directory_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EIO;
        return;
    end
    
    if CURRENT_PARTITION.LOCK_LEVEL > 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    if CurrentProcess == ERROR_HANDLER_PROCESS_ID
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    if Directory_length_Flag~=0 && Directory_Syntax_Flag~=0 && File_Path_Prefix_Flag~=0 && Partition_Read_Write_Access_Rights_Flag~=0 && Device_Is_Write_Protected_Flag~=0 && Existing_Directory_Flag~=0 && Existing_File_Flag==0 && Volume_Space_Available_Flag~=0 && Volume_Storage_Device_Contain_Directory_Flag~=0 && CURRENT_PARTITION.LOCK_LEVEL==0 && CurrentProcess ~= ERROR_HANDLER_PROCESS_ID 
        % APEX_INTEGER DirectoryId;
        DirectoryId = CapacityofFile();
        % APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];
        path_prefix = get_file_prefix(DIRECTORY_NAME);

        % APEX_INTEGER DIR_ID;
        Directory_Name_Set = [Directory_Set{:,1}];
        [~,DIR_ID] = ismember(path_prefix,Directory_Name_Set);
        write_directory(DIR_ID,DIRECTORY_NAME,DirectoryId);

        File_Set{DIR_ID,11} = File_Set{DIR_ID,11} + 1;

        Directory_Set{DirectoryId,1} = DIRECTORY_NAME;
        Directory_Set{DirectoryId,2} = DirectoryId;
        % APEX_INTEGER ID;
        ID = DirectoryId;
        File_Set{DirectoryId,1} = DIRECTORY_NAME;
        File_Set{DirectoryId,2} = DirectoryId;
        File_Set{DirectoryId,3} = 0;
        File_Set{DirectoryId,4} = 0;
        File_Set{DirectoryId,5} = 0;
        File_Set{DirectoryId,6} = 0;
        File_Set{DirectoryId,7} = "";
        File_Set{DirectoryId,8} = 1;
        File_Set{DirectoryId,9} = FILE_MODE_TYPE.READ_WRITE;
        File_Set{DirectoryId,10} = ENTRY_KIND_TYPE.DIRECTORY_ENTRY;
        File_Set{DirectoryId,11} = 0;
        File_Set{DirectoryId,12} = DirectoryId;


        PARTION_EXIT_FILES_NUMBERS = PARTION_EXIT_FILES_NUMBERS + 1;
        File_System_Configuation_Table{1,4} = File_System_Configuation_Table{1,4} - MAX_ATOMIC_SIZE;
        File_System_Configuation_Table{1,8} = File_System_Configuation_Table{1,8} - 1;
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        ERRNO = ERRNO_ERROR_TYPE.EUNCHANGE;
        return;
    end
        
end