function [ RETURN_CODE  ] = PERIODIC_WAIT()

        global RETURN_CODE_TYPE;
        global CURRENT_PARTITION;
        global CurrentProcess;
        global ERROR_HANDLER_PROCESS_ID;
        global Process_Set;
        global INFINITE_TIME_VALUE;
        global Process_Waiting_Resource_Set;
        global PROCESS_STATE_TYPE;
        global WAITING_RESOURCE_TYPE;
        
    if CURRENT_PARTITION.LOCK_LEVEL ~= 0 || CurrentProcess == ERROR_HANDLER_PROCESS_ID
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        return;
    end

    %APEX_INTEGER Curindex;
    Curindex = GetProcessIndex(CurrentProcess);
    %SYSTEM_TIME_TYPE CurPeriod;
    %SYSTEM_TIME_TYPE DeadLineTime;
    CurPeriod = Process_Set{Curindex,6};
    DeadLineTime = Process_Set{Curindex,15} + CurPeriod + Process_Set{Curindex,7};
    if CurPeriod == INFINITE_TIME_VALUE
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        return;
    end
    if Invalid_DeadLineTime(DeadLineTime) == 1
 		RETURN_CODE =RETURN_CODE_TYPE.INVALID_CONFIG;
 		return;
    end
    Process_Set{Curindex,10} = DeadLineTime;
    Process_Set{Curindex,15} = CurPeriod + Process_Set{Curindex,15};
    Process_Set{Curindex,11} = PROCESS_STATE_TYPE.WAITING;
    Process_Waiting_Resource_Set=union(Process_Waiting_Resource_Set,CurrentProcess);
    Process_Set{Curindex,13} = WAITING_RESOURCE_TYPE.PERIOD_WAITING;
    schedule();
    
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
end




