function [ RETURN_CODE ] = REPLENISH( BUDGET_TIME )

        global RETURN_CODE_TYPE;
        global CURRENT_PARTITION;
        global ERROR_HANDLER_PROCESS_ID;
        global PROCESS_STATE_TYPE;
        global CurrentProcess;
        global OPERATING_MODE_TYPE;
        global INFINITE_TIME_VALUE;
        global Process_Set;
        
  		if CurrentProcess == ERROR_HANDLER_PROCESS_ID || CURRENT_PARTITION.OPERATING_MODE ~= OPERATING_MODE_TYPE.NORMAL		
   			RETURN_CODE = PROCESS_STATE_TYPE.NO_ACTION;
   			return;
        end

        %APEX_INTEGER Curindex;
        Curindex = GetProcessIndex(CurrentProcess);
        %SYSTEM_TIME_TYPE CurPeriod;
        %SYSTEM_TIME_TYPE DeadLineTime;
        CurPeriod = Process_Set{Curindex,6};
        DeadLineTime = GetTick() + BUDGET_TIME;
 		if CurPeriod ~= INFINITE_TIME_VALUE && DeadLineTime > Process_Set{Curindex,15}  		
   			RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
   			return;
        end

 		if BUDGET_TIME > GetTick() + 100
  			RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
  			return;
        end

        Process_Set{Curindex,10} = DeadLineTime;

 		RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
 		return;
end

