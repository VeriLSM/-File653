function [ RETURN_CODE ] = TIMED_WAIT( DELAY_TIME )

        global RETURN_CODE_TYPE;
        global CURRENT_PARTITION;
        global CurrentProcess;
        global ERROR_HANDLER_PROCESS_ID;
        global INFINITE_TIME_VALUE;
        global Process_Waiting_Resource_Set;
        global PROCESS_STATE_TYPE;
        global WAITING_RESOURCE_TYPE;
        
		if  CURRENT_PARTITION.LOCK_LEVEL ~= 0 || CurrentProcess == ERROR_HANDLER_PROCESS_ID  			
   			RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
   			return;
        end
        

 		if Invalid_Delay_Time(DELAY_TIME) == 1 		
   			RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
   			return;
        end
      
 		if DELAY_TIME == INFINITE_TIME_VALUE  			
   			RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
   			return;
        end
        
        
 		if DELAY_TIME == 0
            schedule();
        else
            %APEX_INTEGER Curindex;
            Curindex = GetProcessIndex(CurrentProcess);
            Process_Set{Curindex,11} = PROCESS_STATE_TYPE.WAITING;
            Process_Waiting_Resource_Set=union(Process_Waiting_Resource_Set,CurrentProcess);
            Process_Set{Curindex,13} = WAITING_RESOURCE_TYPE.DELAY_WAITING;
            Process_Set{Curindex,14} = GetTick() + DELAY_TIME;
            schedule();
   			RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        end
		


end

