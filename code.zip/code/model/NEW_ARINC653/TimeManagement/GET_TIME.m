function [SYSTEM_TIME,RETURN_CODE] = GET_TIME()

    global RETURN_CODE_TYPE;

    SYSTEM_TIME = GetTick();
    RETURN_CODE =RETURN_CODE_TYPE.NO_ERROR; 
    return;
end