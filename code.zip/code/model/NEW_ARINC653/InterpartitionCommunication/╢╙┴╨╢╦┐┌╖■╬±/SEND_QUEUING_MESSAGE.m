function [ RETURN_CODE ] = SEND_QUEUING_MESSAGE( QUEUING_PORT_ID,MESSAGE_ADDR,LENGTH,TIME_OUT )

    global RETURN_CODE_TYPE;
    global PROCESS_STATE_TYPE;
    global Queuing_Set;
    global CURRENT_PARTITION;
    global CurrentProcess;
    global ERROR_HANDLER_PROCESS_ID;
    global INFINITE_TIME_VALUE;
    global PORT_DIRECTION_TYPE;
    global Process_Set;
    global Process_Waiting_Resource_Set;
    global WAITING_RESOURCE_TYPE;
    global Ready_Processes_Set;



    if isQueuingID(QUEUING_PORT_ID) == 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end


    if Invalid_Time_Out(TIME_OUT) == 1
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return; 
    end

    %APEX_INTEGER QueIndex;
    QueIndex = GetQueIndexById(QUEUING_PORT_ID);
    if LENGTH > Queuing_Set{QueIndex,4}
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return; 
    end

    if LENGTH <= 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return; 
    end

    if Queuing_Set{QueIndex,6} ~= PORT_DIRECTION_TYPE.SOURCE
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        return;
    end

    if Queuing_Set{QueIndex,9} == 0
        memcpy1(Queuing_Set{QueIndex,13} + Queuing_Set{QueIndex,11},MESSAGE_ADDR,LENGTH);
        Queuing_Set{QeuIndex,3} = Queuing_Set{QeuIndex,3} + 1;
        Queuing_Set{QueIndex,11} = mod(Queuing_Set{QueIndex,11} + LENGTH,Queuing_Set{QueIndex,12});    
        if Queuing_Set{QueIndex,11} == Queuing_Set{QueIndex,10}
            Queuing_Set{QueIndex,9} = 1;
        end
        Queuing_Set{QueIndex,8} = 0;
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        return;
    elseif TIME_OUT == 0
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        return;
    elseif CURRENT_PARTITION.LOCK_LEVEL ~= 0 || CurrentProcess == ERROR_HANDLER_PROCESS_ID
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;    
        return;
    else
        if TIME_OUT ~= INFINITE_TIME_VALUE
            %APEX_INTEGER Proindex;
            Proindex = GetProcessIndex(CurrentProcess);
            Process_Set{Proindex,16} = GetTick() + TIME_OUT; 
        end
        Process_Set{Proindex,11} = PROCESS_STATE_TYPE.WAITING;  
        Process_Set{Proindex,13} = WAITING_RESOURCE_TYPE.MESSAGE_WAITING;
        Process_Waiting_Resource_Set = union(Process_Waiting_Resource_Set,CurrentProcess);            
        Queuing_Set{QueIndex,14} = union(Queuing_Set{QueIndex,14},CurrentProcess);
        Queuing_Set{QueIndex,15} = Queuing_Set{QueIndex,15} + 1; 
        schedule();
        if GetTick() >= Process_Set{Proindex,16}
            RETURN_CODE = RETURN_CODE_TYPE.TIMED_OUT;
            return;
        else
            Queuing_Set{QueIndex,14} = setdiff(Queuing_Set{QueIndex,14},CurrentProcess);
            Process_Waiting_Resource_Set = setdiff(Process_Waiting_Resource_Set,CurrentProcess); 
            Process_Set{Proindex,13} = WAITING_RESOURCE_TYPE.NOT_WAITING;
            Process_Set{Proindex,11} = PROCESS_STATE_TYPE.READY;  
            Ready_Processes_Set = union(Ready_Processes_Set,CurrentProcess);
            RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
            return;
        end  
    end
end



