function [ QUEUING_PORT_ID,RETURN_CODE ] = GET_QUEUING_PORT_ID( QUEUING_PORT_NAME )

    global RETURN_CODE_TYPE;
    global Queuing_Set;


    if isQueuingName(QUEUING_PORT_NAME) == 0
        QUEUING_PORT_ID = -1;        
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end

    
    %APEX_INTEGER Queindex;
    Queindex = GetQueIndexByName(SAMPLING_PORT_NAME);
    QUEUING_PORT_ID  = Queuing_Set{Queindex,1};
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
    return;

end

