function [ output ] = isQueuingName( QUEUING_PORT_NAME )

global Queuing_Set;

QueNameSet = {Queuing_Set{:,2}};
%APEX_INTEGER output;
[output,~] = ismember(QUEUING_PORT_NAME,QueNameSet);

return;

end

