function [ ID ] = GenerateQueId()

%APEX_INTEGER index;
%QUEUING_PORT_ID_TYPE ID;
index = CapacityofQueuing();
ID = index * 100 + randi(99);

return;

end

