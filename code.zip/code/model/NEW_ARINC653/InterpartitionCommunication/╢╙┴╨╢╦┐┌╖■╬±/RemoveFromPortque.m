function [pid] = RemoveFromPortque(Qeuindex)
global Queuing_Set;
pid = Queuing_Set{Qeuindex,14}(1);
Queuing_Set{Qeuindex,14} = setdiff(Queuing_Set{Qeuindex,14},Queuing_Set{Qeuindex,14}(1));
Queuing_Set{Qeuindex,15} = Queuing_Set{Qeuindex,15} - 1;
end