global Queuing_Set;
Queuing_Set = cell(MAX_NUMBER_OF_QUEUING_PORTS,15);

for k=1:MAX_NUMBER_OF_QUEUING_PORTS
    Queuing_Set{k,2}='';
end

global SYSTEM_NUMBER_OF_QUEUING_PORTS;
SYSTEM_NUMBER_OF_QUEUING_PORTS = 0;

global Queuing_Data;
Queuing_Data = cell(1,1024);

global Queuing_Message_Data;
Queuing_Message_Data = cell(1,1024);

global Queuing_index;
Queuing_index = 1;

Configuration_Table{1,2} = 'Que1';
Configuration_Table{2,2} = 'Que2';
Configuration_Table{3,2} = 'Que3';
Configuration_Table{4,2} = 'Que4';
Configuration_Table{5,2} = 'Que5';
Configuration_Table{6,2} = 'Que6';
