function [ index ] = CapacityofQueuing()

    global SYSTEM_LIMIT_NUMBER_OF_QUEUING_PORTS;
    global SYSTEM_NUMBER_OF_QUEUING_PORTS;


    %APEX_INTEGER index;
    if SYSTEM_NUMBER_OF_QUEUING_PORTS < SYSTEM_LIMIT_NUMBER_OF_QUEUING_PORTS
        index = SYSTEM_NUMBER_OF_QUEUING_PORTS + 1;
    else
        index = 0;
    end
    return;



end

