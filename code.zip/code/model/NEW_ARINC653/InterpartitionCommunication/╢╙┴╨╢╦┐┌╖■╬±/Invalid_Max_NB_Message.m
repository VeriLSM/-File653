function [flag] = Invalid_Max_NB_Message(MAX_NB_MESSAGE)

global SYSTEM_LIMIT_NUMBER_OF_MESSAGES;

%APEX_INTEGER flag;
flag = 0;
if MAX_NB_MESSAGE < 0 || MAX_NB_MESSAGE > SYSTEM_LIMIT_NUMBER_OF_MESSAGES
    flag = 1;
end
return;

end
