function [flag] = Invalid_Queuing_Discipline(QUEUING_DISCIPLINE)

global QUEUING_DISCIPLINE_TYPE;

%APEX_INTEGER flag;
flag = 1;
if QUEUING_DISCIPLINE == QUEUING_DISCIPLINE_TYPE.FIFO || QUEUING_DISCIPLINE == QUEUING_DISCIPLINE_TYPE.PRIORITY
    flag = 0;
end
return;

end

