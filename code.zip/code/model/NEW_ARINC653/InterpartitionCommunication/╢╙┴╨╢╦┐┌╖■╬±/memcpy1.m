function memcpy1 (dst, src, length)

global Queuing_Data;
global Queuing_Message_Data;

for i = 1 : length
    Queuing_Data{dst,i} = Queuing_Message_Data{src,i};
end

end