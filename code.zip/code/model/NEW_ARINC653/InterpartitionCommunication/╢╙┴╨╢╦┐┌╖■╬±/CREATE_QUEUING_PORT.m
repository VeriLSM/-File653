function [QUEUING_PORT_ID,RETURN_CODE ] = CREATE_QUEUING_PORT( QUEUING_PORT_NAME,MAX_MESSAGE_SIZE,MAX_NB_MESSAGE,PORT_DIRECTION,QUEUING_DISCIPLINE )

    global RETURN_CODE_TYPE;
    global OPERATING_MODE_TYPE;
    global Queuing_Set;
    global CURRENT_PARTITION;
    global Queuing_index;
    global SYSTEM_NUMBER_OF_QUEUING_PORTS;

    %APEX_INTEGER QueIndex;
    QueIndex = CapacityofQueuing();
    if QueIndex == 0
        QUEUING_PORT_ID = -1;        
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end
    
    if ValidQueName(QUEUING_PORT_NAME) == 0
        QUEUING_PORT_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;       
        return;
    end 
    
    if isQueuingName(QUEUING_PORT_NAME) == 0
        QUEUING_PORT_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.NO_ACTION;
        return;
    end
    

    if Invalid_Max_Message_Size(MAX_MESSAGE_SIZE) == 1
        QUEUING_PORT_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end
      

    if Invalid_Max_NB_Message(MAX_NB_MESSAGE) == 1
        QUEUING_PORT_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;      
        return;
    end


    if Invalid_Port_Direction(PORT_DIRECTION) == 1
        QUEUING_PORT_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end

    
    if Invalid_Queuing_Discipline(QUEUING_DISCIPLINE) == 1
        QUEUING_PORT_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end

    if CURRENT_PARTITION.OPERATING_MODE == OPERATING_MODE_TYPE.NORMAL
        QUEUING_PORT_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        return;
    end

    %QUEUING_PORT_ID_TYPE QueId;
    QueId = GenerateQueId();

    Queuing_Set{QueIndex,1} = QueId;
    Queuing_Set{QueIndex,2} = QUEUING_PORT_NAME;
    Queuing_Set{QueIndex,3} = 0;
    Queuing_Set{QueIndex,4} = MAX_NB_MESSAGE;
    Queuing_Set{QueIndex,5} = MAX_MESSAGE_SIZE;
    Queuing_Set{QueIndex,6} = PORT_DIRECTION;
    Queuing_Set{QueIndex,7} = QUEUING_DISCIPLINE; 		
    Queuing_Set{QueIndex,8} = 1;  
    Queuing_Set{QueIndex,9} = 0;  
    Queuing_Set{QueIndex,10} = 0; 
    Queuing_Set{QueIndex,11} = 0; 
    Queuing_Set{QueIndex,12} = MAX_NB_MESSAGE * MAX_MESSAGE_SIZE; 
    Queuing_Set{QueIndex,13} = Queuing_index;
    Queuing_Set{QueIndex,15} = 0;
    

    SYSTEM_NUMBER_OF_QUEUING_PORTS = SYSTEM_NUMBER_OF_QUEUING_PORTS + 1;
    Queuing_index = Queuing_index + Queuing_Set{QueIndex,12};

    QUEUING_PORT_ID = QueId; 
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
    return;

end

