function [RETURN_CODE ] = CLEAR_QUEUING_PORT(QUEUING_PORT_ID )

    global RETURN_CODE_TYPE;
    global PORT_DIRECTION_TYPE;
    global Queuing_Set;

    if isQueuingID(QUEUING_PORT_ID) == 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    
    %APEX_INTEGER Queindex;
    Queindex = GetQueIndexById(QUEUING_PORT_ID);   
    if Queuing_Set{Queindex,6} ~= PORT_DIRECTION_TYPE.DESTINATION
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        return;   
    end

    Queuing_Set{Queindex,8} = 1;
    Queuing_Set{QueIndex,10} = 0; 
    Queuing_Set{QueIndex,11} = 0; 
    Queuing_Set{Queindex,3} = 0;

    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
    return;

end

