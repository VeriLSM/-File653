function [ output ] =isQueuingID(QUEUING_PORT_ID)
global Queuing_Set;
    QueIDSet=[Queuing_Set{:,1}];
    %APEX_INTEGER output;
    [output,~] = ismember(QUEUING_PORT_ID, QueIDSet);
    return;
end