function [index] = GetQueIndexById( QUEUING_PORT_ID )

global Queuing_Set;

    QueIDSet=[Queuing_Set{:,1}];
    %APEX_INTEGER index;
    [~,index]=ismember(QUEUING_PORT_ID,QueIDSet);
    return;
    
end

