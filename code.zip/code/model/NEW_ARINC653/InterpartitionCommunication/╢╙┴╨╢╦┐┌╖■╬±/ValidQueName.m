function [flag] = ValidQueName (QueName)

    global Configuration_Table;
    
    ConfTblNameSet = {Configuration_Table{:,2}};
    %APEX_INTEGER flag;
    [flag,~] = ismember(QueName,ConfTblNameSet);
    return;
end