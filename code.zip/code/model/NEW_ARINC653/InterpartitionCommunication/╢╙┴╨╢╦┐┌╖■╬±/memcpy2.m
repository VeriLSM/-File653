function memcpy2 (dst, src, length)

global Queuing_Data;
global Queuing_Message_Data;

for i = 1 : length
    Queuing_Message_Data{dst,i} = Queuing_Data{src,i};
    Queuing_Data{src,i} = [];
end

end