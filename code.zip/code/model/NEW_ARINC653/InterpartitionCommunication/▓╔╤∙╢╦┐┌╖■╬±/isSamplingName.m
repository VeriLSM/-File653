function [ output ] = isSamplingName( SAMPLING_PORT_NAME )

global Sampling_Set;

SampNameSet = {Sampling_Set{:,2}};
%APEX_INTEGER output;
[output,~] = ismember(SAMPLING_PORT_NAME,SampNameSet);

return;

end

