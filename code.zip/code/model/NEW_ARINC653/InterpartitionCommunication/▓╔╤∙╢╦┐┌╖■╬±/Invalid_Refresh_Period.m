function [ flag ] = Invalid_Refresh_Period( refresh_period )

global INFINITE_TIME_VALUE;

%APEX_INTEGER flag;
flag = 0;

if (refresh_period< 0 && refresh_period~=INFINITE_TIME_VALUE) || refresh_period > 1000
    flag = 1;
end

return;

end

