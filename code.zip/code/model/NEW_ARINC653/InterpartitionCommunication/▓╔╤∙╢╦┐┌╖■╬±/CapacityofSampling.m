function [ index ] = CapacityofSampling()

    global SYSTEM_LIMIT_NUMBER_OF_SAMPLING_PORTS;
    global SYSTEM_NUMBER_OF_SAMPLING_PORTS;


    %APEX_INTEGER index;
    if SYSTEM_NUMBER_OF_SAMPLING_PORTS < SYSTEM_LIMIT_NUMBER_OF_SAMPLING_PORTS
        index = SYSTEM_NUMBER_OF_SAMPLING_PORTS + 1;
    else
        index = 0;
    end
    return;



end

