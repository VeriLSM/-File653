function [tick] = GetTick()
    global INITIAL_SYSTEM_CLOCK;
    %SYSTEM_TIME_TYPE tick;
    tick = ceil(etime(clock,INITIAL_SYSTEM_CLOCK));
    return;
end