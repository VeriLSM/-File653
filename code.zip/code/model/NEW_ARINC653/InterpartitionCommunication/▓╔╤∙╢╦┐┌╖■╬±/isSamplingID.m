function [ output ] =isSamplingID(SAMPLING_PORT_ID)
global Sampling_Set;
    SampIDSet=[Sampling_Set{:,1}];
    %APEX_INTEGER output;
    [output,~] = ismember(SAMPLING_PORT_ID, SampIDSet);
    return;
end