function [flag] = Invalid_Port_Direction(PORT_DIRECTION)

global PORT_DIRECTION_TYPE;

%APEX_INTEGER flag;
flag = 1;
if PORT_DIRECTION == PORT_DIRECTION_TYPE.DESTINATION || PORT_DIRECTION == PORT_DIRECTION_TYPE.SOURCE
    flag = 0;
end
return;

end

