function [index] = GetProcessIndex( PROCESS_ID )

global Process_Set;

    ProcessIDSet=[Process_Set{:,1}];
    %APEX_INTEGER index;
    [~,index]=ismember(PROCESS_ID,ProcessIDSet);
    return;
    
end

