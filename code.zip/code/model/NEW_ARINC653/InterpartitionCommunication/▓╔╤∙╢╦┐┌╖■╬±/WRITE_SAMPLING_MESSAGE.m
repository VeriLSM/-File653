function [ RETURN_CODE ] = WRITE_SAMPLING_MESSAGE( SAMPLING_PORT_ID,MESSAGE_ADDR,LENGTH )

    global RETURN_CODE_TYPE;
    global PORT_DIRECTION_TYPE;
    global Sampling_Set;



    if isSamplingID(SAMPLING_PORT_ID) == 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    %APEX_INTEGER SampIndex;
    SampIndex = GetSampIndexById(SAMPLING_PORT_ID);
    if LENGTH > Sampling_Set{SampIndex,3}
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end

    if LENGTH <= 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    if Sampling_Set{SampIndex,4} ~= PORT_DIRECTION_TYPE.SOURCE
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        return;
    end

    memcpy1(Sampling_Set{SampIndex,8},MESSAGE_ADDR,LENGTH);
    Sampling_Set{SampIndex,10} = GetTick();

    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
		
	


end

