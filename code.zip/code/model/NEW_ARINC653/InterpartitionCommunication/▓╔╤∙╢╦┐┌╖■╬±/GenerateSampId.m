function [ ID ] = GenerateSampId()

%APEX_INTEGER index;
%SAMPLING_PORT_ID_TYPE ID;
index = CapacityofSampling();
ID = index * 100 + randi(99);

return;

end

