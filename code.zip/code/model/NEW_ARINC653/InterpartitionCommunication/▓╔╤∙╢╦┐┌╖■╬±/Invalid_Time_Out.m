function [ flag ] = Invalid_Time_Out( time_out )

global INFINITE_TIME_VALUE;
global CURRENT_PARTITION;
%APEX_INTEGER flag;
flag = 0;

if (time_out< 0 && time_out~=INFINITE_TIME_VALUE) || time_out > CURRENT_PARTITION.DURATION
    flag = 1;
end

return;

end

