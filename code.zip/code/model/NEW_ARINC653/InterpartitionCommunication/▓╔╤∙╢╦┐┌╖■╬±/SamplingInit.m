global Sampling_Set;
Sampling_Set = cell(MAX_NUMBER_OF_SAMPLING_PORTS,10);

for k=1:MAX_NUMBER_OF_SAMPLING_PORTS
    Sampling_Set{k,2}='';
end

global SYSTEM_NUMBER_OF_SAMPLING_PORTS;
SYSTEM_NUMBER_OF_SAMPLING_PORTS = 0;

global Sampling_Data;
Sampling_Data = cell(1,1024);

global Sampling_Message_Data;
Sampling_Message_Data = cell(1,1024);

global Sampling_Index;
Sampling_Index = 1;

global Configuration_Table;
Configuration_Table = cell(6,7);
Configuration_Table{1,2} = 'Samp1';
Configuration_Table{2,2} = 'Samp2';
Configuration_Table{3,2} = 'Samp3';
Configuration_Table{4,2} = 'Samp4';
Configuration_Table{5,2} = 'Samp5';
Configuration_Table{6,2} = 'Samp6';