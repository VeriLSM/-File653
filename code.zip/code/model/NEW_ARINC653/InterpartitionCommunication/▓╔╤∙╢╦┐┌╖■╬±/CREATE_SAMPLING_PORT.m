function [ SAMPLING_PORT_ID,RETURN_CODE ] = CREATE_SAMPLING_PORT(SAMPLING_PORT_NAME,REFRESH_PERIOD,MAX_MESSAGE_SIZE,PORT_DIRECTION)

	global RETURN_CODE_TYPE;
    global VALIDITY_TYPE;
    global CURRENT_PARTITION;
    global OPERATING_MODE_TYPE;
    global Sampling_Set;
    global Sampling_Index;
    global EMPTY_INDICATOR_TYPE;
   
    %APEX_INTEGER SampIndex;
    SampIndex = CapacityofSampling();
    if SampIndex == 0
        SAMPLING_PORT_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end
    
    if ValidSampName(SAMPLING_PORT_NAME) == 0
        SAMPLING_PORT_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end
    
    if isSamplingName(SAMPLING_PORT_NAME) == 0
        SAMPLING_PORT_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.NO_ACTION;
        return;
    end
    
    if Invalid_Max_Message_Size(MAX_MESSAGE_SIZE) == 1
        SAMPLING_PORT_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end

    if invalid_Queuing_Discipline(PORT_DIRECTION) == 1
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end

    if Invalid_Refresh_Period(REFRESH_PERIOD) == 1
        SAMPLING_PORT_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end

    if CURRENT_PARTITION.OPERATING_MODE ==  OPERATING_MODE_TYPE.NORMAL
        SAMPLING_PORT_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        return;
    end

    %SAMPLING_PORT_ID_TYPE SampId;
    SampId = GenerateSampId();
    
    Sampling_Set{SampIndex,1} = SampId;
    Sampling_Set{SampIndex,2} = SAMPLING_PORT_NAME;
    Sampling_Set{SampIndex,3} = MAX_MESSAGE_SIZE;
    Sampling_Set{SampIndex,4} = PORT_DIRECTION;
    Sampling_Set{SampIndex,5} = REFRESH_PERIOD;
    Sampling_Set{SampIndex,6} = VALIDITY_TYPE.INVALID;
    Sampling_Set{SampIndex,7} = CURRENT_PARTITION.IDENTIFIER;
    Sampling_Set{SampIndex,8} = Sampling_Index;
    Sampling_Set{SampIndex,9} = EMPTY_INDICATOR_TYPE.EMPTY;
    Sampling_Set{SampIndex,10} = 0;
    
    Sampling_Index = Sampling_Index + Sampling_Set{SampIndex,3};

    SAMPLING_PORT_ID = SampId; 
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
 end

