function memcpy2 (dst, src, length)

global Sampling_Data;
global Sampling_Message_Data;

for i = 1 : length
    Sampling_Message_Data{dst,i} = Sampling_Data{src,i};
end

end