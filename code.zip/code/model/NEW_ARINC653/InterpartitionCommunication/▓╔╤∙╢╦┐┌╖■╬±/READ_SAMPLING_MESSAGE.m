function [ LENGTH,VALIDITY,RETURN_CODE ] = READ_SAMPLING_MESSAGE( SAMPLING_PORT_ID,MESSAGE_ADDR)

    global RETURN_CODE_TYPE;
    global EMPTY_INDICATOR_TYPE;
    global PORT_DIRECTION_TYPE;
    global Sampling_Set;
    global VALIDITY_TYPE;


    if isSamplingID(SAMPLING_PORT_ID) == 0
        LENGTH = 0;
        VALIDITY = VALIDITY_TYPE.INVALID;        
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end
    
    %APEX_INTEGER SampIndex;
    SampIndex = GetSampIndexById(SAMPLING_PORT_ID);
    if Sampling_Set{SampIndex,4} ~= PORT_DIRECTION_TYPE.DESTINATION
        LENGTH = 0;
        VALIDITY = VALIDITY_TYPE.INVALID;        
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        return;
    end

    if Sampling_Set{SampIndex,9} == EMPTY_INDICATOR_TYPE.EMPTY
        LENGTH = 0;
        VALIDITY = VALIDITY_TYPE.INVALID;
        RETURN_CODE = RETURN_CODE_TYPE.NO_ACTION;
        return;
    else
        memcpy2(MESSAGE_ADDR,Sampling_Set{SampIndex,8},Sampling_Set{SampIndex,3});
        LENGTH = Sampling_Set{SampIndex,3};
        %SYSTEM_TIME_TYPE tick;
        tick = GetTick();
        if tick < Sampling_Set{SampIndex,10} + Sampling_Set{SampIndex,5}
            VALIDITY = VALIDITY_TYPE.VALID;
        else
            VALIDITY = VALIDITY_TYPE.INVALID;
        end
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        return;
    end
end

