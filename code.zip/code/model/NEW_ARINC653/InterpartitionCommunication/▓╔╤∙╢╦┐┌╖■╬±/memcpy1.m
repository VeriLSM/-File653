function memcpy1 (dst, src, length)

global Sampling_Data;
global Sampling_Message_Data;

for i = 1 : length
    Sampling_Data{dst,i} = Sampling_Message_Data{src,i};
end

end