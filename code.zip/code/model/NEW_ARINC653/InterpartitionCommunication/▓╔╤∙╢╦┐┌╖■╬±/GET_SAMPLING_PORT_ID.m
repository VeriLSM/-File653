function [ SAMPLING_PORT_ID,RETURN_CODE ] = GET_SAMPLING_PORT_ID( SAMPLING_PORT_NAME )
		
    global RETURN_CODE_TYPE;
    global Sampling_Set;
    
    if isSamplingName(SAMPLING_PORT_NAME) == 0
        SAMPLING_PORT_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end

    %APEX_INTEGER Sampindex;
    Sampindex = GetSampIndexByName(SAMPLING_PORT_NAME);
    SAMPLING_PORT_ID  = Sampling_Set{Sampindex,1};
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
    return;



end

