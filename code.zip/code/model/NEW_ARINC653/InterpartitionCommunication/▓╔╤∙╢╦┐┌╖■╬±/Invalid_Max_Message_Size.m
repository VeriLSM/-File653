function [flag] = Invalid_Max_Message_Size(MAX_MESSAGE_SIZE)

global SYSTEM_LIMIT_MESSAGE_SIZE;

%APEX_INTEGER flag;
flag = 0;
if MAX_MESSAGE_SIZE <= 0 || MAX_MESSAGE_SIZE > SYSTEM_LIMIT_MESSAGE_SIZE
    flag = 1;
end

return;

end
