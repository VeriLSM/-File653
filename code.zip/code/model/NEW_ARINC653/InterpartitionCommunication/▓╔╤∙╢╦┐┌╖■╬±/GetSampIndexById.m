function [index] = GetSampIndexById( SAMPLING_PORT_ID )

global Sampling_Set;

    SampIDSet=[Sampling_Set{:,1}];
    %APEX_INTEGER index;
    [~,index]=ismember(SAMPLING_PORT_ID,SampIDSet);
    return;
    
end

