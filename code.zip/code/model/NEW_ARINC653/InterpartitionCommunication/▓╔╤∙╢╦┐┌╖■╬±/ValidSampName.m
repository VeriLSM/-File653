function [flag] = ValidSampName (SampName)

    global Configuration_Table;
    
    ConfTblNameSet = {Configuration_Table{:,2}};
    %APEX_INTEGER flag;
    [flag,~] = ismember(SampName,ConfTblNameSet);
    return;
end