function Shut_Down_Partiton()
global CURRENT_PARTITION;
global Process_Set;
global SYSTEM_NUMBER_OF_PROCESSES;

    
    for i = 1:SYSTEM_NUMBER_OF_PROCESSES
        if Process_Set{i,12} == CURRENT_PARTITION.IDENTIFIER
            for k = 1 : 15
                Process_Set{i,k} = [];
            end
        end
    end
    CURRENT_PARTITION = [];
    
end