function [RETURN_CODE] = SET_PARTITION_MODE(OPERATING_MODE)

    global RETURN_CODE_TYPE;
    global OPERATING_MODE_TYPE;
    global CURRENT_PARTITION;
    global MAX_LOCK_LEVEL;
    global SYSTEM_NUMBER_OF_PROCESSES;
    global Process_Set;
    global WAITING_RESOURCE_TYPE;
    global Waiting_Processes_Set;
    global PROCESS_STATE_TYPE;
    global INFINITE_TIME_VALUE;
    global Ready_Processes_Set;
    global Process_Waiting_Resource_Set;
    global INITIAL_SYSTEM_CLOCK;

    if Invalid_Operating_Mode(OPERATING_MODE) == 1
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    if OPERATING_MODE == OPERATING_MODE_TYPE.NORMAL && CURRENT_PARTITION.OPERATING_MODE == OPERATING_MODE_TYPE.NORMAL
        RETURN_CODE = RETURN_CODE_TYPE.NO_ACTION;
        return;
    end

    if OPERATING_MODE == OPERATING_MODE_TYPE.WARM_START && CURRENT_PARTITION.OPERATING_MODE == OPERATING_MODE_TYPE.COLD_START
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        return;
    end

    CURRENT_PARTITION.OPERATING_MODE = OPERATING_MODE;

    if OPERATING_MODE == OPERATING_MODE_TYPE.IDLE
        Shut_Down_Partiton();
    end

    if OPERATING_MODE == OPERATING_MODE_TYPE.WARM_START || OPERATING_MODE == OPERATING_MODE_TYPE.COLD_START
        CURRENT_PARTITION.LOCK_LEVEL = round(MAX_LOCK_LEVEL * rand(1));
        Partition_Init();
    end

    if OPERATING_MODE == OPERATING_MODE_TYPE.NORMAL
        INITIAL_SYSTEM_CLOCK = clock;
        %APEX_INTEGER i;
        i = 1;
        while i <= SYSTEM_NUMBER_OF_PROCESSES
            %APEX_INTEGER flag;
            [flag,~] = ismember(Process_Set{i,1},Waiting_Processes_Set);
            if Process_Set{i,6} == INFINITE_TIME_VALUE && Process_Set{i,13} == WAITING_RESOURCE_TYPE.NORMAL_MODE_WAITING && Process_Set{i,14} == 0 && flag == 0
                %PROCESS_ID_TYPE PID;
                PID = Process_Set{i,1};
                Process_Set{i,11} = PROCESS_STATE_TYPE.READY;
                Ready_Processes_Set=union(Ready_Processes_Set,PID); 
                Process_Waiting_Resource_Set=setdiff(Process_Waiting_Resource_Set,PID);    
                Process_Set{i,13} = WAITING_RESOURCE_TYPE.NOT_WAITING;
				Process_Set{i,10} = GetTick() + Process_Set{i,7};	                
                i = i + 1;
                continue;
            end
            if Process_Set{i,6} == INFINITE_TIME_VALUE && Process_Set{i,13} == WAITING_RESOURCE_TYPE.NORMAL_MODE_WAITING && Process_Set{i,14} ~= 0
                Process_Set{i,14} = GetTick() + Process_Set{i,14};
                Process_Set{i,11} = PROCESS_STATE_TYPE.WAITING;
                Process_Set{i,13} = WAITING_RESOURCE_TYPE.DELAY_WAITING;
                Process_Set{i,10} = Process_Set{i,14} + Process_Set{i,7};
                i = i + 1;
                continue;
            end
            if Process_Set{i,6} ~= INFINITE_TIME_VALUE && Process_Set{i,13} == WAITING_RESOURCE_TYPE.NORMAL_MODE_WAITING && Process_Set{i,14} == 0 && flag == 0
                Process_Set{i,15} = CURRENT_PARTITION.ACTIVATION + CURRENT_PARTITION.PERIOD;
                Process_Set{i,11} = PROCESS_STATE_TYPE.WAITING;
                Process_Set{i,13} = WAITING_RESOURCE_TYPE.PERIOD_WAITING;
                Process_Set{i,10} = Process_Set{i,15} + Process_Set{i,7};
                i = i + 1;
                continue;
            end
            if Process_Set{i,6} ~= INFINITE_TIME_VALUE && Process_Set{i,13} == WAITING_RESOURCE_TYPE.NORMAL_MODE_WAITING && Process_Set{i,14} ~= 0
                Process_Set{i,15} = CURRENT_PARTITION.ACTIVATION + Process_Set{i,14} + CURRENT_PARTITION.PERIOD;
                Process_Set{i,11} = PROCESS_STATE_TYPE.WAITING;
                Process_Set{i,13} = WAITING_RESOURCE_TYPE.PERIOD_WAITING;
                Process_Set{i,10} = Process_Set{i,15} + Process_Set{i,7};
                i = i + 1;
                continue;
            end
            i = i + 1;
        end
        CURRENT_PARTITION.LOCK_LEVEL = 0;
        schedule();
    end
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
end



