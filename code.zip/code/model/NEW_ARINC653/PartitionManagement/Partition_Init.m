function Partition_Init ()

    global CURRENT_PARTITION;
    global MIN_PRIORITY_VALUE;
    global CurrentProcess;
    global DEADLINE_TYPE;
    global Process_Set;
    global PROCESS_STATE_TYPE;
    global MAX_LOCK_LEVEL;
    global Dormant_Processes_Set;
    global Ready_Processes_Set;
    global SYSTEM_NUMBER_OF_PROCESSES;
    global Waiting_Processes_Set;
    global Process_Waiting_Resource_Set;
    global PROCESS_SCHEDULING_FLAG;
    global MAX_NUMBER_OF_PROCESSES;
    
    SYSTEM_NUMBER_OF_PROCESSES = 0;
    Process_Set = cell(MAX_NUMBER_OF_PROCESSES,16);
    for k=1:MAX_NUMBER_OF_PROCESSES
        Process_Set{k,2}='';
    end
    Dormant_Processes_Set=[];
    Ready_Processes_Set=[];
    Waiting_Processes_Set=[];    
    Process_Waiting_Resource_Set=[];   
    PROCESS_SCHEDULING_FLAG = 0;

    global WAITING_RESOURCE_TYPE;
    WAITING_RESOURCE_TYPE.NOT_WAITING = 0;
    WAITING_RESOURCE_TYPE.DELAY_WAITING = 1;
    WAITING_RESOURCE_TYPE.SEMAPHORE_WAITING = 2;
    WAITING_RESOURCE_TYPE.PERIOD_WAITING = 3;
    WAITING_RESOURCE_TYPE.EVENT_WAITING = 4;
    WAITING_RESOURCE_TYPE.MESSAGE_WAITING = 5;
    WAITING_RESOURCE_TYPE.NORMAL_MODE_WAITING = 6;





    CURRENT_PARTITION.IDENTIFIER = 1;
    CURRENT_PARTITION.NAME = 'PAR1';
    CURRENT_PARTITION.SIZE = 500;
    CURRENT_PARTITION.PERIOD = 50;
    CURRENT_PARTITION.DURATION = 40;
    CURRENT_PARTITION.INTER_PAR = 1;
    CURRENT_PARTITION.ERROR_STATUS = [];
    CURRENT_PARTITION.ENTRY_POINT = 1234567;
    CURRENT_PARTITION.SYSTEM_PARTITION = 1;
    %CURRENT_PARTITION.LOCK_LEVEL = round(MAX_LOCK_LEVEL * rand(1));
    CURRENT_PARTITION.LOCK_LEVEL = 0;
    CURRENT_PARTITION.OPERATING_MODE = 2;
    CURRENT_PARTITION.START_CONDITION = 0;
    CURRENT_PARTITION.ACTIVATION = 0;
    
    ATTRIBUTES.NAME='main_thread';
    ATTRIBUTES.ENTRY_POINT=100;
    ATTRIBUTES.STACK_SIZE=20;
    ATTRIBUTES.BASE_PRIORITY=MIN_PRIORITY_VALUE;
    ATTRIBUTES.PERIOD=-1;
    ATTRIBUTES.TIME_CAPACITY=0;
    ATTRIBUTES.DEADLINE=DEADLINE_TYPE.SOFT;
    
    addpath(genpath('../ProcessManagement'));
    CREATE_PROCESS(ATTRIBUTES);
    CurrentProcess = Process_Set{1,1};
    Dormant_Processes_Set = setdiff(Dormant_Processes_Set,CurrentProcess);
    Process_Set{1,11} = PROCESS_STATE_TYPE.RUNNING;
    Process_Set{1,9} = ATTRIBUTES.BASE_PRIORITY;
end