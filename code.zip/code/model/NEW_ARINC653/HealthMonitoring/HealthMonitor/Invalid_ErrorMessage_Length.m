function [flag] = Invalid_ErrorMessage_Length (length)
    global MAX_ERROR_MESSAGE_SIZE;
    %APEX_INTEGER flag;
    flag = 0;
    if length < 0 || length > MAX_ERROR_MESSAGE_SIZE
        flag = 1;
    end
    return;
end