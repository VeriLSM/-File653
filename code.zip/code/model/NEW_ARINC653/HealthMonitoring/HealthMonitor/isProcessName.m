function [ output ] = isProcessName( PROCESS_NAME )

global Process_Set;

ProcessNameSet = {Process_Set{:,2}};
%APEX_INTEGER output;
[output,~] = ismember(PROCESS_NAME,ProcessNameSet);

return;

end

