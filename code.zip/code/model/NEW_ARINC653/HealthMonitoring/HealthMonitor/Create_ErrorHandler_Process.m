function  Create_ErrorHandler_Process(ATTRIBUTES)

        global PROCESS_STATE_TYPE;
        global CURRENT_PARTITION;
        global SYSTEM_NUMBER_OF_PROCESSES;
        global Process_Set;
        global Dormant_Processes_Set;       
        global ERROR_HANDLER_PROCESS_ID;
        
        %PROCESS_ID_TYPE ID;
        ID = ERROR_HANDLER_PROCESS_ID;
        Process_Set{Proindex,1}=ID;
        Process_Set{Proindex,2}=ATTRIBUTES.NAME;
        Process_Set{Proindex,3}=ATTRIBUTES.ENTRY_POINT;
        Process_Set{Proindex,4}=ATTRIBUTES.STACK_SIZE;
        Process_Set{Proindex,5}=ATTRIBUTES.BASE_PRIORITY;
        Process_Set{Proindex,6}=ATTRIBUTES.PERIOD;
        Process_Set{Proindex,7}=ATTRIBUTES.TIME_CAPACITY;
        Process_Set{Proindex,8}=ATTRIBUTES.DEADLINE;
        Process_Set{Proindex,11}=PROCESS_STATE_TYPE.DORMANT;
        Process_Set{Proindex,12} = CURRENT_PARTITION.IDENTIFIER;

        SYSTEM_NUMBER_OF_PROCESSES = SYSTEM_NUMBER_OF_PROCESSES + 1;

        Dormant_Processes_Set=union(Dormant_Processes_Set,ID);
        
        Initialize_Process_Context(ID);
        Initialize_Process_Stack(ID);


end


