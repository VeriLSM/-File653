function memcpy2 (dst,src,size)
    global ERROR_LIST;
    global CURRENT_PARTITION;

    for i = 1 : size
        CURRENT_PARTITION.ERROR_STATUS.MESSAGE{dst.i} = ERROR_LIST{src,5}{1:i};
    end
    
end