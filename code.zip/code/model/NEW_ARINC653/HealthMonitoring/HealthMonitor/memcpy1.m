function memcpy1 (dst,src,size)
    global ERROR_LIST;
    global CURRENT_PARTITION;

    for i = 1 : size
        ERROR_LIST{dst,5}{1:i} = CURRENT_PARTITION.ERROR_STATUS.MESSAGE{src.i};
    end
    
end