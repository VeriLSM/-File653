function [ output ] =isErrorHandlerID()
global Process_Set;
global ERROR_HANDLER_PROCESS_ID;
    ProcessIDSet = [Process_Set{:,1}];
    %APEX_INTEGER output;
    [output,~] = ismember(ERROR_HANDLER_PROCESS_ID, ProcessIDSet);
    return;
end