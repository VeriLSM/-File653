function [ RETURN_CODE ] = REPORT_APPLICATION_MESSAGE( MESSAGE_ADDR,LENGTH )

    global RETURN_CODE_TYPE;
    global CURRENT_PARTITION;
    global Error_Status_Index;
    global ERROR_LIST;
    global SYSTEM_NUMBER_OF_ERROR_PROCESSES;

    if Invalid_ErrorMessage_Length(LENGTH) == 1
        RETURN_CODE=RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    
    Error_Status_Index = Error_Status_Index + 1;
    ERROR_LIST{Error_Status_Index,1} = CURRENT_PARTITION.ERROR_STATUS.ERROR_CODE;
    ERROR_LIST{Error_Status_Index,2} = LENGTH;
    ERROR_LIST{Error_Status_Index,3} = CURRENT_PARTITION.ERROR_STATUS.FAILED_PROCESS_ID;
    ERROR_LIST{Error_Status_Index,4} = CURRENT_PARTITION.ERROR_STATUS.FAILED_ADDRESS;
    memcpy(Error_Status_Index,MESSAGE_ADDR,LENGTH);
    
    
    SYSTEM_NUMBER_OF_ERROR_PROCESSES = SYSTEM_NUMBER_OF_ERROR_PROCESSES + 1;
    RETURN_CODE=RETURN_CODE_TYPE.NO_ERROR;
    return;

end

