function [ flag ] = Invalid_Stack_Size( stack_size )

%APEX_INTEGER flag;
flag = 0;

if stack_size > 2048
    flag = 1;
end

return;

end

