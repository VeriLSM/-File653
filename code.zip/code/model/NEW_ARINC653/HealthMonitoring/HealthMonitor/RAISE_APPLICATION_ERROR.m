function [ RETURN_CODE ] = RAISE_APPLICATION_ERROR( ERROR_CODE,MESSAGE_ADDR,LENGTH )

    global RETURN_CODE_TYPE;
    global ERROR_CODE_TYPE;
    global CurrentProcess;
    global ERROR_HANDLER_PROCESS_ID;
    global CURRENT_PARTITION;

    if Invalid_ErrorMessage_Length(LENGTH) == 1
        RETURN_CODE=RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    if ERROR_CODE ~= ERROR_CODE_TYPE.APPLICATION_ERROR
        RETURN_CODE=RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    if  CurrentProcess == ERROR_HANDLER_PROCESS_ID || isErrorHandlerID() == 0
        CURRENT_PARTITION.ERROR_STATUS.ERROR_CODE = ERROR_CODE;
        memcpy2(MESSAGE_ADDR,Error_Status_Index,LENGTH);
    else
        START(ERROR_HANDLER_PROCESS_ID);
    end
    
    RETURN_CODE=RETURN_CODE_TYPE.NO_ERROR;
    return;

end

