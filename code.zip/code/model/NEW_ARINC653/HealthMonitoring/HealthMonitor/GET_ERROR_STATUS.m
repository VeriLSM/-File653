function [ ERROR_STATUS,RETURN_CODE ] = GET_ERROR_STATUS()

    global RETURN_CODE_TYPE;
    global ERROR_LIST;
    global CurrentProcess;
    global ERROR_HANDLER_PROCESS_ID;
    global Error_Status_Index;
    global SYSTEM_NUMBER_OF_ERROR_PROCESSES;

    if CurrentProcess ~= ERROR_HANDLER_PROCESS_ID    
        ERROR_STATUS.ERROR_CODE = -1; 
        ERROR_STATUS.LENGTH = -1;
        ERROR_STATUS.FAILED_PROCESS_ID = -1;
        ERROR_STATUS.FAILED_ADDRESS = -1;
        RETURN_CODE=RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end

    if SYSTEM_NUMBER_OF_ERROR_PROCESSES == 0 
        ERROR_STATUS.ERROR_CODE = -1; 
        ERROR_STATUS.LENGTH = -1;
        ERROR_STATUS.FAILED_PROCESS_ID = -1;
        ERROR_STATUS.FAILED_ADDRESS = -1;
        RETURN_CODE=RETURN_CODE_TYPE.NO_ACTION;
        return;
    end

    ERROR_STATUS.ERROR_CODE = ERROR_LIST{Error_Status_Index,1}; 
    ERROR_STATUS.LENGTH = ERROR_LIST{Error_Status_Index,2};
    ERROR_STATUS.FAILED_PROCESS_ID = ERROR_LIST{Error_Status_Index,3};
    ERROR_STATUS.FAILED_ADDRESS = ERROR_LIST{Error_Status_Index,4};

    Error_Status_Index = Error_Status_Index - 1;
    SYSTEM_NUMBER_OF_ERROR_PROCESSES = SYSTEM_NUMBER_OF_ERROR_PROCESSES - 1;
    RETURN_CODE=RETURN_CODE_TYPE.NO_ERROR;
    return;

end

