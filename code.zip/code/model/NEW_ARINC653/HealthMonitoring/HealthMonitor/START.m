function [RETURN_CODE] = START(PROCESS_ID)
               
        global PROCESS_STATE_TYPE;
        global RETURN_CODE_TYPE;
        global OPERATING_MODE_TYPE;
        global Process_Set;
        global Dormant_Processes_Set;
        global Ready_Processes_Set;
        global CURRENT_PARTITION;
        global PROCESS_SCHEDULING_FLAG;
        global INFINITE_TIME_VALUE;
        global WAITING_RESOURCE_TYPE;
        global Process_Waiting_Resource_Set;
        
        %APEX_INTEGER index;
        index = GetProcessIndex(PROCESS_ID);
        if index == 0
			RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
			return;
        end

        %PROCESS_STATE_TYPE ProcessState;
        ProcessState = Process_Set{index,11};
        if ProcessState ~= PROCESS_STATE_TYPE.DORMANT
            RETURN_CODE = RETURN_CODE_TYPE.NO_ACTION;
            return;
        end               
        
        %SYSTEM_TIME_TYPE TimeCapacity;
        %SYSTEM_TIME_TYPE DeadLineTime;
        TimeCapacity = Process_Set{index,7};
        DeadLineTime = GetTick() + TimeCapacity;
        if DeadLineTimeOutofRange(DeadLineTime) == 1
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
            return;
        end
        
        %SYSTEM_TIME_TYPE ProcessPeriod;
        ProcessPeriod = Process_Set{index,6};
  		if ProcessPeriod == INFINITE_TIME_VALUE
			Process_Set{index,9} = Process_Set{index,5};
            Initialize_Process_Context(PROCESS_ID);
            Initialize_Process_Stack(PROCESS_ID);
			if  CURRENT_PARTITION.OPERATING_MODE == OPERATING_MODE_TYPE.NORMAL
				Process_Set{index,11} = PROCESS_STATE_TYPE.READY;
                Dormant_Processes_Set=setdiff(Dormant_Processes_Set,PROCESS_ID);
                Ready_Processes_Set=union(Ready_Processes_Set,PROCESS_ID);   
                DeadLineTime = GetTick() + TimeCapacity;
				Process_Set{index,10} = DeadLineTime;			                
                if  CURRENT_PARTITION.LOCK_LEVEL == 0
    				PROCESS_SCHEDULING_FLAG = 1;
                    schedule();
                end                
            else
				Process_Set{index,11} = PROCESS_STATE_TYPE.WAITING;
                Process_Set{index,13} = WAITING_RESOURCE_TYPE.NORMAL_MODE_WAITING;
				Dormant_Processes_Set=setdiff(Dormant_Processes_Set,PROCESS_ID);
                Process_Waiting_Resource_Set=union(Process_Waiting_Resource_Set,PROCESS_ID);
            end            
			RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
			return;	
       else		
  			Process_Set{index,9} = Process_Set{index,5};
            Initialize_Process_Context(PROCESS_ID);
            Initialize_Process_Stack(PROCESS_ID);
			if  CURRENT_PARTITION.OPERATING_MODE == OPERATING_MODE_TYPE.NORMAL				
				Process_Set{index,11} = PROCESS_STATE_TYPE.WAITING;
                Process_Set{index,13} = WAITING_RESOURCE_TYPE.PERIOD_WAITING;
				Dormant_Processes_Set=setdiff(Dormant_Processes_Set,PROCESS_ID);
                Process_Waiting_Resource_Set=union(Process_Waiting_Resource_Set,PROCESS_ID);
                Process_Set{index,15} = GetTick();
                DeadLineTime = Process_Set{index,15} + TimeCapacity;
                Process_Set{index,10} = DeadLineTime;	
            else			
				Process_Set{index,11} = PROCESS_STATE_TYPE.WAITING;
                Process_Set{index,13} = WAITING_RESOURCE_TYPE.NORMAL_MODE_WAITING;
				Dormant_Processes_Set=setdiff(Dormant_Processes_Set,PROCESS_ID);
                Process_Waiting_Resource_Set=union(Process_Waiting_Resource_Set,PROCESS_ID);           
            end            
			RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
			return;  
        end
        
end

