function [ flag ] = Invalid_Time_Capacity( time_capacity )

global INFINITE_TIME_VALUE;
global CURRENT_PARTITION;

%APEX_INTEGER flag;
flag = 0;

if time_capacity < 0 && time_capacity ~= INFINITE_TIME_VALUE && time_capacity > CURRENT_PARTITION.DURATION
    flag = 1;
end

return;

end

