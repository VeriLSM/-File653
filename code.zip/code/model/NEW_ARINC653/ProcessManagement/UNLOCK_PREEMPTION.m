function [ LOCK_LEVEL,RETURN_CODE ] = UNLOCK_PREEMPTION()

        global RETURN_CODE_TYPE;
        global OPERATING_MODE_TYPE;
        global ERROR_HANDLER_PROCESS_ID;
        global PROCESS_SCHEDULING_FLAG;
        global CurrentProcess;
        global CURRENT_PARTITION;
        
        if CurrentProcess == ERROR_HANDLER_PROCESS_ID 
            LOCK_LEVEL = CURRENT_PARTITION.LOCK_LEVEL;
            RETURN_CODE = RETURN_CODE_TYPE.NO_ACTION;
            return;
        end
        
        if CURRENT_PARTITION.OPERATING_MODE ~= OPERATING_MODE_TYPE.NORMAL
            LOCK_LEVEL = CURRENT_PARTITION.LOCK_LEVEL;
            RETURN_CODE = RETURN_CODE_TYPE.NO_ACTION;
            return;
        end
        
        if CURRENT_PARTITION.LOCK_LEVEL == 0
            LOCK_LEVEL = CURRENT_PARTITION.LOCK_LEVEL;
            RETURN_CODE = RETURN_CODE_TYPE.NO_ACTION;
            return;
        end
        
        CURRENT_PARTITION.LOCK_LEVEL = CURRENT_PARTITION.LOCK_LEVEL - 1;
        if CURRENT_PARTITION.LOCK_LEVEL == 0
            PROCESS_SCHEDULING_FLAG = 1;
            schedule();
        end        
        LOCK_LEVEL = CURRENT_PARTITION.LOCK_LEVEL;
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        return;

end

