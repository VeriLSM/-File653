function [RETURN_CODE] = DELAYED_START(PROCESS_ID,DELAY_TIME)
               
        global PROCESS_STATE_TYPE;
        global RETURN_CODE_TYPE;
        global OPERATING_MODE_TYPE;
        global Process_Set;
        global Dormant_Processes_Set;
        global Ready_Processes_Set;
        global Process_Waiting_Resource_Set;
        global CURRENT_PARTITION;
        global PROCESS_SCHEDULING_FLAG;
        global INFINITE_TIME_VALUE;
        global WAITING_RESOURCE_TYPE;
        
       %APEX_INTEGER index;
       index = GetProcessIndex(PROCESS_ID);
        if index == 0
			RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
			return;
        end

        %PROCESS_STATE_TYPE ProcessState;
        ProcessState = Process_Set{index,11};
        if ProcessState ~= PROCESS_STATE_TYPE.DORMANT
            RETURN_CODE = RETURN_CODE_TYPE.NO_ACTION;
            return;
        end 

        if Invalid_Delay_Time(DELAY_TIME) == 1
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
            return;
        end      
        
        %SYSTEM_TIME_TYPE ProcessPeriod;               
        ProcessPeriod = Process_Set{index,6};
        if ProcessPeriod ~= INFINITE_TIME_VALUE && DELAY_TIME >= ProcessPeriod
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
            return;
        end
        
        %SYSTEM_TIME_TYPE TimeCapacity;
        %SYSTEM_TIME_TYPE DeadLineTime;
        TimeCapacity = Process_Set{index,7};
        DeadLineTime = GetTick() + TimeCapacity + DELAY_TIME;
        if Invalid_DeadLineTime(DeadLineTime) == 1
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
            return;
        end
        
        if ProcessPeriod == INFINITE_TIME_VALUE
			Process_Set{index,9} = Process_Set{index,5};
            Initialize_Process_Context(PROCESS_ID);
            Initialize_Process_Stack(PROCESS_ID);
            if  CURRENT_PARTITION.OPERATING_MODE == OPERATING_MODE_TYPE.NORMAL
                if DELAY_TIME == 0
                    Process_Set{index,11} = PROCESS_STATE_TYPE.READY;
                    Dormant_Processes_Set=setdiff(Dormant_Processes_Set,PROCESS_ID);
                    Ready_Processes_Set=union(Ready_Processes_Set,PROCESS_ID);               
                    DeadLineTime = GetTick() + TimeCapacity;
                    Process_Set{index,10} = DeadLineTime;
                else
                    Process_Set{index,11} = PROCESS_STATE_TYPE.WAITING;
                    Process_Set{index,13} = WAITING_RESOURCE_TYPE.DELAY_WAITING;
                    Dormant_Processes_Set=setdiff(Dormant_Processes_Set,PROCESS_ID);
                    Process_Waiting_Resource_Set=union(Process_Waiting_Resource_Set,PROCESS_ID);
                    DeadLineTime = GetTick() + TimeCapacity + DELAY_TIME;
                    Process_Set{index,10} = DeadLineTime;	
                    Process_Set{index,14} = GetTick() + DELAY_TIME; 
                end
                if  CURRENT_PARTITION.LOCK_LEVEL == 0
    				PROCESS_SCHEDULING_FLAG = 1;
                end
            else
				Process_Set{index,11} = PROCESS_STATE_TYPE.WAITING;
                Process_Set{index,13} = WAITING_RESOURCE_TYPE.NORMAL_MODE_WAITING;
                Process_Set{index,14} = DELAY_TIME; 
                Dormant_Processes_Set=setdiff(Dormant_Processes_Set,PROCESS_ID);
                Process_Waiting_Resource_Set=union(Process_Waiting_Resource_Set,PROCESS_ID);
            end            
			RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
			return;	
        else		
			Process_Set{index,9} = Process_Set{index,5};
            Initialize_Process_Context(PROCESS_ID);
            Initialize_Process_Stack(PROCESS_ID);
			if  CURRENT_PARTITION.OPERATING_MODE == OPERATING_MODE_TYPE.NORMAL				
				Process_Set{index,11} = PROCESS_STATE_TYPE.WAITING;
                Process_Set{index,13} = WAITING_RESOURCE_TYPE.PERIOD_WAITING;
                Dormant_Processes_Set=setdiff(Dormant_Processes_Set,PROCESS_ID);
                Process_Waiting_Resource_Set=union(Process_Waiting_Resource_Set,PROCESS_ID);
                Process_Set{index,15} = GetTick() + DELAY_TIME;
                DeadLineTime = Process_Set{index,15} + TimeCapacity;
                Process_Set{index,10} = DeadLineTime;	
            else			
				Process_Set{index,11} = PROCESS_STATE_TYPE.WAITING;
                Process_Set{index,13} = WAITING_RESOURCE_TYPE.NORMAL_MODE_WAITING;
                Process_Set{index,14} = DELAY_TIME; 
                Dormant_Processes_Set=setdiff(Dormant_Processes_Set,PROCESS_ID);
                Process_Waiting_Resource_Set=union(Process_Waiting_Resource_Set,PROCESS_ID);
            end            
			RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
			return;      
        end
        
end




