function STOP_SELF()
        
        global PROCESS_STATE_TYPE;
        global Process_Set;
        global CurrentProcess;
        global Dormant_Processes_Set;
        global CURRENT_PARTITION;
        global ERROR_HANDLER_PROCESS_ID;
        global PROCESS_SCHEDULING_FLAG;
        global PreviousProcess;

        if  CurrentProcess ~= ERROR_HANDLER_PROCESS_ID
            CURRENT_PARTITION.LOCK_LEVEL = 0;
        end
        
        %APEX_INTEGER Curindex;
        Curindex = GetProcessIndex(CurrentProcess);
        Process_Set{Curindex,11} = PROCESS_STATE_TYPE.DORMANT;
        
        Dormant_Processes_Set=union(Dormant_Processes_Set,CurrentProcess);
        
        %APEX_INTEGER Preindex;
        Preindex = GetProcessIndex(PreviousProcess);
        if CurrentProcess == ERROR_HANDLER_PROCESS_ID && CURRENT_PARTITION.LOCK_LEVEL ~= 0 && Process_Set{Preindex,11} ~= PROCESS_STATE_TYPE.DORMANT
            Process_Set{Preindex,11} = PROCESS_STATE_TYPE.RUNNING;
            Dormant_Processes_Set=setdiff(Dormant_Processes_Set,PreviousProcess);
            CurrentProcess = PreviousProcess;
        else
            PROCESS_SCHEDULING_FLAG = 1;
            schedule();
        end
        
end

