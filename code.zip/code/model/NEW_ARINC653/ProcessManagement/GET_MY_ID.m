function [PROCESS_ID,RETURN_CODE] = GET_MY_ID()

        global RETURN_CODE_TYPE;
        global ERROR_HANDLER_PROCESS_ID;
        global CurrentProcess;

        if  isempty(CurrentProcess) == 1
            PROCESS_ID = -1;            
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
            return;
        end
        
        if  CurrentProcess == ERROR_HANDLER_PROCESS_ID
            PROCESS_ID = -1;
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
            return;
        end

        PROCESS_ID = CurrentProcess;
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        
        return;

end



