function [ RETURN_CODE ] = SUSPEND( PROCESS_ID )

        global PROCESS_STATE_TYPE;
        global RETURN_CODE_TYPE;
        global Process_Set;
        global Ready_Processes_Set;
        global Waiting_Processes_Set;
        global ERROR_HANDLER_PROCESS_ID;
        global CURRENT_PARTITION;
        global INFINITE_TIME_VALUE;

        if PROCESS_ID == ERROR_HANDLER_PROCESS_ID || CURRENT_PARTITION.LOCK_LEVEL > 0
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;          
            return;
        end

        %APEX_INTEGER index;
        index=GetProcessIndex(PROCESS_ID);
        %PROCESS_STATE_TYPE ProcessState;
        ProcessState = Process_Set{index,11};
        if index == 0 || ProcessState == PROCESS_STATE_TYPE.RUNNING
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
            return;
        end
        
        if ProcessState == PROCESS_STATE_TYPE.DORMANT
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
            return;
        end
        
        %PRIORITY_TYPE ProcessPeriod;
        ProcessPeriod = Process_Set{index,6};
        if ProcessPeriod ~= INFINITE_TIME_VALUE
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
            return;
        end
        
        if ProcessState == PROCESS_STATE_TYPE.WAITING
            RETURN_CODE = RETURN_CODE_TYPE.NO_ACTION;
            return;
        end
        
        Process_Set{index,11}=PROCESS_STATE_TYPE.WAITING;
        Waiting_Processes_Set=union(Waiting_Processes_Set,PROCESS_ID);
        Ready_Processes_Set=setdiff(Ready_Processes_Set,PROCESS_ID);
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        return;
            
end

