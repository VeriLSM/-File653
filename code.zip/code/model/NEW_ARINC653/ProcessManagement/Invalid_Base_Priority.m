function [ flag ] = Invalid_Base_Priority( base_priority )

global MAX_PRIORITY_VALUE;
global MIN_PRIORITY_VALUE;

%APEX_INTEGER flag;
flag = 0;

if base_priority < MIN_PRIORITY_VALUE || base_priority > MAX_PRIORITY_VALUE
    flag = 1;
end

return;

end

