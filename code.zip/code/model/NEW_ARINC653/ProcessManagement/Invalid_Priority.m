function [ flag ] = Invalid_Priority( priority )

global MIN_PRIORITY_VALUE;
global MAX_PRIORITY_VALUE;

%APEX_INTEGER flag;
flag = 0;

if priority < MIN_PRIORITY_VALUE || priority > MAX_PRIORITY_VALUE
    flag = 1;
end

return;

end

