function [ ret ] = Invalid_DeadLineTime(DeadLineTime)

    global CURRENT_PARTITION;
    %APEX_INTEGER ret;
    ret = 0;
    
    if DeadLineTime > GetTick() + CURRENT_PARTITION.DURATION
        ret = 1;
    end
    
    return;
    
end