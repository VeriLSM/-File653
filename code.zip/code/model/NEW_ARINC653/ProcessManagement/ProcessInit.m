global SYSTEM_NUMBER_OF_PROCESSES;
SYSTEM_NUMBER_OF_PROCESSES = 0;

global PROCESS_SCHEDULING_FLAG;
PROCESS_SCHEDULING_FLAG = 0;

global INITIAL_SYSTEM_CLOCK;
INITIAL_SYSTEM_CLOCK = clock;

global WAITING_RESOURCE_TYPE;
WAITING_RESOURCE_TYPE.NOT_WAITING = 0;
WAITING_RESOURCE_TYPE.DELAY_WAITING = 1;
WAITING_RESOURCE_TYPE.SEMAPHORE_WAITING = 2;
WAITING_RESOURCE_TYPE.PERIOD_WAITING = 3;
WAITING_RESOURCE_TYPE.EVENT_WAITING = 4;
WAITING_RESOURCE_TYPE.MESSAGE_WAITING = 5;
WAITING_RESOURCE_TYPE.NORMAL_MODE_WAITING = 6;

global Process_Set;
Process_Set = cell(MAX_NUMBER_OF_PROCESSES,17);
global Dormant_Processes_Set;
Dormant_Processes_Set=[];
global Ready_Processes_Set;
Ready_Processes_Set=[];
global Waiting_Processes_Set;
Waiting_Processes_Set=[];
global Process_Waiting_Resource_Set;
Process_Waiting_Resource_Set=[];


for k=1:MAX_NUMBER_OF_PROCESSES
    Process_Set{k,2}='';
end
