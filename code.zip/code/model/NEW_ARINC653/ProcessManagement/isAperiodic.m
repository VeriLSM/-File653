function [ ret ]=isAperiodic(period)

global INFINITE_TIME_VALUE;

%APEX_INTEGER ret;
    ret = 0;
    if period == INFINITE_TIME_VALUE
        ret = 1;
    end
    
    return;

end