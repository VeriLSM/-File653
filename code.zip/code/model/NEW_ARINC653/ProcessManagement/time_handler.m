function time_handler(obj,event)

%T = timer('TimerFcn',@time_handler, 'Period', 3,'executionmode','fixeddelay','TasksToExecute',100000)
    global Running_Processes_Set;
    global Process_Set;
    global PROCESS_STATE_TYPE;
    global Ready_Processes_Set;
    global CurrentProcessID;
    global SYSTEM_NUMBER_OF_PROCESSES;
    

    for i = 1 : SYSTEM_NUMBER_OF_PROCESSES
        
    end
    schedule();

    


end