function [ LOCK_LEVEL,RETURN_CODE ] = LOCK_PREEMPTION()

        global RETURN_CODE_TYPE;
        global OPERATING_MODE_TYPE;
        global ERROR_HANDLER_PROCESS_ID;
        global MAX_LOCK_LEVEL;
        global CurrentProcess;
        global CURRENT_PARTITION;
        
        
        if CurrentProcess == ERROR_HANDLER_PROCESS_ID || CURRENT_PARTITION.OPERATING_MODE ~= OPERATING_MODE_TYPE.NORMAL
            LOCK_LEVEL = CURRENT_PARTITION.LOCK_LEVEL;
            RETURN_CODE = RETURN_CODE_TYPE.NO_ACTION;
            return;
        end
        
        
        if CURRENT_PARTITION.LOCK_LEVEL >= MAX_LOCK_LEVEL
            LOCK_LEVEL = CURRENT_PARTITION.LOCK_LEVEL;
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
            return;
        end
        
        CURRENT_PARTITION.LOCK_LEVEL = CURRENT_PARTITION.LOCK_LEVEL + 1;
        LOCK_LEVEL = CURRENT_PARTITION.LOCK_LEVEL;
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        return;
        
end

