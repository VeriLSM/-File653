function [ RETURN_CODE ] = RESUME( PROCESS_ID )

        global RETURN_CODE_TYPE;
        global PROCESS_STATE_TYPE;
        global Process_Set;
        global Waiting_Processes_Set;
        global Ready_Processes_Set;
        global Process_Waiting_Resource_Set;
        global PROCESS_SCHEDULING_FLAG;
        global CURRENT_PARTITION;
        global INFINITE_TIME_VALUE;

        %APEX_INTEGER index;
        index = GetProcessIndex(PROCESS_ID);
        %PROCESS_STATE_TYPE ProcessState;
        ProcessState = Process_Set{index,11};
        if index == 0 || ProcessState == PROCESS_STATE_TYPE.RUNNING
			RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
			return;
        end
        
        if ProcessState == PROCESS_STATE_TYPE.DORMANT
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
            return;
        end
        
        %SYSTEM_TIME_TYPE ProcessPeriod;
        ProcessPeriod = Process_Set{index,6};
        if ProcessPeriod ~= INFINITE_TIME_VALUE
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
            return;
        end
        
        %APEX_INTEGER flag;
        [flag,~] = ismember(PROCESS_ID,Waiting_Processes_Set);
        if flag == 0 
            RETURN_CODE = RETURN_CODE_TYPE.NO_ACTION;
            return;
        end
        
        if Process_Set{index,16} ~= 0
            Process_Set{index,16} = 0;
        end
        
        %APEX_INTEGER order;
        [order,~] = ismember(PROCESS_ID,Process_Waiting_Resource_Set);
        if order == 0
            Process_Set{index,11} = PROCESS_STATE_TYPE.READY;
            Waiting_Processes_Set=setdiff(Waiting_Processes_Set,PROCESS_ID);
            Ready_Processes_Set=union(Ready_Processes_Set,PROCESS_ID);
            if CURRENT_PARTITION.LOCK_LEVEL == 0
                PROCESS_SCHEDULING_FLAG = 1;
                schedule();
            end
        end
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        return;

end

