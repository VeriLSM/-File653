function [ ID ] = GenerateProcessId()

%APEX_INTEGER index;
%PROCESS_ID_TYPE ID;
index = CapacityofProcess();
ID = index * 1000 + randi(999);

return;

end

