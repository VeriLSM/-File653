function [ RETURN_CODE ] = STOP( PROCESS_ID )
    
        global PROCESS_STATE_TYPE;
        global RETURN_CODE_TYPE;
        global Process_Set;
        global Dormant_Processes_Set;
        global Ready_Processes_Set;
        global Waiting_Processes_Set;
        global Process_Waiting_Resource_Set;
        global CURRENT_PARTITION;
        global CurrentProcess;
        global PreviousProcess;
        global ERROR_HANDLER_PROCESS_ID;
        
       %APEX_INTEGER index; 
       index = GetProcessIndex(PROCESS_ID);
        if index == 0 || PROCESS_ID == CurrentProcess
			RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
			return;
        end

        %PROCESS_STATE_TYPE ProcessState;
        ProcessState = Process_Set{index,11};
        if ProcessState == PROCESS_STATE_TYPE.DORMANT 
            RETURN_CODE = RETURN_CODE_TYPE.NO_ACTION;
            return;
        end

        if ProcessState == PROCESS_STATE_TYPE.READY
            Ready_Processes_Set=setdiff(Ready_Processes_Set,PROCESS_ID);
        elseif ProcessState == PROCESS_STATE_TYPE.WAITING
            %APEX_INTEGER flag; 
            [flag,~] = ismember(PROCESS_ID,Process_Waiting_Resource_Set);
            if flag == 0
                Waiting_Processes_Set=setdiff(Waiting_Processes_Set,PROCESS_ID);
            else       
                Process_Waiting_Resource_Set=setdiff(Process_Waiting_Resource_Set,PROCESS_ID);
            end
        end
        Process_Set{index,14} = 0;
        Process_Set{index,15} = 0;
        Process_Set{index,16} = 0;
        Process_Set{index,11}=PROCESS_STATE_TYPE.DORMANT;
        Dormant_Processes_Set=union(Dormant_Processes_Set,PROCESS_ID);
        
        if CurrentProcess == ERROR_HANDLER_PROCESS_ID && PreviousProcess == PROCESS_ID
            CURRENT_PARTITION.LOCK_LEVEL = 0;
        end
        
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        return;
end

