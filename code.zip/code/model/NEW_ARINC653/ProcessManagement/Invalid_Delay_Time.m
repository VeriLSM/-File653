function [ flag ] = Invalid_Delay_Time( delay_time )

global CURRENT_PARTITION;
%APEX_INTEGER flag;
flag = 0;

if delay_time < 0 || delay_time > CURRENT_PARTITION.DURATION
    flag = 1;
end

return;

end

