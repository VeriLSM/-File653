function [ output ] =isProcessID(PROCESS_ID)
global Process_Set;
    ProcessIDSet = [Process_Set{:,1}];
    %APEX_INTEGER output;
    [output,~] = ismember(PROCESS_ID, ProcessIDSet);
    return;
end