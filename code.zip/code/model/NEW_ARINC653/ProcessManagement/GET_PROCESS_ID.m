function [PROCESS_ID,RETURN_CODE] = GET_PROCESS_ID (PROCESS_NAME)

        global RETURN_CODE_TYPE;
        global Process_Set;

        
        ProcessNameSet = {Process_Set{:,2}};
        %APEX_INTEGER index;
        [~,index] = ismember(PROCESS_NAME,ProcessNameSet);
        
        if index==0
            PROCESS_ID = -1;
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
            return;
        end
        
        PROCESS_ID = Process_Set{index,1};
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        
        return;

end
