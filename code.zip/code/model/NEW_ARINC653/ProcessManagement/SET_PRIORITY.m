function [RETURN_CODE]= SET_PRIORITY(PROCESS_ID,PRIORITY)

        global RETURN_CODE_TYPE;
        global PROCESS_STATE_TYPE;
        global Process_Set;
        global CURRENT_PARTITION;         
        global PROCESS_SCHEDULING_FLAG;

        %APEX_INTEGER index;
        index=GetProcessIndex(PROCESS_ID);
        if index == 0
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
            return;
        end

        if Invalid_Priority(PRIORITY) == 1
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;	
            return;
        end

        %PROCESS_STATE_TYPE ProcessState;
        ProcessState = Process_Set{index,11};
        if ProcessState == PROCESS_STATE_TYPE.DORMANT
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
            return;
        end

        Process_Set{index,9} = PRIORITY;

        if CURRENT_PARTITION.LOCK_LEVEL == 0
            PROCESS_SCHEDULING_FLAG = 1;
            schedule();
        end

        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        return;
         
end
	 
			
		 	
