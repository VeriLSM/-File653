function [ flag ] = Invalid_Period( period )

global INFINITE_TIME_VALUE;

%APEX_INTEGER flag;
flag = 0;

if period <= 0 && period ~= INFINITE_TIME_VALUE && period > 1000
    flag = 1;
end

return;

end

