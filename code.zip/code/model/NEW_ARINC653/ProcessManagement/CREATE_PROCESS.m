function  [PROCESS_ID,RETURN_CODE] = CREATE_PROCESS(ATTRIBUTES)
        global RETURN_CODE_TYPE;
        global OPERATING_MODE_TYPE;
        global PROCESS_STATE_TYPE;
        global CURRENT_PARTITION;
        global SYSTEM_NUMBER_OF_PROCESSES;
        global Process_Set;
        global Dormant_Processes_Set;
        global WAITING_RESOURCE_TYPE;
        
        %APEX_INTEGER Proindex;
        Proindex = CapacityofProcess();
        if Proindex == 0
            PROCESS_ID = -1;
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
            return;
        end 

        if isProcessName(ATTRIBUTES.NAME)==1
            PROCESS_ID = -1;
            RETURN_CODE = RETURN_CODE_TYPE.NO_ACTION;
            return;
        end

        if Invalid_Stack_Size(ATTRIBUTES.STACK_SIZE)==1
            PROCESS_ID = -1;            
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
            return;
        end

        if Invalid_Base_Priority(ATTRIBUTES.BASE_PRIORITY)==1
            PROCESS_ID = -1;            
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
            return;
        end

        if Invalid_Period(ATTRIBUTES.PERIOD)==1
            PROCESS_ID = -1;            
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
            return;
        elseif Invalid_Period(ATTRIBUTES.PERIOD) == 0 && isAperiodic(ATTRIBUTES.PERIOD) == 0 && mod(ATTRIBUTES.PERIOD,CURRENT_PARTITION.PERIOD) ~= 0
            PROCESS_ID = -1;            
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
            return;
        end

        if Invalid_Time_Capacity(ATTRIBUTES.TIME_CAPACITY)==1
            PROCESS_ID = -1;            
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
            return;
        end
        
        if Invalid_Period(ATTRIBUTES.PERIOD) == 0 && isAperiodic(ATTRIBUTES.PERIOD) == 0 && ATTRIBUTES.TIME_CAPACITY > ATTRIBUTES.PERIOD
            PROCESS_ID = -1;            
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
            return;
        end

        if CURRENT_PARTITION.OPERATING_MODE == OPERATING_MODE_TYPE.NORMAL
            PROCESS_ID = -1;            
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
            return;
        end
        
        %PROCESS_ID_TYPE ID;
        ID = GenerateProcessId();
        Process_Set{Proindex,1}=ID;
        Process_Set{Proindex,2}=ATTRIBUTES.NAME;
        Process_Set{Proindex,3}=ATTRIBUTES.ENTRY_POINT;
        Process_Set{Proindex,4}=ATTRIBUTES.STACK_SIZE;
        Process_Set{Proindex,5}=ATTRIBUTES.BASE_PRIORITY;
        Process_Set{Proindex,6}=ATTRIBUTES.PERIOD;
        Process_Set{Proindex,7}=ATTRIBUTES.TIME_CAPACITY;
        Process_Set{Proindex,8}=ATTRIBUTES.DEADLINE;
        Process_Set{Proindex,11}=PROCESS_STATE_TYPE.DORMANT;
        Process_Set{Proindex,12} = CURRENT_PARTITION.IDENTIFIER;
        Process_Set{Proindex,13} = WAITING_RESOURCE_TYPE.NOT_WAITING;
        Process_Set{Proindex,14} = 0;
        Process_Set{Proindex,15} = 0;
        Process_Set{Proindex,16} = 0;

        SYSTEM_NUMBER_OF_PROCESSES = SYSTEM_NUMBER_OF_PROCESSES + 1;
        Dormant_Processes_Set=union(Dormant_Processes_Set,ID);
        
        Initialize_Process_Context(ID);
        Initialize_Process_Stack(ID);

        PROCESS_ID = ID;
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;

end


