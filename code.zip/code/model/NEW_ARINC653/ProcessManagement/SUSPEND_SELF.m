function [ RETURN_CODE ] = SUSPEND_SELF( TIME_OUT )

        global RETURN_CODE_TYPE;
        global PROCESS_STATE_TYPE;
        global CURRENT_PARTITION;
        global Process_Set;
        global Waiting_Processes_Set;    
        global PROCESS_SCHEDULING_FLAG;
        global ERROR_HANDLER_PROCESS_ID;
        global INFINITE_TIME_VALUE;
        global CurrentProcess;

        if CURRENT_PARTITION.LOCK_LEVEL ~= 0 || CurrentProcess == ERROR_HANDLER_PROCESS_ID
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
            return;
        end

        if Invalid_Time_Out(TIME_OUT)==1
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
            return;
        end

       %APEX_INTEGER index;
       index = GetProcessIndex(CurrentProcess);
       %SYSTEM_TIME_TYPE ProcessPeriod;
        ProcessPeriod = Process_Set{index,6};
        if ProcessPeriod ~= INFINITE_TIME_VALUE
			RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
			return;
        end
        
        if TIME_OUT == 0
            RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
            return;
        else
            Process_Set{index,11} = PROCESS_STATE_TYPE.WAITING;
            Waiting_Processes_Set=union(Waiting_Processes_Set,CurrentProcess);
            if TIME_OUT ~= INFINITE_TIME_VALUE
               Process_Set{index,16} = GetTick() + TIME_OUT;
            end
            PROCESS_SCHEDULING_FLAG = 1;
            schedule();
            if GetTick() >= Process_Set{index,16} 
                 RETURN_CODE = RETURN_CODE_TYPE.TIMED_OUT;
                 return;
            else
                RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
                return;
            end
        end

end



