function [PROCESS_STATUS,RETURN_CODE] = GET_PROCESS_STATUS(PROCESS_ID)

        global RETURN_CODE_TYPE;
        global Process_Set;

        %APEX_INTEGER index;
        index = GetProcessIndex( PROCESS_ID );
        if index == 0
           PROCESS_STATUS.DEADLINE_TIME = -1;
           PROCESS_STATUS.CURRENT_PRIORITY = -1;
           PROCESS_STATUS.PROCESS_STATE = -1;
           RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;   
            return;
        end
       %PROCESS_ATTRIBUTE_TYPE attributes;
       attributes.NAME = Process_Set{index,2};
       attributes.ENTRY_POINT = Process_Set{index,3};
       attributes.STACK_SIZE  = Process_Set{index,4};
       attributes.BASE_PRIORITY = Process_Set{index,5};
       attributes.PERIOD = Process_Set{index,6};
       attributes.TIME_CAPACITY = Process_Set{index,7};
       attributes.DEADLINE = Process_Set{index,8};
       
       PROCESS_STATUS.CURRENT_PRIORITY = Process_Set{index,9};
       PROCESS_STATUS.DEADLINE_TIME = Process_Set{index,10};
       PROCESS_STATUS.PROCESS_STATE = Process_Set{index,11};
       PROCESS_STATUS.ATTRIBUTES = attributes;
       
       RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;

end	