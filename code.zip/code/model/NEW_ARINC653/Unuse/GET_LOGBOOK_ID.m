function [ LOGBOOK_ID,RETURN_CODE ] = GET_LOGBOOK_ID( LOGBOOK_NAME )
    global LOGBOOK_STATUS_TYPE;
    global CURRENT_PARTITION;

    
    if Invalid_Logbook_Name_is_Created(LOGBOOK_NAME) == 0 %��־δ����
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
    end
    
    

end

