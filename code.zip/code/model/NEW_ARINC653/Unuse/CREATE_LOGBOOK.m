function  [LOGBOOK_ID,RETURN_CODE] = CREATE_LOGBOOK(LOGBOOK_NAME,MAX_MESSAGE_SIZE,MAX_NB_LOGGED_MESSAGES,MAX_NB_IN_PROGRESS_MESSAGES)
    global LOGBOOK_STATUS_TYPE;
    global CURRENT_PARTITION;
    
    Logbookindex = CapacityofLogbook();
    if Logbookindex ==0
        LOGBOOK_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
    end
    
    if Invalid_Logbook_Name_in_Current_Partition_Configuration(LOGBOOK_NAME) == 0 %�����ñ��У���ǰ������û��logname��ʾ����־
        LOGBOOK_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
    end
    
    if Invalid_Logbook_Name_is_Created(LOGBOOK_NAME) == 1 %��־�Ѿ�����
        LOGBOOK_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.NO_ACTION;
    end
    
    if Invalid_Max_Message_Size(MAX_MESSAGE_SIZE) == 0
        LOGBOOK_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
    end
    
    if Invalid_Max_Nb_Logged_Messages(MAX_NB_LOGGED_MESSAGES) == 0
        LOGBOOK_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
    end
    
    if Invalid_Max_Nb_In_Progress_Messages(MAX_NB_IN_PROGRESS_MESSAGES) == 0
        LOGBOOK_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
    end
 
    if Invalid_Operating_Mode_is_Normal() == 0 % ��������normal����һ��ʲô��˼��
        LOGBOOK_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
    end
    
        
end