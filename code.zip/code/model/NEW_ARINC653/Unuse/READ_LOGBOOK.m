function [ LENGTH,WRITE_STATUS,RETURN_CODE ] = READ_LOGBOOK( LOGBOOK_ID,LOGBOOK_ENTRY,MESSAGE_ADDR )
    global LOGBOOK_STATUS_TYPE;
    global CURRENT_PARTITION;

    
    if Invalid_Logbook_Id_is_Created(LOGBOOK_ID) == 0 %��־δ����
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
    end
    
    if Invalid_Logbook_Entry(LOGBOOK_ENTRY) == 0 %logbook entry���ڻ����MAX_NB_LOGGED_MESSAGES
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
    end

    

end

