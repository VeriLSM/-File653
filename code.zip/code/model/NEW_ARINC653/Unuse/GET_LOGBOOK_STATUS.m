function [ LOGBOOK_STATUS,RETURN_CODE ] = GET_LOGBOOK_STATUS( LOGBOOK_ID,LENGTH )
    global LOGBOOK_STATUS_TYPE;
    global CURRENT_PARTITION;

    
    if Invalid_Logbook_Id_is_Created(LOGBOOK_ID) == 0 %��־δ����
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
    end
    
    

end

