function [ index ] = CapacityofLogbook()

    global MAX_Logbook_Number;
    global Current_Logbook_Number;


    %APEX_INTEGER index;
    if Current_Logbook_Number < MAX_Logbook_Number
        index = Current_Logbook_Number + 1;
        Current_Logbook_Number = index;
    else
        index = 0;
    end
    return;



end

