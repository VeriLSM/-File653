function [ RETURN_CODE ] = CLEAR_LOGBOOK( LOGBOOK_ID )
    global LOGBOOK_STATUS_TYPE;
    global CURRENT_PARTITION;

    
    if Invalid_Logbook_Id_is_Created(LOGBOOK_ID) == 0 %��־δ����
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
    end
    

    

end

