function [ RETURN_CODE ] = OVERWRITE_LOGBOOK( LOGBOOK_ID,MESSAGE_ADDR,LENGTH )
    global LOGBOOK_STATUS_TYPE;
    global CURRENT_PARTITION;

    
    if Invalid_Logbook_Id_is_Created(LOGBOOK_ID) == 0 %��־δ����
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
    end
    
    if Invalid_Max_Nb_in_Progress_Message() == 0 %MAX_NB_IN_PROGRESS_MESSAGESС��2
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
    end
    
    if Invalid_Logbook_Id_Length(LOGBOOK_ID,LENGTH) == 0 %��־����Ϊ0,���ߴ���MAX_MESSAGE_SIZE
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
    end

    
    
    
        

end

