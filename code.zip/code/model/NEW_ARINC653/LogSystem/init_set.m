function  [] = init_set()
    global Logbook_Set;
    global In_Progress_Log_Set;
    global Aborted_Log_Set;
    
        %APEX_INTEGER i;
        Logbook_Set = cell([MAX_NB_LOGGED_MESSAGES,1]);
        for i=1:MAX_NB_LOGGED_MESSAGES
            Logbook_Set{i,1} = "";
        end

        In_Progress_Log_Set = cell([MAX_NB_IN_PROGRESS_MESSAGES,1]);
        for i=1:MAX_NB_IN_PROGRESS_MESSAGES
            In_Progress_Log_Set{i,1} = "";
        end

        Aborted_Log_Set = cell([MAX_NB_ABORTED_MESSAGES_LIMITED,1]);
        for i=1:MAX_NB_ABORTED_MESSAGES_LIMITED
            Aborted_Log_Set{i,1} = "";
        end
    return;
end

