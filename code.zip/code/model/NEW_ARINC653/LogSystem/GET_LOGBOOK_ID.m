function [LOGBOOK_ID,RETURN_CODE] = GET_LOGBOOK_ID(LOGBOOK_NAME)
    global CURRENT_LOGBOOK_NAME;
    global RETURN_CODE_TYPE;
    global CURRENT_LOGBOOK_ID;
    
    if LOGBOOK_NAME ~= CURRENT_LOGBOOK_NAME
        LOGBOOK_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end
    
    if LOGBOOK_NAME == CURRENT_LOGBOOK_NAME
        LOGBOOK_ID = CURRENT_LOGBOOK_ID;
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        return;
    end
    
end

