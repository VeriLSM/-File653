function  [] = initialize_non_volatile_memory()
    

    return;
end