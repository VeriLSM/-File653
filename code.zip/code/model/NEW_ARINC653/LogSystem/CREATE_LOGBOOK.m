function [LOGBOOK_ID,RETURN_CODE] = CREATE_LOGBOOK(LOGBOOK_NAME,MAX_MESSAGE_SIZE,MAX_NB_LOGGED_MESSAGES,MAX_NB_IN_PROGRESS_MESSAGES)
    global RETURN_CODE_TYPE;
    global Logbook_Set;
    global In_Progress_Log_Set;
    global Aborted_Log_Set;
    global CURRENT_LOGBOOK_NAME;
    global CURRENT_LOGBOOK_ID;
    global CURRENT_MAX_MESSAGE_SIZE;
    global CURRENT_MAX_NB_LOGGED_MESSAGE;
    global CURRENT_MAX_NB_IN_PROGRESS_MESSAGES;
    global MAX_NB_ABORTED_MESSAGES_LIMITED;
    
    
    %APEX_INTEGER Logindex;
    Logindex = CapacityofLogbook();
    if Logindex == 0
        LOGBOOK_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end
    
    %APEX_INTEGER Logbook_Name_in_Configuration_Flag;
    Logbook_Name_in_Configuration_Flag = Invalid_Logbook_Name_in_Configuration(LOGBOOK_NAME);
    if Logbook_Name_in_Configuration_Flag == 0
        LOGBOOK_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end
    
    %APEX_INTEGER Logbook_Name_already_Created_Flag;
    Logbook_Name_already_Created_Flag = Invalid_Logbook_Name_already_Created(LOGBOOK_NAME);
    if Logbook_Name_already_Created_Flag == 0
        LOGBOOK_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end
    
    %APEX_INTEGER Max_Message_Size_Flag;
    Max_Message_Size_Flag = Invalid_Max_Message_Size(MAX_MESSAGE_SIZE);
    if Max_Message_Size_Flag == 0
        LOGBOOK_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end

    %APEX_INTEGER Max_nb_Logged_Messages_Flag;
    Max_nb_Logged_Messages_Flag = Invalid_Max_nb_Logged_Messages(MAX_NB_LOGGED_MESSAGES);
    if Max_nb_Logged_Messages_Flag == 0
        LOGBOOK_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end
    
    %APEX_INTEGER Max_nb_in_Progress_Message_Flag;
    Max_nb_in_Progress_Message_Flag = Invalid_Max_nb_in_Progress_Message(MAX_NB_IN_PROGRESS_MESSAGES);
    if Max_nb_in_Progress_Message_Flag == 0
        LOGBOOK_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end
    
    if Fileindex~=0 && Logbook_Name_in_Configuration_Flag~=0 && Logbook_Name_already_Created_Flag~=0 && Max_Message_Size_Flag~=0 && Max_nb_Logged_Messages_Flag~=0 && Max_nb_in_Progress_Message_Flag~=0
        initialize_non_volatile_memory();
        

        CURRENT_LOGBOOK_NAME = LOGBOOK_NAME;
        CURRENT_LOGBOOK_ID = Logindex;
        CURRENT_MAX_MESSAGE_SIZE = MAX_MESSAGE_SIZE;
        CURRENT_MAX_NB_LOGGED_MESSAGE = MAX_NB_LOGGED_MESSAGES;
        CURRENT_MAX_NB_IN_PROGRESS_MESSAGES = MAX_NB_IN_PROGRESS_MESSAGES;

        LOGBOOK_ID = Logindex;

        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        return;
    end
    
end

