function [RETURN_CODE] = SET_EVENT(EVENT_ID)

    global Event_Set;
    global RETURN_CODE_TYPE;
    global CURRENT_PARTITION;
    global Process_Set;
    global PROCESS_STATE_TYPE;
    global EVENT_STATE_TYPE;
    global Process_Waiting_Resource_Set;
    global Ready_Processes_Set;
    global WAITING_RESOURCE_TYPE;


    if isEventID(EVENT_ID) == 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    %APEX_INTEGER EvtIndex;
    EvtIndex = GetEventIndexById(EVENT_ID);
    Event_Set{EvtIndex,3} = EVENT_STATE_TYPE.UP;
    if Event_Set{EvtIndex,4} ~= 0
        %APEX_INTEGER i;
        i = 0;
        while i < Event_Set{EvtIndex,4}
            %PROCESS_ID_TYPE Revpid;
            Revpid = RemoveFromEvtque(EvtIndex);
            %APEX_INTEGER RevpidIndex;
            RevpidIndex = GetProcessIndex(Revpid);
            if Process_Set{RevpidIndex,16} ~= 0
                Process_Set{RevpidIndex,16} = 0;
            end
            %APEX_INTEGER flag;
            [flag,~] = ismember(Revpid,Waiting_Processes_Set);
            if flag == 0
                Process_Waiting_Resource_Set = setdiff(Process_Waiting_Resource_Set,Revpid);
                Process_Set{RevpidIndex,13} = WAITING_RESOURCE_TYPE.NOT_WAITING;
                Process_Set{RevpidIndex,11} = PROCESS_STATE_TYPE.READY;
                Ready_Processes_Set = union(Ready_Processes_Set,Revpid);
            end
            if CURRENT_PARTITION.LOCK_LEVEL == 0
                schedule();
            end
        end
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
    end

end


