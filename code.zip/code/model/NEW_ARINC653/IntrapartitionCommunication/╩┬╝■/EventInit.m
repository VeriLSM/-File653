global Event_Set;
Event_Set = cell(MAX_NUMBER_OF_EVENTS,5);

for k=1:MAX_NUMBER_OF_EVENTS
    Event_Set{k,2}='';
end

global SYSTEM_NUMBER_OF_EVENTS;
SYSTEM_NUMBER_OF_EVENTS = 0;