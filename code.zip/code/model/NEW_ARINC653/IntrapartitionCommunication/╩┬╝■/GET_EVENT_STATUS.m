function [EVENT_STATUS, RETURN_CODE] = GET_EVENT_STATUS(EVENT_ID)

    global Event_Set;
    global RETURN_CODE_TYPE;


    if isEventID(EVENT_ID) == 0
        EVENT_STATUS.EVENT_STATE = -1;
        EVENT_STATUS.WAITING_PROCESSES = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    %APEX_INTEGER Evtindex;
    Evtindex = GetEventIndexById(EVENT_ID);
    EVENT_STATUS.EVENT_STATE = Event_Set{Evtindex,3};
    EVENT_STATUS.WAITING_PROCESSES = Event_Set{Evtindex,4};
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
end