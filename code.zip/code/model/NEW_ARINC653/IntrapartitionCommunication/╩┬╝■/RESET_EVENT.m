function [RETURN_CODE] = RESET_EVENT(EVENT_ID)

    global RETURN_CODE_TYPE;
    global Event_Set;
    global EVENT_STATE_TYPE;


    if isEventID(EVENT_ID) == 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    %APEX_INTEGER EvtIndex;
    EvtIndex = GetEventIndexById(EVENT_ID);
    Event_Set{EvtIndex,3} = EVENT_STATE_TYPE.DOWN;
end
    