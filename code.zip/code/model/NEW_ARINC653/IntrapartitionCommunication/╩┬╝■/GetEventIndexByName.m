function [index] = GetEventIndexByName( EVENT_NAME )

global Event_Set;

    EventNameSet={Event_Set{:,2}};
    %APEX_INTEGER index;
    [~,index]=ismember(EVENT_NAME,EventNameSet);
    return;
    
end

