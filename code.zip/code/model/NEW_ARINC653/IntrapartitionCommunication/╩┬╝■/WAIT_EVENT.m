function [RETURN_CODE] = WAIT_EVENT(EVENT_ID,TIME_OUT)

    global Event_Set;
    global RETURN_CODE_TYPE;
    global CURRENT_PARTITION;
    global Process_Set;
    global PROCESS_STATE_TYPE;
    global EVENT_STATE_TYPE;
    global Process_Waiting_Resource_Set;
    global WAITING_RESOURCE_TYPE;
    global ERROR_HANDLER_PROCESS_ID;
    global CurrentProcess;
    global INFINITE_TIME_VALUE;

    if isEventID(EVENT_ID) == 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    if Invalid_Time_Out(TIME_OUT) == 1
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    %APEX_INTEGER EvtIndex;
    EvtIndex = GetEventIndexById(EVENT_ID);

    if Event_Set{EvtIndex,3} == EVENT_STATE_TYPE.UP
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        return;
    elseif TIME_OUT == 0
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        return;
    elseif CURRENT_PARTITION.LOCK_LEVEL ~= 0 || CurrentProcess == ERROR_HANDLER_PROCESS_ID
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        return;
    elseif TIME_OUT == INFINITE_TIME_VALUE
        %APEX_INTEGER Proindex;
        Proindex = GetProcessIndex(CurrentProcess);
        Process_Set{Proindex,11} = PROCESS_STATE_TYPE.WAITING;  
        Process_Set{Proindex,13} = WAITING_RESOURCE_TYPE.EVENT_WAITING;
        Process_Waiting_Resource_Set = union(Process_Waiting_Resource_Set,CurrentProcess);
        Event_Set{Blkbdindex,5} = union(Event_Set{Blkbdindex,5},CurrentProcess);
        Event_Set{Bufindex,4} = Event_Set{Bufindex,4} + 1;
        schedule();
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        return;
    else
        %APEX_INTEGER Proindex;
        Proindex = GetProcessIndex(CurrentProcess);
        Process_Set{Proindex,11} = PROCESS_STATE_TYPE.WAITING;                 
        Process_Set{Proindex,13} = WAITING_RESOURCE_TYPE.EVENT_WAITING;
        Process_Waiting_Resource_Set = union(Process_Waiting_Resource_Set,CurrentProcess); 
        Event_Set{EvtIndex,5} = union(Event_Set{EvtIndex,5},CurrentProcess);
        Event_Set{EvtIndex,4} = Event_Set{EvtIndex,4} + 1;
        Process_Set{Proindex,16} = GetTick() + TIME_OUT; 
        schedule();
        if  GetTick() >= Process_Set{Proindex,16}
            RETURN_CODE = RETURN_CODE_TYPE.TIMED_OUT;
            return;
        else
            RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
            return;
        end
    end
end
    

        
 
    

