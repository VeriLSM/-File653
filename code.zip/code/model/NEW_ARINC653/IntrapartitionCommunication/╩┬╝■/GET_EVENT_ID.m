function [EVENT_ID,RETURN_CODE] = GET_EVENT_ID(EVENT_NAME)

    global Event_Set;
    global RETURN_CODE_TYPE;



    if isEventName(EVENT_NAME)==0    
        EVENT_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end

    %APEX_INTEGER Evtindex;
    Evtindex = GetEventIndexByName(EVENT_NAME);
    EVENT_ID = Event_Set{Evtindex,1};
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;    
end