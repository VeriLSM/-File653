function [pid] = RemoveFromEvtque(Evtindex)
global Event_Set;
pid = Event_Set{Evtindex,5}(1);
Event_Set{Evtindex,5} = setdiff(Event_Set{Evtindex,5},Event_Set{Evtindex,5}(1));
Event_Set{Evtindex,4} = Event_Set{Evtindex,4} - 1;
end