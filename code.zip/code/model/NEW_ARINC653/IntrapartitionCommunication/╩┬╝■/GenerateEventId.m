function [ ID ] = GenerateEventId()

%APEX_INTEGER index;
%EVENT_ID_TYPE ID;
index = CapacityofEvent();
ID = index * 100 + randi(99);

return;

end

