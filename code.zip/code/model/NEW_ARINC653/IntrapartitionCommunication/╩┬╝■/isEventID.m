function [ output ] =isEventID(EVENT_ID)
global Event_Set;
    EventIDSet=[Event_Set{:,1}];
    %APEX_INTEGER output;
    [output,~] = ismember(EVENT_ID, EventIDSet);
    return;
end