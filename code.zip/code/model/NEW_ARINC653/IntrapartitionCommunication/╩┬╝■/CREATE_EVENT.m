function [EVENT_ID,RETURN_CODE] = CREATE_EVENT(EVENT_NAME)

    global Event_Set;
    global RETURN_CODE_TYPE;
    global OPERATING_MODE_TYPE;
    global CURRENT_PARTITION;
    global SYSTEM_NUMBER_OF_EVENTS;
    global EVENT_STATE_TYPE; 

    %APEX_INTEGER EvtIndex;
    EvtIndex = CapacityofEvent();
    if EvtIndex == 0
        EVENT_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end

    if isEventName(EVENT_NAME) == 1
        EVENT_ID = -1;        
        RETURN_CODE = RETURN_CODE_TYPE.NO_ACTION;
        return;
    end 

    if CURRENT_PARTITION.OPERATING_MODE == OPERATING_MODE_TYPE.NORMAL
        EVENT_ID = -1;   
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        return;
    end
    
    %EVENT_ID_TYPE EvtID;
    EvtID = GenerateEventId();
    Event_Set{SemIndex,1} = EvtID;
    Event_Set{SemIndex,2} = EVENT_NAME;
    Event_Set{SemIndex,3} = EVENT_STATE_TYPE.DOWN;
    Event_Set{SemIndex,4} = 0;
    
    SYSTEM_NUMBER_OF_EVENTS = SYSTEM_NUMBER_OF_EVENTS + 1;

    EVENT_ID = EvtID;
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
end










