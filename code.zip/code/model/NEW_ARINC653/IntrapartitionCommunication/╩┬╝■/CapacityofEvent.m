function [ index ] = CapacityofEvent()

    global SYSTEM_LIMIT_NUMBER_OF_EVENTS;
    global SYSTEM_NUMBER_OF_EVENTS;


    %APEX_INTEGER index;
    if SYSTEM_NUMBER_OF_EVENTS < SYSTEM_LIMIT_NUMBER_OF_EVENTS
        index = SYSTEM_NUMBER_OF_EVENTS + 1;
    else
        index = 0;
    end
    return;



end

