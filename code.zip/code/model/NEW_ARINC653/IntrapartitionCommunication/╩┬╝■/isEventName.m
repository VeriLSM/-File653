function [ output ] = isEventName( EVENT_NAME )

global Event_Set;

EventNameSet = {Event_Set{:,2}};
%APEX_INTEGER output;
[output,~] = ismember(EVENT_NAME,EventNameSet);

return;

end

