function [index] = GetEventIndexById( EVENT_ID )

global Event_Set;

    EventIDSet=[Event_Set{:,1}];
    %APEX_INTEGER index;
    [~,index]=ismember(EVENT_ID,EventIDSet);
    return;
    
end

