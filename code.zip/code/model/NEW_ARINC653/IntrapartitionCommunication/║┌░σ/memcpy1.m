function memcpy1 (dst, src, length)

global Blackboards_Data;
global Blackboard_Message_Data;

for i = 1 : length
    Blackboards_Data{dst,i} = Blackboard_Message_Data{src,i};
end

end