function [LENGTH,RETURN_CODE ] = READ_BLACKBOARD( BLACKBOARD_ID,TIME_OUT,MESSAGE_ADDR )

    global RETURN_CODE_TYPE;
    global Blackboard_Set;
    global CURRENT_PARTITION;
    global PROCESS_STATE_TYPE;
    global ERROR_HANDLER_PROCESS_ID;
    global INFINITE_TIME_VALUE;
    global EMPTY_INDICATOR_TYPE;
    global CurrentProcess;
    global Process_Waiting_Resource_Set;
    global Process_Set;
    global WAITING_RESOURCE_TYPE;



    if isBlackboardID(BLACKBOARD_ID) == 0
        LENGTH = 0;
        RETURN_CODE =  RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end
    
    if Invalid_Time_Out(TIME_OUT) == 1
        LENGTH = 0;
        RETURN_CODE =  RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    %APEX_INTEGER Blkbdindex;
    Blkbdindex = GetBlackboardIndexById(BLACKBOARD_ID);
    
    if Blackboard_Set{Blkbdindex,3} == EMPTY_INDICATOR_TYPE.OCCUPIED
        memcpy2(MESSAGE_ADDR,Blackboard_Set{Blkbdindex,6},Blackboard_Set{Blkbdindex,4});
        LENGTH = Blackboard_Set{Blkbdindex,4};
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        return;
    elseif TIME_OUT == 0
        LENGTH = 0;
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        return;
    elseif CURRENT_PARTITION.LOCK_LEVEL ~= 0 || CurrentProcess == ERROR_HANDLER_PROCESS_ID
        LENGTH = 0;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        return;
    elseif TIME_OUT == INFINITE_TIME_VALUE        
        %APEX_INTEGER Proindex;
        Proindex = GetProcessIndex(CurrentProcess);
        Process_Set{Proindex,11} = PROCESS_STATE_TYPE.WAITING;  
        Process_Set{Proindex,13} = WAITING_RESOURCE_TYPE.MESSAGE_WAITING;
        Process_Waiting_Resource_Set = union(Process_Waiting_Resource_Set,CurrentProcess);
        Blackboard_Set{Blkbdindex,7} = union(Blackboard_Set{Blkbdindex,7},CurrentProcess);
        Blackboard_Set{Blkbdindex,5} = Blackboard_Set{Blkbdindex,5} + 1;
        schedule();
        memcpy2(MESSAGE_ADDR,Blackboard_Set{Blkbdindex,6},Blackboard_Set{Blkbdindex,4});
        LENGTH = Blackboard_Set{Blkbdindex,4};
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        return;
    else        
        %APEX_INTEGER Proindex;
        Proindex = GetProcessIndex(CurrentProcess);
        Process_Set{Proindex,11} = PROCESS_STATE_TYPE.WAITING;  
        Process_Set{Proindex,13} = WAITING_RESOURCE_TYPE.MESSAGE_WAITING;
        Process_Waiting_Resource_Set = union(Process_Waiting_Resource_Set,CurrentProcess);
        Blackboard_Set{Blkbdindex,7} = union(Blackboard_Set{Blkbdindex,7},CurrentProcess);  
        Blackboard_Set{Blkbdindex,5} = Blackboard_Set{Blkbdindex,5} + 1;
        Process_Set{Proindex,16} = GetTick() + TIME_OUT; 
        schedule();
        if GetTick() >= Process_Set{Proindex,16}
            LENGTH = 0;
            RETURN_CODE = RETURN_CODE_TYPE.TIMED_OUT;
            return;
        else
            memcpy2(MESSAGE_ADDR,Blackboard_Set{Blkbdindex,6},Blackboard_Set{Blkbdindex,4});
            LENGTH = Blackboard_Set{Blkbdindex,4};
            RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
            return;
        end        
    end

end

