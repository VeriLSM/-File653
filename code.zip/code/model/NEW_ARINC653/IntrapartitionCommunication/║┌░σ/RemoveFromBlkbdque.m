function [pid] = RemoveFromBlkbdque(Blkbdindex)
global Blackboard_Set;
pid = Blackboard_Set{Blkbdindex,7}(1);
Blackboard_Set{Blkbdindex,7} = setdiff(Blackboard_Set{Blkbdindex,7},Blackboard_Set{Blkbdindex,7}(1));
Blackboard_Set{Bufindex,6} = Blackboard_Set{Bufindex,6} - 1;
end