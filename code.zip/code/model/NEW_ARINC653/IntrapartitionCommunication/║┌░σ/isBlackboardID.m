function [ output ] =isBlackboardID(BLACKBOARD_ID)
global Blackboard_Set;
    BlackboardIDSet=[Blackboard_Set{:,1}];
    %APEX_INTEGER output;
    [output,~] = ismember(BLACKBOARD_ID, BlackboardIDSet);
    return;
end