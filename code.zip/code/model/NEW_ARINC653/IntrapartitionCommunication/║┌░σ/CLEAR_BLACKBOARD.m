function [ RETURN_CODE ] = CLEAR_BLACKBOARD( BLACKBOARD_ID )

    global RETURN_CODE_TYPE;
    global Blackboard_Set;
    global EMPTY_INDICATOR_TYPE;

    if isBlackboardID(BLACKBOARD_ID) == 0
        RETURN_CODE =  RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    %APEX_INTEGER Blkbdindex;
    Blkbdindex = GetBlackboardIndexById(BLACKBOARD_ID);
    Blackboard_Set{Blkbdindex,3} = EMPTY_INDICATOR_TYPE.EMPTY;
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;

end

