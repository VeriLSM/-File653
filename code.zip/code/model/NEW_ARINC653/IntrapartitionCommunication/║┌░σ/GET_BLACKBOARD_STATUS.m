function [ BLACKBOARD_STATUS,RETURN_CODE  ] =  GET_BLACKBOARD_STATUS( BLACKBOARD_ID )

    global RETURN_CODE_TYPE;
    global Blackboard_Set;

    if isBlackboardID(BLACKBOARD_ID)
        BLACKBOARD_STATUS.EMPTY_INDICATOR = -1;
        BLACKBOARD_STATUS.MAX_MESSAGE_SIZE = -1;
        BLACKBOARD_STATUS.WAITING_PROCESSES = -1;
        RETURN_CODE =  RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    %APEX_INTEGER Blkbdindex;
    Blkbdindex = GetBlackboardIndexById(BLACKBOARD_ID);
    BLACKBOARD_STATUS.EMPTY_INDICATOR = Blackboard_Set{Blkbdindex,3};
    BLACKBOARD_STATUS.MAX_MESSAGE_SIZE = Blackboard_Set{Blkbdindex,4};
    BLACKBOARD_STATUS.WAITING_PROCESSES =  Blackboard_Set{Blkbdindex,5};
    
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;


end

