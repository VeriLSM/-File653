function  [BLACKBOARD_ID,RETURN_CODE] = CREATE_BLACKBOARD( BLACKBOARD_NAME,MAX_MESSAGE_SIZE )

        global RETURN_CODE_TYPE;
        global Blackboard_Set;
        global CURRENT_PARTITION;
        global SYSTEM_NUMBER_OF_BLACKBOARDS;
        global Blackboard_index;
        global EMPTY_INDICATOR_TYPE;
        global OPERATING_MODE_TYPE;


        %APEX_INTEGER Blkbdindex;
        Blkbdindex = CapacityofBlackboard();
        if Blkbdindex == 0
            BLACKBOARD_ID = -1;
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
            return;
        end
            
  		if isBlackboardName(BLACKBOARD_NAME) == 1 
            BLACKBOARD_ID = -1;
  			RETURN_CODE = RETURN_CODE_TYPE.NO_ACTION;
			return;
        end

        if Invalid_Max_Message_Size(MAX_MESSAGE_SIZE) == 1
            BLACKBOARD_ID = -1;
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
            return;
        end

        if CURRENT_PARTITION.OPERATING_MODE == OPERATING_MODE_TYPE.NORMAL
            BLACKBOARD_ID=-1;
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
            return;
        end

        %BLACKBOARD_ID_TYPE BlkbdID;
        BlkbdID = GenerateBlackboardId();
        Blackboard_Set{Blkbdindex,1} = BlkbdID;
        Blackboard_Set{Blkbdindex,2} = BLACKBOARD_NAME;
        Blackboard_Set{Blkbdindex,3} = EMPTY_INDICATOR_TYPE.EMPTY;
        Blackboard_Set{Blkbdindex,4} = MAX_MESSAGE_SIZE;
        Blackboard_Set{Blkbdindex,5} = 0;
        Blackboard_Set{Blkbdindex,6} = Blackboard_index;
        
        SYSTEM_NUMBER_OF_BLACKBOARDS = SYSTEM_NUMBER_OF_BLACKBOARDS + 1;
        Blackboard_index = Blackboard_index + MAX_MESSAGE_SIZE;
               	
        BLACKBOARD_ID = BlkbdID;
      	RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;

end

