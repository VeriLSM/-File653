global Blackboard_Set;
Blackboard_Set = cell(MAX_NUMBER_OF_BLACKBOARDS,7);

for k=1:MAX_NUMBER_OF_BLACKBOARDS
    Blackboard_Set{k,2}='';
end

global Blackboards_Data;
Blackboards_Data = cell(1,1024);

global Blackboard_Message_Data;
Blackboard_Message_Data = cell(1,1024);

global SYSTEM_NUMBER_OF_BLACKBOARDS;
SYSTEM_NUMBER_OF_BLACKBOARDS = 0;

global Blackboard_index;
Blackboard_index = 1;