function [BLACKBOARD_ID,RETURN_CODE ] = GET_BLACKBOARD_ID(BLACKBOARD_NAME )

    global RETURN_CODE_TYPE;
    global Blackboard_Set;


    if isBlackboardName(BLACKBOARD_NAME) == 0
        BLACKBOARD_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end
    
    %APEX_INTEGER Blkbdindex;
    Blkbdindex = GetBlackboardIndexByName(BUFFER_NAME);
    BLACKBOARD_ID  = Blackboard_Set{Blkbdindex,1};
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;


end


