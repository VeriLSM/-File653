function memcpy2 (dst, src, length)

global Blackboards_Data;
global Blackboard_Message_Data;

for i = 1 : length
    Blackboard_Message_Data{dst,i} = Blackboards_Data{src,i};
end

end