function [index] = GetBlackboardIndexById( BLACKBOARD_ID )

global Blackboard_Set;

    BlackboardIDSet=[Blackboard_Set{:,1}];
    %APEX_INTEGER index;
    [~,index]=ismember(BLACKBOARD_ID,BlackboardIDSet);
    return;
    
end

