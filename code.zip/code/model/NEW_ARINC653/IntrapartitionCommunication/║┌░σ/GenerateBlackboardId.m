function [ ID ] = GenerateBlackboardId()

%APEX_INTEGER index;
%BLACKBOARD_ID_TYPE ID;
index = CapacityofBlackboard();
ID = index * 100 + randi(99);

return;

end

