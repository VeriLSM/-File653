function [ output ] = isBlackboardName( BLACKBOARD_NAME )

global Blackboard_Set;

BlackboardNameSet = {Blackboard_Set{:,2}};
%APEX_INTEGER output;
[output,~] = ismember(BLACKBOARD_NAME,BlackboardNameSet);

return;

end

