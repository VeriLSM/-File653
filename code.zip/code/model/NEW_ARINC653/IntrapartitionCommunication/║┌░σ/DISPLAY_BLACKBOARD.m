function [ RETURN_CODE ] = DISPLAY_BLACKBOARD( BLACKBOARD_ID,MESSAGE_ADDR,LENGTH )

    global RETURN_CODE_TYPE;
    global Blackboard_Set;
    global CURRENT_PARTITION;
    global Process_Set;
    global PROCESS_STATE_TYPE;
    global EMPTY_INDICATOR_TYPE;
    global Process_Waiting_Resource_Set;
    global Waiting_Processes_Set;
    global Ready_Processes_Set;


    if isBlackboardID(BLACKBOARD_ID) == 0
       RETURN_CODE =  RETURN_CODE_TYPE.INVALID_PARAM;
	   return;
    end
  
    if LENGTH <= 0
        RETURN_CODE =  RETURN_CODE_TYPE.INVALID_PARAM;
		return;
    end
    
    %APEX_INTEGER Blkbdindex;
    Blkbdindex = GetBlackboardIndexById(BLACKBOARD_ID);
    if LENGTH > Blackboard_Set{Blkbdindex,4}
         RETURN_CODE =  RETURN_CODE_TYPE.INVALID_PARAM;
	     return;
    end
    
    Blackboard_Set{Blkbdindex,3} = EMPTY_INDICATOR_TYPE.OCCUPIED;
    memcpy1(Blackboard_Set{Blkbdindex,6},MESSAGE_ADDR,LENGTH);
    if Blackboard_Set{Blkbdindex,5} ~= 0
        %APEX_INTEGER i;
        i = 0;
        while i < Blackboard_Set{Blkbdindex,5}
            %PROCESS_ID_TYPE Revpid;
            Revpid = RemoveFromBlkbdque(Blkbdindex);
            %APEX_INTEGER RevpidIndex;
            RevpidIndex = GetProcessIndex(Revpid);
            if Process_Set{RevpidIndex,16} ~= 0
                Process_Set{RevpidIndex,16} = 0;
            end
            %APEX_INTEGER flag;
            [flag,~] = ismember(Revpid,Waiting_Processes_Set);
            if flag == 0
                Process_Waiting_Resource_Set = setdiff(Process_Waiting_Resource_Set,Revpid);
                Process_Set{RevpidIndex,13} = WAITING_RESOURCE_TYPE.NOT_WAITING;
                Process_Set{RevpidIndex,11} = PROCESS_STATE_TYPE.READY;
                Ready_Processes_Set = union(Ready_Processes_Set,Revpid);
            end
            i = i + 1;
            if CURRENT_PARTITION.LOCK_LEVEL == 0
                 schedule();
            end
        end
    end    
       
     RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
	


end

