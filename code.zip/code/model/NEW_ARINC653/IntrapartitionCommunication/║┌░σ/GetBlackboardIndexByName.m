function [index] = GetBlackboardIndexByName( BLACKBOARD_NAME )

global Blackboard_Set;

    BlackboardNameSet={Blackboard_Set{:,2}};
    %APEX_INTEGER index;
    [~,index]=ismember(BLACKBOARD_NAME,BlackboardNameSet);
    return;
    
end

