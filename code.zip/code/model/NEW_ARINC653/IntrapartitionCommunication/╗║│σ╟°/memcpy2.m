function memcpy2 (dst, src, length)

global Buffers_Data;
global Buffer_Message_Data;

for i = 1 : length
    Buffer_Message_Data{dst,i} = Buffers_Data{src,i};
end

end