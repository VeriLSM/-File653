function [ BUFFER_STATUS,RETURN_CODE] = GET_BUFFER_STATUS( BUFFER_ID )


global RETURN_CODE_TYPE;
global Buffer_Set;

if isBufferID(BUFFER_ID)==0
    BUFFER_STATUS.NB_MESSAGE = -1;        
    BUFFER_STATUS.MAX_NB_MESSAGE = -1; 
    BUFFER_STATUS.MAX_MESSAGE_SIZE = -1; 
    BUFFER_STATUS.WAITING_PROCESSES = -1;
    RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
    return;
end
    %APEX_INTEGER Bufindex;
    Bufindex = GetBufferIndexById(BUFFER_ID);
    BUFFER_STATUS.NB_MESSAGE = Buffer_Set{Bufindex,3};        
    BUFFER_STATUS.MAX_NB_MESSAGE = Buffer_Set{Bufindex,4}; 
    BUFFER_STATUS.MAX_MESSAGE_SIZE = Buffer_Set{Bufindex,5}; 
    BUFFER_STATUS.WAITING_PROCESSES = Buffer_Set{Bufindex,6};
   
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
   
end

