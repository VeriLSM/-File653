function [ output ] = isBufferName( BUFFER_NAME )

global Buffer_Set;

BufferNameSet = {Buffer_Set{:,2}};
%APEX_INTEGER output;
[output,~] = ismember(BUFFER_NAME,BufferNameSet);

return;

end

