function [ ID ] = GenerateBufferId()

%APEX_INTEGER index;
%BUFFER_ID_TYPE ID;
index = CapacityofBuffer();
ID = index * 100 + randi(99);

return;

end

