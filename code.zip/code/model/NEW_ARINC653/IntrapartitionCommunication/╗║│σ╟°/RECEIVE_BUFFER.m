function [LENGTH,RETURN_CODE]=RECEIVE_BUFFER ( BUFFER_ID, TIME_OUT, MESSAGE_ADDR)	
  		global PROCESS_STATE_TYPE;
        global RETURN_CODE_TYPE;
        global Buffer_Set;
        global CURRENT_PARTITION;
        global INFINITE_TIME_VALUE;
        global Process_Set;
        global Process_Waiting_Resource_Set;
        global Ready_Processes_Set;
        global ERROR_HANDLER_PROCESS_ID;
        global CurrentProcess;
        global WAITING_RESOURCE_TYPE;


  		if isBufferID(BUFFER_ID) == 0   
            LENGTH = 0;
			RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
			return;
        end
        
		if Invalid_Time_Out(TIME_OUT) == 1
            LENGTH = 0;
			RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
			return;
        end
        
        %APEX_INTEGER Bufindex;
        Bufindex = GetBufferIndexById(BUFFER_ID);
      	if Buffer_Set{Bufindex,8} == 0
            memcpy2(MESSAGE_ADDR,Buffer_Set{Bufindex,13} + Buffer_Set{Bufindex,11},Buffer_Set{Bufindex,5});
            Buffer_Set{Bufindex,3} = Buffer_Set{Bufindex,3} - 1;
            LENGTH = Buffer_Set{Bufindex,5};
            Buffer_Set{Bufindex,10} = mod(Buffer_Set{Bufindex,10} + LENGTH,Buffer_Set{Bufindex,12});
            if Buffer_Set{Bufindex,6} ~= 0
                %PROCESS_ID_TYPE Revpid;
                Revpid = RemoveFromBufque(Bufindex);
                %APEX_INTEGER RevpidIndex;
                RevpidIndex = GetProcessIndex(Revpid);
                if Process_Set{RevpidIndex,16} ~= 0
                    Process_Set{RevpidIndex,16} = 0;
                end
                %APEX_INTEGER flag;
                [flag,~] = ismember(Revpid,Waiting_Processes_Set);
                if flag == 0
                    Process_Waiting_Resource_Set = setdiff(Process_Waiting_Resource_Set,Revpid);
                    Process_Set{RevpidIndex,13} = WAITING_RESOURCE_TYPE.NOT_WAITING;
                    Process_Set{RevpidIndex,11} = PROCESS_STATE_TYPE.READY;
                    Ready_Processes_Set = union(Ready_Processes_Set,Revpid);
                end
                if CURRENT_PARTITION.LOCK_LEVEL == 0
                    schedule();
                end
            end
            if Buffer_Set{Bufindex,10} == Buffer_Set{Bufindex,11}
                Buffer_Set{Bufindex,8} = 1;
            end
            Buffer_Set{Bufindex,9} = 0;
            RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
            return;
        elseif TIME_OUT == 0
            LENGTH = 0;
            RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
            return;
        elseif CURRENT_PARTITION.LOCK_LEVEL ~= 0 || CurrentProcess == ERROR_HANDLER_PROCESS_ID
            LENGTH = 0;
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;    
            return;
        elseif TIME_OUT == INFINITE_TIME_VALUE
            %APEX_INTEGER Proindex;
            Proindex = GetProcessIndex(CurrentProcess);
            Process_Set{Proindex,11} = PROCESS_STATE_TYPE.WAITING;  
            Process_Set{Proindex,13} = WAITING_RESOURCE_TYPE.MESSAGE_WAITING;
            Process_Waiting_Resource_Set = union(Process_Waiting_Resource_Set,CurrentProcess);            
            Buffer_Set{Bufindex,14} = union(Buffer_Set{Bufindex,14},CurrentProcess);
            Buffer_Set{Bufindex,6} = Buffer_Set{Bufindex,6} + 1;
            schedule();
            LENGTH = Buffer_Set{Bufindex,5};
            RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
            return;
        else  
            %APEX_INTEGER Proindex;
            Proindex = GetProcessIndex(CurrentProcess);
            Process_Set{Proindex,11} = PROCESS_STATE_TYPE.WAITING; 
            Process_Set{Proindex,13} = WAITING_RESOURCE_TYPE.MESSAGE_WAITING;
            Process_Waiting_Resource_Set = union(Process_Waiting_Resource_Set,CurrentProcess);
            Buffer_Set{Bufindex,14} = union(Buffer_Set{Bufindex,14},CurrentProcess);
            Buffer_Set{Bufindex,6} = Buffer_Set{Bufindex,6} + 1;
            Process_Set{Proindex,16} = GetTick() + TIME_OUT; 
            schedule();
            if GetTick() >= Process_Set{Proindex,16}
                LENGTH = 0;
                RETURN_CODE = RETURN_CODE_TYPE.TIMED_OUT;
                return;
            else
                LENGTH = Buffer_Set{Bufindex,5};
                RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
                return;
            end
        end

end
