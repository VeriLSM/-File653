function [flag] = Invalid_Max_Message_Size(MAX_MESSAGE_SIZE)

%APEX_INTEGER flag;
flag = 0;
if MAX_MESSAGE_SIZE <= 0 
    flag = 1;
end

return;

end
