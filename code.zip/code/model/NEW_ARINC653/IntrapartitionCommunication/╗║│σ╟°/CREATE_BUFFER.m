function [BUFFER_ID,RETURN_CODE]=CREATE_BUFFER(BUFFER_NAME,MAX_MESSAGE_SIZE,MAX_NB_MESSAGE,QUEUING_DISCIPLINE)
        
        global SYSTEM_NUMBER_OF_BUFFERS;
        global RETURN_CODE_TYPE;
        global OPERATING_MODE_TYPE;
        global CURRENT_PARTITION;
        global Buffer_Set;
        global Buffer_index;
          
        %APEX_INTEGER Bufindex;
        Bufindex = CapacityofBuffer();
        if Bufindex == 0
            BUFFER_ID = -1;
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
            return;
        end
            
  		if isBufferName(BUFFER_NAME) == 1 
            BUFFER_ID = -1;
  			RETURN_CODE = RETURN_CODE_TYPE.NO_ACTION;
			return;
        end
        
        if Invalid_Max_Message_Size(MAX_MESSAGE_SIZE) == 1
		    BUFFER_ID=-1;
			RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
    		return;
        end
       
		if Invalid_Max_NB_Message(MAX_NB_MESSAGE) == 1
		    BUFFER_ID=-1;
			RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
    		return;
        end
            
		if Invalid_Queuing_Discipline(QUEUING_DISCIPLINE) == 1
		    BUFFER_ID=-1;
			RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
    		return;
        end
         
        if CURRENT_PARTITION.OPERATING_MODE == OPERATING_MODE_TYPE.NORMAL
            BUFFER_ID = -1;
    		RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
            return;
        end        
		
        %BUFFER_ID_TYPE BufID;
        BufID = GenerateBufferId();
        
        Buffer_Set{Bufindex,1} = BufID;
		Buffer_Set{Bufindex,2} = BUFFER_NAME;
		Buffer_Set{Bufindex,3} = 0;
		Buffer_Set{Bufindex,4} = MAX_NB_MESSAGE;
		Buffer_Set{Bufindex,5} = MAX_MESSAGE_SIZE;
		Buffer_Set{Bufindex,6} = 0;
		Buffer_Set{Bufindex,7} = QUEUING_DISCIPLINE; 		
  		Buffer_Set{Bufindex,8} = 1;  
        Buffer_Set{Bufindex,9} = 0; 
        Buffer_Set{Bufindex,10} = 0; 
        Buffer_Set{Bufindex,11} = 0; 
  		Buffer_Set{Bufindex,12} = MAX_NB_MESSAGE * MAX_MESSAGE_SIZE; 
  		Buffer_Set{Bufindex,13} = Buffer_index;
        
        SYSTEM_NUMBER_OF_BUFFERS = SYSTEM_NUMBER_OF_BUFFERS + 1;
        Buffer_index = Buffer_index + Buffer_Set{Bufindex,12};
        
        BUFFER_ID  = BufID;
   		RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        
end
