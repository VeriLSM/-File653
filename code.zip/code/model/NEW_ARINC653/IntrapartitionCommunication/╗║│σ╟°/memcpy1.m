function memcpy1 (dst, src, length)

global Buffers_Data;
global Buffer_Message_Data;

for i = 1 : length
    Buffers_Data{dst,i} = Buffer_Message_Data{src,i};
end

end