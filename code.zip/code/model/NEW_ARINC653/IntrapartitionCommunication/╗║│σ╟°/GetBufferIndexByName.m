function [index] = GetBufferIndexByName( BUFFER_NAME )

global Buffer_Set;

    BufferNameSet={Buffer_Set{:,2}};
    %APEX_INTEGER index;
    [~,index]=ismember(BUFFER_NAME,BufferNameSet);
    return;
    
end

