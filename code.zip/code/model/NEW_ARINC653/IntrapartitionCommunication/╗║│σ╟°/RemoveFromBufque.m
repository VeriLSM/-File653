function [pid] = RemoveFromBufque(Bufindex)
global Buffer_Set;
pid = Buffer_Set{Bufindex,14}(1);
Buffer_Set{Bufindex,14} = setdiff(Buffer_Set{Bufindex,14},Buffer_Set{Bufindex,14}(1));
Buffer_Set{Bufindex,6} = Buffer_Set{Bufindex,6} - 1;
end