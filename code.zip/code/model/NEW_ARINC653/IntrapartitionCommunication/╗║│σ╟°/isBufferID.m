function [ output ] =isBufferID(BUFFER_ID)
global Buffer_Set;
    BufferIDSet=[Buffer_Set{:,1}];
    %APEX_INTEGER output;
    [output,~] = ismember(BUFFER_ID, BufferIDSet);
    return;
end