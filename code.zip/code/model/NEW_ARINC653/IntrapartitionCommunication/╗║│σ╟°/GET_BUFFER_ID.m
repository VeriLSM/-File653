function [BUFFER_ID,RETURN_CODE]=GET_BUFFER_ID( BUFFER_NAME )
	global RETURN_CODE_TYPE;
    global Buffer_Set;
    
    if isBufferName(BUFFER_NAME) == 0
        BUFFER_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end

    %APEX_INTEGER index;
    index = GetBufferIndexByName(BUFFER_NAME);
    BUFFER_ID  = Buffer_Set{index,1};
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
end
        

