function [RETURN_CODE]=SEND_BUFFER (BUFFER_ID,MESSAGE_ADDR,LENGTH,TIME_OUT)

  		global PROCESS_STATE_TYPE;
        global CURRENT_PARTITION;
        global RETURN_CODE_TYPE;
        global Buffer_Set;
        global Process_Set;
        global ERROR_HANDLER_PROCESS_ID;
        global INFINITE_TIME_VALUE;
        global Process_Waiting_Resource_Set;
        global WAITING_RESOURCE_TYPE;
        global Waiting_Processes_Set;
        global Ready_Processes_Set;
        global CurrentProcess;

        
  		if isBufferID(BUFFER_ID) == 0   
			RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
			return;
        end
		 
        %APEX_INTEGER Bufindex;
        Bufindex = GetBufferIndexById(BUFFER_ID);
		if LENGTH > Buffer_Set{Bufindex,5}
			RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
			return;
        end
        
        if LENGTH <= 0
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
			return;
        end
        
		if Invalid_Time_Out(TIME_OUT) 
			RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
			return;
        end
  		
      	if Buffer_Set{Bufindex,9} == 0
            memcpy1(Buffer_Set{Bufindex,13} + Buffer_Set{Bufindex,11},MESSAGE_ADDR,LENGTH);
            Buffer_Set{Bufindex,3} = Buffer_Set{Bufindex,3} + 1;
            Buffer_Set{Bufindex,11} = mod(Buffer_Set{Bufindex,11} + LENGTH,Buffer_Set{Bufindex,12});
            if Buffer_Set{Bufindex,6} ~= 0
                %PROCESS_ID_TYPE Revpid;
                Revpid = RemoveFromBufque(Bufindex);
                %APEX_INTEGER RevpidIndex;
                RevpidIndex = GetProcessIndex(Revpid);
                if Process_Set{RevpidIndex,16} ~= 0
                    Process_Set{RevpidIndex,16} = 0;
                end
                %APEX_INTEGER flag;
                [flag,~] = ismember(Revpid,Waiting_Processes_Set);
                if flag == 0
                    Process_Waiting_Resource_Set = setdiff(Process_Waiting_Resource_Set,Revpid);
                    Process_Set{RevpidIndex,13} = WAITING_RESOURCE_TYPE.NOT_WAITING;
                    Process_Set{RevpidIndex,11} = PROCESS_STATE_TYPE.READY;
                    Ready_Processes_Set = union(Ready_Processes_Set,Revpid);
                end
                if CURRENT_PARTITION.LOCK_LEVEL == 0
                    schedule();
                end
            end
            if Buffer_Set{Bufindex,11} == Buffer_Set{Bufindex,10}
                Buffer_Set{Bufindex,9} = 1;
            end
            Buffer_Set{Bufindex,8} = 0;
            RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
            return;
        elseif TIME_OUT == 0
            RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
            return;
        elseif CURRENT_PARTITION.LOCK_LEVEL ~= 0 || CurrentProcess == ERROR_HANDLER_PROCESS_ID
            RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;    
            return;
        elseif TIME_OUT == INFINITE_TIME_VALUE
            %APEX_INTEGER Proindex;
            Proindex = GetProcessIndex(CurrentProcess);
            Process_Set{Proindex,11} = PROCESS_STATE_TYPE.WAITING;  
            Process_Set{Proindex,13} = WAITING_RESOURCE_TYPE.MESSAGE_WAITING;
            Process_Waiting_Resource_Set = union(Process_Waiting_Resource_Set,CurrentProcess);            
            Buffer_Set{Bufindex,14} = union(Buffer_Set{Bufindex,14},CurrentProcess);
            Buffer_Set{Bufindex,6} = Buffer_Set{Bufindex,6} + 1;
            schedule();
            RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
            return;
        else            
            %APEX_INTEGER Proindex;
            Proindex = GetProcessIndex(CurrentProcess);
            Process_Set{Proindex,11} = PROCESS_STATE_TYPE.WAITING; 
            Process_Set{Proindex,13} = WAITING_RESOURCE_TYPE.MESSAGE_WAITING;
            Process_Waiting_Resource_Set = union(Process_Waiting_Resource_Set,CurrentProcess);
            Buffer_Set{Bufindex,14} = union(Buffer_Set{Bufindex,14},CurrentProcess);
            Buffer_Set{Bufindex,6} = Buffer_Set{Bufindex,6} + 1;
            Process_Set{Proindex,16} = GetTick() + TIME_OUT; 
            schedule();
            if GetTick() >= Process_Set{Proindex,16}
                RETURN_CODE = RETURN_CODE_TYPE.TIMED_OUT;
                return;
            else
                RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
                return;
            end
        end
end
            


