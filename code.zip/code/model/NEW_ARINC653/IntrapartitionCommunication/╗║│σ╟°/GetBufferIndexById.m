function [index] = GetBufferIndexById( BUFFER_ID )

global Buffer_Set;

    BufferIDSet=[Buffer_Set{:,1}];
    %APEX_INTEGER index;
    [~,index]=ismember(BUFFER_ID,BufferIDSet);
    return;
    
end

