global Buffer_Set;
Buffer_Set = cell(MAX_NUMBER_OF_BUFFERS,14);

for k=1:MAX_NUMBER_OF_BUFFERS
    Buffer_Set{k,2}='';
end

global SYSTEM_NUMBER_OF_BUFFERS;
SYSTEM_NUMBER_OF_BUFFERS = 0;

global Buffers_Data;
Buffers_Data = cell(1,1024);

global Buffer_Message_Data;
Buffer_Message_Data = cell(1,1024);

global Buffer_index;
Buffer_index = 1;


