function [pid] = RemoveFromSemque(Semindex)
global Semaphore_Set;
pid = Semaphore_Set{Semindex,7}(1);
Semaphore_Set{Semindex,7} = setdiff(Semaphore_Set{Semindex,7},Semaphore_Set{Semindex,7}(1));
Semaphore_Set{Semindex,6} = Semaphore_Set{Semindex,6} - 1;
end