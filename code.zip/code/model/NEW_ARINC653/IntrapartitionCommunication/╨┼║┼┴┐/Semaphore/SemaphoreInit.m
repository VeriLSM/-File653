global Semaphore_Set;
Semaphore_Set = cell(MAX_NUMBER_OF_SEMAPHORES,7);

for k=1:MAX_NUMBER_OF_SEMAPHORES
    Semaphore_Set{k,2}='';
end

global SYSTEM_NUMBER_OF_SEMAPHORES;
SYSTEM_NUMBER_OF_SEMAPHORES = 0;