function [ index ] = CapacityofSemaphore()

    global SYSTEM_LIMIT_NUMBER_OF_SEMAPHORES;
    global SYSTEM_NUMBER_OF_SEMAPHORES;


    %APEX_INTEGER index;
    if SYSTEM_NUMBER_OF_SEMAPHORES < SYSTEM_LIMIT_NUMBER_OF_SEMAPHORES
        index = SYSTEM_NUMBER_OF_SEMAPHORES + 1;
    else
        index = 0;
    end
    return;



end

