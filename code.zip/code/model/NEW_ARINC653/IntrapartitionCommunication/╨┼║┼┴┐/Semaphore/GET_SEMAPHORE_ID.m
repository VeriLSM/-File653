function [ SEMAPHORE_ID,RETURN_CODE ] = GET_SEMAPHORE_ID( SEMAPHORE_NAME )

    global RETURN_CODE_TYPE;
    global Semaphore_Set;


    if isSemaphoreName(SEMAPHORE_NAME) == 0
        SEMAPHORE_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end

    %APEX_INTEGER Semindex;
    Semindex = GetSemaphoreIndexByName(SEMAPHORE_NAME);
    SEMAPHORE_ID = Semaphore_Set{Semindex,1};
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;

end

