function [index] = GetSemaphoreIndexByName( SEMAPHORE_NAME )

global Semaphore_Set;

    SemaphoreNameSet={Semaphore_Set{:,2}};
    %APEX_INTEGER index;
    [~,index]=ismember(SEMAPHORE_NAME,SemaphoreNameSet);
    return;
    
end

