function [ RETURN_CODE ] = SIGNAL_SEMAPHORE( SEMAPHORE_ID )

    global RETURN_CODE_TYPE;
    global Semaphore_Set;
    global CURRENT_PARTITION;
    global Process_Set;
    global Process_Waiting_Resource_Set;
    global Ready_Processes_Set;
    global PROCESS_STATE_TYPE;
    global WAITING_RESOURCE_TYPE;
 
    if isSemaphoreID(SEMAPHORE_ID) == 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    %APEX_INTEGER SemIndex;
    SemIndex = GetSemaphoreIndexById(SEMAPHORE_ID);

    if Semaphore_Set{SemIndex,3} == Semaphore_Set{SemIndex,4}
        RETURN_CODE = RETURN_CODE_TYPE.NO_ACTION;
        return;
    end

    if Semaphore_Set{SemIndex,6} == 0
        Semaphore_Set{SemIndex,3} = Semaphore_Set{SemIndex,3} + 1;
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        return;
    else
        %PROCESS_ID_TYPE Revpid;
        Revpid = RemoveFromSemque(SemIndex);
        %APEX_INTEGER RevpidIndex;
        RevpidIndex = GetProcessIndex(Revpid);
        if Process_Set{RevpidIndex,16} ~= 0
            Process_Set{RevpidIndex,16} = 0;
        end
        %APEX_INTEGER flag;
        [flag,~] = ismember(Revpid,Waiting_Processes_Set);
        if flag == 0
            Process_Waiting_Resource_Set = setdiff(Process_Waiting_Resource_Set,Revpid);
            Process_Set{RevpidIndex,13} = WAITING_RESOURCE_TYPE.NOT_WAITING;
            Process_Set{RevpidIndex,11} = PROCESS_STATE_TYPE.READY;
            Ready_Processes_Set = union(Ready_Processes_Set,Revpid);
        end
        if CURRENT_PARTITION.LOCK_LEVEL == 0
            schedule();
        end
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
    end
       
end

