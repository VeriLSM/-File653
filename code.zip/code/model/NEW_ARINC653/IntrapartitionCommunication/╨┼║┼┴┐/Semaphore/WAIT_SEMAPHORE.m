function [ RETURN_CODE ] = WAIT_SEMAPHORE( SEMAPHORE_ID,TIME_OUT )

    global RETURN_CODE_TYPE;
    global PROCESS_STATE_TYPE;
    global Semaphore_Set;
    global CURRENT_PARTITION;
    global CurrentProcess;
    global INFINITE_TIME_VALUE;
    global ERROR_HANDLER_PROCESS_ID;
    global Process_Waiting_Resource_Set;
    global Process_Set;
    global WAITING_RESOURCE_TYPE;


    if isSemaphoreID(SEMAPHORE_ID) == 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    if Invalid_Time_Out(TIME_OUT) == 1
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    %APEX_INTEGER SemIndex;
    SemIndex = GetSemaphoreIndexById(SEMAPHORE_ID);

    if Semaphore_Set{SemIndex,3} > 0
        Semaphore_Set{SemIndex,3} = Semaphore_Set{SemIndex,3} - 1;
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        return;
    elseif TIME_OUT == 0
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        return;
    elseif CURRENT_PARTITION.LOCK_LEVEL > 0 || CurrentProcess == ERROR_HANDLER_PROCESS_ID
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        return;
    elseif TIME_OUT == INFINITE_TIME_VALUE
        %APEX_INTEGER Proindex;
        Proindex = GetProcessIndex(CurrentProcess);
        Process_Set{Proindex,11} = PROCESS_STATE_TYPE.WAITING;                 
        Process_Set{Proindex,13} = WAITING_RESOURCE_TYPE.SEMAPHORE_WAITING;
        Process_Waiting_Resource_Set = union(Process_Waiting_Resource_Set,CurrentProcess); 
        Semaphore_Set{SemIndex,7} = union(Semaphore_Set{SemIndex,7},CurrentProcess);
        Semaphore_Set{SemIndex,6} = Semaphore_Set{SemIndex,6} + 1;
        schedule();
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        return;
    else
        %APEX_INTEGER Proindex;
        Proindex = GetProcessIndex(CurrentProcess);
        Process_Set{Proindex,11} = PROCESS_STATE_TYPE.WAITING;                 
        Process_Set{Proindex,13} = WAITING_RESOURCE_TYPE.SEMAPHORE_WAITING;
        Process_Waiting_Resource_Set = union(Process_Waiting_Resource_Set,CurrentProcess); 
        Semaphore_Set{SemIndex,7} = union(Semaphore_Set{SemIndex,7},CurrentProcess);
        Semaphore_Set{SemIndex,6} = Semaphore_Set{SemIndex,6} + 1;
        Process_Set{Proindex,16} = GetTick() + TIME_OUT; 
        schedule();
        if  GetTick() >= Process_Set{Proindex,16}
            RETURN_CODE = RETURN_CODE_TYPE.TIMED_OUT;
            return;
        else
            RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
            return;
        end
    end

end

