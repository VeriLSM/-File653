function  [SEMAPHORE_ID,RETURN_CODE] = CREATE_SEMAPHORE( SEMAPHORE_NAME,CURRENT_VALUE,MAXIMUM_VALUE,QUEUING_DISCIPLINE )

    global RETURN_CODE_TYPE;
    global OPERATING_MODE_TYPE;
    global Semaphore_Set;
    global CURRENT_PARTITION;
    global MAX_SEMAPHORE_VALUE;
    global SYSTEM_NUMBER_OF_SEMAPHORES;


    %APEX_INTEGER SemIndex;
    SemIndex = CapacityofSemaphore();
    if SemIndex == 0
        SEMAPHORE_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        return;
    end

    if isSemaphoreName(SEMAPHORE_NAME) == 1
        SEMAPHORE_ID = -1;        
        RETURN_CODE = RETURN_CODE_TYPE.NO_ACTION;
        return;
    end 

    if CURRENT_VALUE < 0 || CURRENT_VALUE > MAX_SEMAPHORE_VALUE
        SEMAPHORE_ID = -1;        
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    if MAXIMUM_VALUE < 0 || MAXIMUM_VALUE > MAX_SEMAPHORE_VALUE
        SEMAPHORE_ID = -1;        
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    if CURRENT_VALUE > MAXIMUM_VALUE
        SEMAPHORE_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;        
        return;
    end

    if Invalid_Queuing_Discipline(QUEUING_DISCIPLINE) == 1
        SEMAPHORE_ID = -1;      
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    if CURRENT_PARTITION.OPERATING_MODE == OPERATING_MODE_TYPE.NORMAL
        SEMAPHORE_ID = -1;   
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        return;
    end

    %SEMAPHORE_ID_TYPE SemID;
    SemID = GenerateSemaphoreId();
    Semaphore_Set{SemIndex,1} = SemID;
    Semaphore_Set{SemIndex,2} = SEMAPHORE_NAME;
    Semaphore_Set{SemIndex,3} = CURRENT_VALUE;
    Semaphore_Set{SemIndex,4} = MAXIMUM_VALUE;
    Semaphore_Set{SemIndex,5} = QUEUING_DISCIPLINE;
    Semaphore_Set{SemIndex,6} = 0;

    
    SYSTEM_NUMBER_OF_SEMAPHORES = SYSTEM_NUMBER_OF_SEMAPHORES + 1;

    SEMAPHORE_ID = SemID;
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;

end

