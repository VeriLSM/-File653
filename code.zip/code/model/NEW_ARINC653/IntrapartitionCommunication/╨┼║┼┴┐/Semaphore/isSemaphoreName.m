function [ output ] = isSemaphoreName( SEMAPHORE_NAME )

global Semaphore_Set;

SemaphoreNameSet = {Semaphore_Set{:,2}};
%APEX_INTEGER output;
[output,~] = ismember(SEMAPHORE_NAME,SemaphoreNameSet);

return;

end

