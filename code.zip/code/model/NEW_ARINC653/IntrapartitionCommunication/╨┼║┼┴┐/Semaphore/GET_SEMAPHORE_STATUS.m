function [ SEMAPHORE_STATUS,RETURN_CODE  ] = GET_SEMAPHORE_STATUS( SEMAPHORE_ID )

    global RETURN_CODE_TYPE;
    global Semaphore_Set;

    if isSemaphoreID(SEMAPHORE_ID) == 0
        SEMAPHORE_STATUS.CURRENT_VALUE = -1;
        SEMAPHORE_STATUS.MAXIMUM_VALUE = -1;
        SEMAPHORE_STATUS.WAITING_PROCESSES = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    %APEX_INTEGER Semindex;
    Semindex = GetSemaphoreIndexById(SEMAPHORE_ID);
    SEMAPHORE_STATUS.CURRENT_VALUE = Semaphore_Set{Semindex,3};
    SEMAPHORE_STATUS.MAXIMUM_VALUE = Semaphore_Set{Semindex,4};
    SEMAPHORE_STATUS.WAITING_PROCESSES =  Semaphore_Set{Semindex,6};
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;

end

