function [ ID ] = GenerateSemaphoreId()

%APEX_INTEGER index;
%SEMAPHORE_ID_TYPE ID;
index = CapacityofBuffer();
ID = index * 100 + randi(99);

return;

end

