function [index] = GetSemaphoreIndexById( SEMAPHORE_ID )

global Semaphore_Set;

    SemaphoreIDSet=[Semaphore_Set{:,1}];
    %APEX_INTEGER index;
    [~,index]=ismember(SEMAPHORE_ID,SemaphoreIDSet);
    return;
    
end

