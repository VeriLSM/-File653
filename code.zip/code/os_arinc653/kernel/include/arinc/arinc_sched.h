#ifndef __L_ARINC_SCHED_H
#define __L_ARINC_SCHED_H

#include <sched.h>

extern struct sched_class arinc_sched_class;


#endif