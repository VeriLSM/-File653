#ifndef __L_U_ARINC_PROCESS_H
#define __L_U_ARINC_PROCESS_H

#include <apex.h>
#include <defs.h>
#include <proc.h>
#include <partition.h>

#define MAX_NUMBER_OF_PROCESSES SYSTEM_LIMIT_NUMBER_OF_PROCESSES

#define MIN_PRIORITY_VALUE 1

#define MAX_PRIORITY_VALUE 239

#define MAX_STACK_SIZE  (4096 * 20)

#define MAX_PROC_PERIOD 1000

#define MAX_TIME_CAPA 1000

#define MAX_LOCK_LEVEL 16

typedef enum {
    DORMANT = 0,
    READY = 1,
    RUNNING = 2,
    WAITING = 3
} process_state_type;

typedef enum {
    SOFT = 0,
    HARD = 1
} deadline_type;

typedef process_state_type process_state_t;

typedef deadline_type   deadline_t;

typedef name_t  process_name_t;

typedef apex_integer_t  process_id_t;

typedef apex_unsigned_t stack_size_t;

typedef apex_integer_t  priority_t;

typedef struct {
    system_time_t       period;
    system_time_t       time_capacity;
    system_address_t    entry_point;
    stack_size_t        stack_size;
    priority_t          base_priority;
    deadline_t          deadline;
    process_name_t      name;
} process_attribute_type;

typedef process_attribute_type  process_attribute_t;

#define DEFAULT_ATTR(_entry, _name) {\
    .period = INFINITE_TIME_VALUE,  \
    .time_capacity = 5,\
    .entry_point = _entry, \
    .stack_size = 4 * 4096, \
    .base_priority = 1, \
    .deadline = SOFT,   \
    .name = _name,  \
}

typedef struct {
    system_time_t       deadline_time;
    priority_t          current_priority;
    process_state_t     process_state;
    process_attribute_t attributes;
} process_status_type;

typedef process_status_type process_status_t;

extern int arinc_lock_level;

#define PREEMPTION (!((partition_t*)current->part)->status.lock_level) 

void do_create_process(process_attribute_t *attributes, 
                    process_id_t *process_id,   
                    return_code_t *return_code);

void do_set_priority(process_id_t process_id,
                    priority_t priority,
                    return_code_t *return_code);

void do_suspend_self(system_time_t time_out,
                    return_code_t *return_code);
            
void do_suspend(process_id_t process_id, return_code_t *return_code);

void do_resume(process_id_t process_id, return_code_t *return_code);

void do_stop_self(void);

void do_stop(process_id_t process_id, return_code_t *return_code);

void do_start(process_id_t process_id, return_code_t *return_code);

void do_delayed_start(process_id_t process_id,
                    system_time_t delay_time,
                    return_code_t *return_code);

void do_lock_preemption(lock_level_t *lock_level, return_code_t *return_code);

void do_unlock_preemption(lock_level_t *lock_level, return_code_t *return_code);

void do_get_my_id(process_id_t *process_id, return_code_t *return_code);

void do_get_process_id(process_name_t  process_name,
                    process_id_t    *process_id,
                    return_code_t   *return_code);

void do_get_process_status(process_id_t process_id,
                    process_status_t    *process_status,
                    return_code_t       *return_code);


#endif