#!/usr/bin/env python
# -*- coding: utf-8 -*-

# @Time    : 2018/6/2 21:42
# @Author  : ethanw
# @Mail    ：ethan_w@aliyun.com
# @Describe: 提供保存M*和MISRA-C层级编码的字符串缓冲区以及将字符串存入文件

import os

class Hierarchy(object):
    def __init__(self):
        '''
        初始化
        '''
        self.fileName = 'h_test'
        self.cHierCode = ''  # c层级编码
        self.cFile = ''  # c层级编码头文件
        self.globalVar = ''  # c层级编码全局变量
        self.globalVarEx = ''  # c层级编码extern全局变量
        self.functionString = ''  # c层级编码定义的函数
        self.statfunctionString = ''  # c层级编码定义的static函数
        self.mHierCode = ''  # M*层级编码
        self.globalStat = dict()  # 记录全局变量，防止重复
        self.root = './gen/'
        self._add_cFile()
        self._add_global_statement()

    def _add_cFile(self):
        '''
        include入合适的库
        :return:
        '''
        self.cFile += '#include \"arinc_fs.h\"\n'
        self.cFile += '#include \"libc.h\"\n'
        self.cFile += '#include \"types.h\"\n'

    def _add_global_statement(self):
        '''
        记录全局变量，防止重复
        :return:
        '''
        file = self.fileName + '.h'
        if file not in self.globalStat:
            self.globalStat[file] = True

    def add_global_statement(self,globalstat):
        if globalstat in self.globalStat:
            return False
        else:
            self.globalStat[globalstat] = True
            return True

    def get_file_name(self):
        return self.fileName

    def set_file_name(self,filename):
        self.fileName = filename

    def add_cFile(self,cFile):
        '''
        缓冲区加入信息
        :param cFile:
        :return:
        '''
        self.cFile += cFile + '\n'

    def add_global_var(self, globalVar):
        '''
        全局变量缓冲区添加
        :param globalVar:
        :return:
        '''
        self.globalVar += globalVar + '\n'

    def add_global_var_ex(self,globalVarEx):
        '''
        extern全局变量添加
        :param globalVarEx:
        :return:
        '''
        self.globalVarEx += globalVarEx + '\n'

    def add_function_string(self,functionString):
        '''
        ARINC 653服务函数添加
        :param functionString:
        :return:
        '''
        self.functionString += functionString + '\n'

    def add_static_function_string(self,staticfunctionString):
        '''
        功能函数添加为静态函数
        :param staticfunctionString:
        :return:
        '''
        self.statfunctionString += staticfunctionString + '\n'

    def add_c_hier_code(self):
        '''
        所有c的层级编码的结果缓存在cHierCode
        :return:
        '''
        self.cHierCode += self.cFile + '\n'
        self.cHierCode += self.globalVar + '\n'
        self.cHierCode += self.globalVarEx + '\n'
        self.cHierCode += self.statfunctionString + '\n'
        self.cHierCode += self.functionString + '\n'

    def add_m_hier_code(self,mHierCode):
        '''
        添加m层级编码
        :param mHierCode:
        :return:
        '''
        self.mHierCode += mHierCode + '\n'

    def clear(self):
        '''
        清空
        :return:
        '''
        self.cFile = ''
        self.globalVar = ''
        self.globalVarEx = ''
        self.functionString = ''
        self.statfunctionString = ''

    def to_c_string(self):
        '''
        打印输出
        :return:
        '''
        print(self.cFile)
        print('\n')
        print(self.globalVar)
        print('\n')
        print(self.globalVarEx)
        print('\n')
        print(self.statfunctionString)
        print('\n')
        print(self.functionString)

    def to_hier_file(self):
        '''
        输出c和m的层级编码,强制覆盖
        :return:
        '''
        c_path = self.root + 'hier_c/'
        m_path = self.root + 'hier_m/'
        if not os.path.exists(c_path):
            os.mkdir(c_path)
        if not os.path.exists(m_path):
            os.mkdir(m_path)
        target_c_path = c_path + self.fileName + '.c'
        target_m_path = m_path + self.fileName + '.m'
        self.add_c_hier_code()
        with open(target_c_path,'w',encoding='utf-8') as f_c:
            f_c.write(self.cHierCode)
            f_c.write('\n')
            print('{} : success'.format(target_c_path))

        with open(target_m_path,'w',encoding='utf-8') as f_m:
            f_m.write(self.mHierCode)
            f_m.write('\n')
            print('{} : success'.format(target_m_path))

    def to_hier_file_uncovered(self):
        '''
        输出c和m的层级编码，但不覆盖
        :return:
        '''
        c_path = self.root + 'hier_c/'
        m_path = self.root + 'hier_m/'
        if not os.path.exists(c_path):
            os.mkdir(c_path)
        if not os.path.exists(m_path):
            os.mkdir(m_path)
        target_c_path = c_path + self.fileName + '.c'
        target_m_path = m_path + self.fileName + '.m'
        if os.path.exists(target_c_path):
            print('{} already exist !'.format(target_c_path))
        else:
            self.add_c_hier_code()
            with open(target_c_path,'w',encoding='utf-8') as f_c:
                f_c.write(self.cHierCode)
                f_c.write('\n')
                print('{} : success'.format(target_c_path))

        if os.path.exists(target_m_path):
            print('{} already exist !'.format(target_m_path))
        else:
            with open(target_m_path,'w',encoding='utf-8') as f_m:
                f_m.write(self.mHierCode)
                f_m.write('\n')
                print('{} : success'.format(target_m_path))
