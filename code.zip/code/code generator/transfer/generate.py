#!/usr/bin/env python
# -*- coding: utf-8 -*-

# @Time    : 2018/6/2 21:17
# @Author  : ethanw
# @Mail    ：ethan_w@aliyun.com
# @Describe: 主函数

import os,time
from antlr4 import *
from MatlabLexer import MatlabLexer
from MatlabParser import MatlabParser
from Matlab2CVisitor import Matlab2CVisitor


class Matlab2C(object):
    def __init__(self):
        self.mat2cvi = Matlab2CVisitor()
        self.flag = 'c'
        self.file_system_services = ['OPEN_NEW_FILE','OPEN_FILE','CLOSE_FILE','READ_FILE','WRITE_FILE','SEEK_FILE',
                                     'REMOVE_FILE','RENAME_FILE','GET_FILE_STATUS','GET_VOLUME_STATUS','RESIZE_FILE',
                                     'SYNC_FILE','OPEN_DIRECTORY','CLOSE_DIRECTORY','READ_DIRECTORY','REWIND_DIRECTORY',
                                     'MAKE_DIRECTORY','REMOVE_DIRECTORY']
        self.log_system_services = ['CREATE_LOGBOOK','WRITE_LOGBOOK','OVERWRITE_LOGBOOK','READ_LOGBOOK','CLEAR_LOGBOOK',
                                    'GET_LOGBOOK_ID','GET_LOGBOOK_STATUS']
        self.ignore_function = ['get_file_name','get_file_prefix','FileSystemInit','schedule','LogSystemInit']


    def transfer(self,input_file):
        '''
        将input_file生成指定类型的文件
        :param input_file: 文件名
        :return:
        '''
        name = input_file.split('/')[-1]
        name = name.split('.')[0]
        input = FileStream(input_file)
        lexer = MatlabLexer(input)
        stream = CommonTokenStream(lexer)
        parser = MatlabParser(stream)
        tree = parser.function()
        self.mat2cvi.function_name = name # 新增
        self.mat2cvi.flag = self.flag
        self.mat2cvi.hierCode.set_file_name(name)
        self.mat2cvi.machineC.set_file_name(name)
        self.mat2cvi.visit(tree)
        self.mat2cvi.clear_level()
        self.mat2cvi.clear_pointers()

    def set_flag(self,flag):
        '''
        设置生成代码类型：hier_m->层级M,hier_c->层级c,c->正常c
        :param flag:
        :return:
        '''
        if flag == 'hier_m':
            self.flag = 'hier_m'
        elif flag == 'hier_c':
            self.flag = 'hier_c'
        elif flag == 'c':
            self.flag = 'c'
        else:
            print('unvalid flag : {}'.format(flag))

    def to_code(self,input_file,flag):
        '''
        转换为一种格式
        :param input_file:
        :return:
        '''
        self.set_flag(flag)
        self.transfer(input_file)
        self.mat2cvi.machineC.to_c_string()
        self.mat2cvi.machineC.to_file()
        self.mat2cvi.hierCode.to_hier_file()
        self.mat2cvi.machineC.clear()

    def to_code3(self,input_file):
        '''
        同时生成层级C/普通C/层级M
        :param input_file:
        :return:
        '''
        print('-------------------------hier_c info----------------------------')
        self.flag = 'hier_c'
        self.transfer(input_file)
        print('\n')
        print('-------------------------c info----------------------------')
        self.flag = 'c'
        self.transfer(input_file)
        print('\n')
        print('-------------------------hier_m info----------------------------')
        self.flag = 'hier_m'
        self.transfer(input_file)
        self.mat2cvi.machineC.to_c_string()
        self.mat2cvi.machineC.to_file()
        self.mat2cvi.hierCode.to_hier_file()
        self.mat2cvi.machineC.clear()

    def to_code_all(self,path,flag,out_name):
        '''
        一次生成所有代码到单个文件
        :param path: 转换文件所在目录
        :param flag: 转换模式
        :param out_name: 转化后的文件名
        :return:
        '''
        if not os.path.exists(path):
            print('path not exist!')
            return
        else:
            self.mat2cvi.print_flag = False
            self.set_flag(flag)
            files = os.listdir(path)
            for file in files:
                if file.split('.')[0] not in self.ignore_function:
                    print('read {}'.format(file))
                    file_path = path + file
                    self.transfer(file_path)
                    # time.sleep(0.5)
            if flag == 'hier_c' or flag == 'hier_m':
                self.mat2cvi.hierCode.set_file_name(out_name)
                self.mat2cvi.hierCode.to_hier_file()
            else:
                self.mat2cvi.machineC.set_file_name(out_name)
                self.mat2cvi.machineC.to_file()


#'OPEN_NEW_FILE','OPEN_FILE','CLOSE_FILE','READ_FILE','WRITE_FILE','SEEK_FILE','REMOVE_FILE','RENAME_FILE','GET_FILE_STATUS','GET_VOLUME_STATUS','RESIZE_FILE','SYNC_FILE','OPEN_DIRECTORY','CLOSE_DIRECTORY','READ_DIRECTORY','REWIND_DIRECTORY','MAKE_DIRECTORY','REMOVE_DIRECTORY'
#'CREATE_LOGBOOK','WRITE_LOGBOOK','OVERWRITE_LOGBOOK','READ_LOGBOOK','CLEAR_LOGBOOK','GET_LOGBOOK_ID','GET_LOGBOOK_STATUS'

if __name__ == '__main__':
    #单个文件的生成
    matlab2c = Matlab2C()
    input_file = './fs/OPEN_NEW_FILE.m'
    matlab2c.to_code3(input_file)
    #
    # path = './fs/'
    # files = os.listdir(path)
    # print(files)
    # matlab2c = Matlab2C()
    # path = './fs/'
    # flag = 'c'
    # out_name = 'arinc_fs'
    # matlab2c.to_code_all(path,flag,out_name)

    # matlab2c = Matlab2C()
    # input_file = './ls/READ_LOGBOOK.m'
    # matlab2c.to_code3(input_file)

    # path = './ls/'
    # files = os.listdir(path)
    # print(files)
    # matlab2c = Matlab2C()
    # flag = 'c'
    # out_name = 'arinc_ls'
    # matlab2c.to_code_all(path,flag,out_name)

