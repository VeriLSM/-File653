#include "arinc_fs.h"
#include "libc.h"
#include "types.h"


extern APEX_INTEGER LOCK_LEVEL;		//  C-GLBD
extern APEX_INTEGER CurrentProcess;		//  C-GLBD
extern APEX_INTEGER ERROR_HANDLER_PROCESS_ID;		//  C-GLBD
extern APEX_INTEGER PARTION_OPEN_FILES_NUMBERS;		//  C-GLBD
extern APEX_INTEGER PARTION_EXIT_FILES_NUMBERS;		//  C-GLBD
extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];
extern bool inode_bitmap[INODE_NUM];
extern bool block_bitmap[BLOCK_NUM];
extern char Directory_Name_Set[INODE_NUM][MAX_FILE_NAME_LENGTH];
extern SuperBlock *super_block;
extern int8_t blocks[2621440];
extern int8_t blocks[2621440];
extern Inode inodes[512];
extern int32_t ROOT_DIRECTORY_ID;
extern int32_t CURRENT_DIRECTORY_ID;
extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];


void OPEN_NEW_FILE(FILE_NAME_TYPE FILE_NAME, FILE_ID_TYPE *FILE_ID, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {		// 1 C-FUCD
	APEX_INTEGER Fileindex;		// 1.0 C-TYDE
	Fileindex = CapacityofFile();		// 1.1 C-ASS
	if (Fileindex == 0) {		// 1.2 C-IFS
		*FILE_ID = -1;		// 1.2.0 C-ASS
		*RETURN_CODE = INVALID_CONFIG;		// 1.2.1 C-ASS
		*ERRNO = EMFILE;		// 1.2.2 C-ASS
		return;		// 1.2.3 C-RET
	}
	APEX_INTEGER File_Length_Flag;		// 1.3 C-TYDE
	File_Length_Flag = Invalid_File_Length(FILE_NAME);		// 1.4 C-ASS
	if (File_Length_Flag == 0) {		// 1.5 C-IFS
		*FILE_ID = -1;		// 1.5.0 C-ASS
		*RETURN_CODE = INVALID_PARAM;		// 1.5.1 C-ASS
		*ERRNO = ENAMETOOLONG;		// 1.5.2 C-ASS
		return;		// 1.5.3 C-RET
	}
	APEX_INTEGER File_Syntax_Flag;		// 1.6 C-TYDE
	File_Syntax_Flag = Invalid_File_Syntax(FILE_NAME);		// 1.7 C-ASS
	if (File_Syntax_Flag == 0) {		// 1.8 C-IFS
		*FILE_ID = -1;		// 1.8.0 C-ASS
		*RETURN_CODE = INVALID_PARAM;		// 1.8.1 C-ASS
		*ERRNO = EINVAL;		// 1.8.2 C-ASS
		return;		// 1.8.3 C-RET
	}
	APEX_INTEGER File_Path_Prefix_Flag;		// 1.9 C-TYDE
	File_Path_Prefix_Flag = Invalid_File_Path_Prefix(FILE_NAME);		// 1.10 C-ASS
	if (File_Path_Prefix_Flag == 0) {		// 1.11 C-IFS
		*FILE_ID = -1;		// 1.11.0 C-ASS
		*RETURN_CODE = INVALID_PARAM;		// 1.11.1 C-ASS
		*ERRNO = ENOTDIR;		// 1.11.2 C-ASS
		return;		// 1.11.3 C-RET
	}
	APEX_INTEGER Invalid_Partition_Mode_Flag;		// 1.12 C-TYDE
	Invalid_Partition_Mode_Flag = Invalid_Partition_Read_Write_Access_Rights(FILE_NAME);		// 1.13 C-ASS
	if (Invalid_Partition_Mode_Flag == 0) {		// 1.14 C-IFS
		*FILE_ID = -1;		// 1.14.0 C-ASS
		*RETURN_CODE = INVALID_CONFIG;		// 1.14.1 C-ASS
		*ERRNO = EACCES;		// 1.14.2 C-ASS
		return;		// 1.14.3 C-RET
	}
	APEX_INTEGER Invalid_Device_Write_Protected_Flag;		// 1.15 C-TYDE
	Invalid_Device_Write_Protected_Flag = Invalid_Device_Is_Write_Protected();		// 1.16 C-ASS
	if (Invalid_Device_Write_Protected_Flag == 0) {		// 1.17 C-IFS
		*FILE_ID = -1;		// 1.17.0 C-ASS
		*RETURN_CODE = INVALID_PARAM;		// 1.17.1 C-ASS
		*ERRNO = EROFS;		// 1.17.2 C-ASS
		return;		// 1.17.3 C-RET
	}
	APEX_INTEGER Existing_File_Flag;		// 1.18 C-TYDE
	Existing_File_Flag = Invalid_Existing_File(FILE_NAME);		// 1.19 C-ASS
	if (Existing_File_Flag > 0) {		// 1.20 C-IFS
		*FILE_ID = -1;		// 1.20.0 C-ASS
		*RETURN_CODE = INVALID_PARAM;		// 1.20.1 C-ASS
		*ERRNO = EEXIST;		// 1.20.2 C-ASS
		return;		// 1.20.3 C-RET
	}
	APEX_INTEGER Existing_Directory_Flag;		// 1.21 C-TYDE
	Existing_Directory_Flag = Invalid_Existing_Directory(FILE_NAME);		// 1.22 C-ASS
	if (Existing_Directory_Flag == 0) {		// 1.23 C-IFS
		*FILE_ID = -1;		// 1.23.0 C-ASS
		*RETURN_CODE = INVALID_PARAM;		// 1.23.1 C-ASS
		*ERRNO = EISDIR;		// 1.23.2 C-ASS
		return;		// 1.23.3 C-RET
	}
	APEX_INTEGER Volume_Space_Flag;		// 1.24 C-TYDE
	Volume_Space_Flag = Invalid_Volume_Space_Available(FILE_NAME);		// 1.25 C-ASS
	if (Volume_Space_Flag == 0) {		// 1.26 C-IFS
		*FILE_ID = -1;		// 1.26.0 C-ASS
		*RETURN_CODE = INVALID_CONFIG;		// 1.26.1 C-ASS
		*ERRNO = ENOSPC;		// 1.26.2 C-ASS
		return;		// 1.26.3 C-RET
	}
	APEX_INTEGER Storage_Device_Flag;		// 1.27 C-TYDE
	Storage_Device_Flag = Invalid_Storage_Device_Contain_File_Name(FILE_NAME);		// 1.28 C-ASS
	if (Storage_Device_Flag == 0) {		// 1.29 C-IFS
		*FILE_ID = -1;		// 1.29.0 C-ASS
		*RETURN_CODE = NOT_AVAILABLE;		// 1.29.1 C-ASS
		*ERRNO = EIO;		// 1.29.2 C-ASS
		return;		// 1.29.3 C-RET
	}
	if (LOCK_LEVEL > 0) {		// 1.30 C-IFS
		*FILE_ID = -1;		// 1.30.0 C-ASS
		*RETURN_CODE = INVALID_MODE;		// 1.30.1 C-ASS
		*ERRNO = EACCES;		// 1.30.2 C-ASS
		return;		// 1.30.3 C-RET
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {		// 1.31 C-IFS
		*FILE_ID = -1;		// 1.31.0 C-ASS
		*RETURN_CODE = INVALID_MODE;		// 1.31.1 C-ASS
		*ERRNO = EACCES;		// 1.31.2 C-ASS
		return;		// 1.31.3 C-RET
	}
	APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];		// 1.32 C-TYDE
	get_file_prefix(FILE_NAME,path_prefix);		// 1.33 C-ASS
	APEX_INTEGER DIR_ID;		// 1.34 C-TYDE
	
	DIR_ID = ismember4(path_prefix, Directory_Name_Set,MAX_DIRECTORY_NUMBER);		// 1.36 C-EISM
	write_directory(DIR_ID, FILE_NAME, Fileindex);		// 1.37 C-FUC
	inodes[DIR_ID].cnt = inodes[DIR_ID].cnt + 1;		// 1.38 C-ASS
	APEX_INTEGER ID;		// 1.39 C-TYDE
	ID = Fileindex;		// 1.40 C-ASS
	*FILE_ID = ID;		// 1.41 C-ASS
	inodes[ID].id = ID;		// 1.42 C-ASS
	inodes[ID].position = 0;		// 1.43 C-ASS
	inodes[ID].size = 0;		// 1.44 C-ASS
	inodes[ID].nb_of_changes = 0;		// 1.45 C-ASS
	inodes[ID].nb_of_write_errors = 0;		// 1.46 C-ASS
	//inode.content = "";		// 1.47 C-ASS
	inodes[ID].is_open = 1;		// 1.48 C-ASS
	inodes[ID].mode = READ_WRITE;		// 1.49 C-ASS
	inodes[ID].entry = FILE_ENTRY;		// 1.50 C-ASS
	inodes[ID].cnt = 0;		// 1.51 C-ASS
	inodes[ID].dirBlock[0] = block_alloc();		// 1.52 C-ASS
	PARTION_OPEN_FILES_NUMBERS = PARTION_OPEN_FILES_NUMBERS + 1;		// 1.53 C-ASS
	PARTION_EXIT_FILES_NUMBERS = PARTION_EXIT_FILES_NUMBERS + 1;		// 1.54 C-ASS
	inode_bitmap[ID] = 1;		// 1.55 C-ASS
	super_block->free_block_num = super_block->free_block_num - 1;		// 1.56 C-ASS
	super_block->free_inode_num = super_block->free_inode_num - 1;		// 1.57 C-ASS
	*RETURN_CODE = NO_ERROR;		// 1.58 C-ASS
	*ERRNO = EUNCHANGE;		// 1.59 C-ASS
	return;		// 1.60 C-RET
}



