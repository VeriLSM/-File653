#include "arinc_fs.h"
#include "libc.h"
#include "types.h"


extern APEX_INTEGER CurrentProcess;		//  C-GLBD
extern APEX_INTEGER ERROR_HANDLER_PROCESS_ID;		//  C-GLBD
extern APEX_INTEGER LOCK_LEVEL;		//  C-GLBD
extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];
extern bool inode_bitmap[INODE_NUM];
extern bool block_bitmap[BLOCK_NUM];
extern char Directory_Name_Set[INODE_NUM][MAX_FILE_NAME_LENGTH];
extern SuperBlock *super_block;
extern int8_t blocks[2621440];
extern int8_t blocks[2621440];
extern Inode inodes[512];
extern int32_t ROOT_DIRECTORY_ID;
extern int32_t CURRENT_DIRECTORY_ID;
extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];


void WRITE_FILE(FILE_ID_TYPE FILE_ID, MESSAGE_ADDR_TYPE MESSAGE_ADDR, MESSAGE_SIZE_TYPE LENGTH, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {		// 1 C-FUCD
	APEX_INTEGER File_Id_In_Current_Partition_Flag;		// 1.0 C-TYDE
	File_Id_In_Current_Partition_Flag = Invalid_File_Id_In_Current_Partition(FILE_ID);		// 1.1 C-ASS
	if (File_Id_In_Current_Partition_Flag == 0) {		// 1.2 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.2.0 C-ASS
		*ERRNO = EBADF;		// 1.2.1 C-ASS
		return;		// 1.2.2 C-RET
	}
	APEX_INTEGER File_Id_has_Operation_Flag;		// 1.3 C-TYDE
	File_Id_has_Operation_Flag = Invalid_File_Id_has_Operation(FILE_ID);		// 1.4 C-ASS
	if (File_Id_has_Operation_Flag == 0) {		// 1.5 C-IFS
		*RETURN_CODE = NOT_AVAILABLE;		// 1.5.0 C-ASS
		*ERRNO = EBUSY;		// 1.5.1 C-ASS
		return;		// 1.5.2 C-RET
	}
	APEX_INTEGER File_Id_has_Read_Write_Access_Mode_Flag;		// 1.6 C-TYDE
	File_Id_has_Read_Write_Access_Mode_Flag = Invalid_File_Id_has_Read_Write_Access_Mode(FILE_ID);		// 1.7 C-ASS
	if (File_Id_has_Read_Write_Access_Mode_Flag == 0) {		// 1.8 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.8.0 C-ASS
		*ERRNO = EACCES;		// 1.8.1 C-ASS
		return;		// 1.8.2 C-RET
	}
	if (LENGTH <= 0) {		// 1.9 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.9.0 C-ASS
		*ERRNO = EINVAL;		// 1.9.1 C-ASS
		return;		// 1.9.2 C-RET
	}
	APEX_INTEGER Volume_Space_Flag;		// 1.10 C-TYDE
	Volume_Space_Flag = Invalid_Volume_Space_Available_Length(LENGTH);		// 1.11 C-ASS
	if (Volume_Space_Flag == 0) {		// 1.12 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.12.0 C-ASS
		*ERRNO = ENOSPC;		// 1.12.1 C-ASS
		return;		// 1.12.2 C-RET
	}
	APEX_INTEGER Length_Greater_than_Miximun_Flag;		// 1.13 C-TYDE
	Length_Greater_than_Miximun_Flag = Invalid_Length_Greater_than_Miximun(LENGTH);		// 1.14 C-ASS
	if (Length_Greater_than_Miximun_Flag == 0) {		// 1.15 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.15.0 C-ASS
		*ERRNO = EFBIG;		// 1.15.1 C-ASS
		return;		// 1.15.2 C-RET
	}
	APEX_INTEGER Storage_Device_Contain_File_ID_Flag;		// 1.16 C-TYDE
	Storage_Device_Contain_File_ID_Flag = Invalid_Storage_Device_Contain_File_Id(FILE_ID);		// 1.17 C-ASS
	if (Storage_Device_Contain_File_ID_Flag == 0) {		// 1.18 C-IFS
		*RETURN_CODE = NOT_AVAILABLE;		// 1.18.0 C-ASS
		*ERRNO = EIO;		// 1.18.1 C-ASS
		return;		// 1.18.2 C-RET
	}
	if (LOCK_LEVEL > 0) {		// 1.19 C-IFS
		*RETURN_CODE = INVALID_MODE;		// 1.19.0 C-ASS
		*ERRNO = EACCES;		// 1.19.1 C-ASS
		return;		// 1.19.2 C-RET
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {		// 1.20 C-IFS
		*RETURN_CODE = INVALID_MODE;		// 1.20.0 C-ASS
		*ERRNO = EACCES;		// 1.20.1 C-ASS
		return;		// 1.20.2 C-RET
	}
	if (File_Id_In_Current_Partition_Flag != 0 && File_Id_has_Operation_Flag != 0 && File_Id_has_Read_Write_Access_Mode_Flag != 0 && LENGTH > 0 && Volume_Space_Flag != 0 && Length_Greater_than_Miximun_Flag != 0 && Storage_Device_Contain_File_ID_Flag != 0 && LOCK_LEVEL == 0 && CurrentProcess != ERROR_HANDLER_PROCESS_ID) {		// 1.21 C-IFS
		APEX_INTEGER File_Position,File_Size,File_Nb_Of_Changes,ID;		// 1.21.0 C-TYDE
		ID = *FILE_ID;		// 1.21.1 C-ASS
		File_Position = inodes[ID].position + LENGTH;		// 1.21.2 C-ASS
		File_Size = inodes[ID].size;		// 1.21.3 C-ASS
		File_Nb_Of_Changes = inodes[ID].nb_of_changes;		// 1.21.4 C-ASS
		transfer_from_message(FILE_ID, MESSAGE_ADDR);		// 1.21.5 C-FUC
		if (File_Position > File_Size) {		// 1.21.6 C-IFS
			inodes[ID].size = File_Position;		// 1.21.6.0 C-ASS
		}
		inodes[ID].nb_of_changes = File_Nb_Of_Changes + 1;		// 1.21.7 C-ASS
		*RETURN_CODE = NO_ERROR;		// 1.21.8 C-ASS
		return;		// 1.21.9 C-RET
	}
}



