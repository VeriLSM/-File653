#include "arinc_fs.h"
#include "libc.h"
#include "types.h"




void READ_LOGBOOK(LOGBOOK_ID_TYPE LOGBOOK_ID, MESSAGE_RANGE_TYPE LOGBOOK_ENTRY, MESSAGE_ADDR_TYPE MESSAGE_ADDR, MESSAGE_SIZE_TYPE *LENGTH, WRITE_STATUS_TYPE *WRITE_STATUS, RETURN_CODE_TYPE *RETURN_CODE) {		// 1 C-FUCD
	if (LOGBOOK_ID != CURRENT_LOGBOOK_ID) {		// 1.0 C-IFS
		*LENGTH = 0;		// 1.0.0 C-ASS
		*WRITE_STATUS = NOUSE;		// 1.0.1 C-ASS
		*RETURN_CODE = INVALID_PARAM;		// 1.0.2 C-ASS
		return;		// 1.0.3 C-RET
	}
	if (LOGBOOK_ENTRY > CURRENT_IN_PROGRESS_MESSAGE_NUMBER) {		// 1.1 C-IFS
		*LENGTH = 0;		// 1.1.0 C-ASS
		*WRITE_STATUS = NOUSE;		// 1.1.1 C-ASS
		*RETURN_CODE = INVALID_PARAM;		// 1.1.2 C-ASS
		return;		// 1.1.3 C-RET
	}
			// 1.2 C-ETKS
			// 1.3 C-ETKS
	index1 = ismember4(MESSAGE_ADDR, In_Progress_Log_Set,MAX_NB_IN_PROGRESS_MESSAGES_LIMITED);		// 1.4 C-EISM
	index2 = ismember4(MESSAGE_ADDR, Logbook_Set,MAX_NB_LOGGED_MESSAGES_LIMITED);		// 1.5 C-EISM
	if (index1 != 0) {		// 1.6 C-IFS
		*LENGTH = strlength(In_Progress_Log_Set[index1]);		// 1.6.0 C-ASS
		*WRITE_STATUS = IN_PROGRESS;		// 1.6.1 C-ASS
		*RETURN_CODE = NO_ERROR;		// 1.6.2 C-ASS
		return;		// 1.6.3 C-RET
	}
	if (index2 != 0) {		// 1.7 C-IFS
		*LENGTH = strlength(Logbook_Set[index2]);		// 1.7.0 C-ASS
		*WRITE_STATUS = COMPLETE;		// 1.7.1 C-ASS
		*RETURN_CODE = NO_ERROR;		// 1.7.2 C-ASS
		return;		// 1.7.3 C-RET
	}
	*LENGTH = 0;		// 1.8 C-ASS
	*WRITE_STATUS = ABORTED;		// 1.9 C-ASS
	*RETURN_CODE = NO_ERROR;		// 1.10 C-ASS
	return;		// 1.11 C-RET
}



