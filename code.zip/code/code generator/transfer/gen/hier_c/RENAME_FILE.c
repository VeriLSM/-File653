#include "arinc_fs.h"
#include "libc.h"
#include "types.h"


extern APEX_INTEGER LOCK_LEVEL;		//  C-GLBD
extern APEX_INTEGER CurrentProcess;		//  C-GLBD
extern APEX_INTEGER ERROR_HANDLER_PROCESS_ID;		//  C-GLBD
extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];
extern bool inode_bitmap[INODE_NUM];
extern bool block_bitmap[BLOCK_NUM];
extern char Directory_Name_Set[INODE_NUM][MAX_FILE_NAME_LENGTH];
extern SuperBlock *super_block;
extern int8_t blocks[2621440];
extern int8_t blocks[2621440];
extern Inode inodes[512];
extern int32_t ROOT_DIRECTORY_ID;
extern int32_t CURRENT_DIRECTORY_ID;
extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];


void RENAME_FILE(FILE_NAME_TYPE OLD_FILE_NAME, FILE_NAME_TYPE NEW_FILE_NAME, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {		// 1 C-FUCD
	APEX_INTEGER Old_File_length_Flag;		// 1.0 C-TYDE
	Old_File_length_Flag = Invalid_File_Length(OLD_FILE_NAME);		// 1.1 C-ASS
	if (Old_File_length_Flag == 0) {		// 1.2 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.2.0 C-ASS
		*ERRNO = ENAMETOOLONG;		// 1.2.1 C-ASS
		return;		// 1.2.2 C-RET
	}
	APEX_INTEGER Old_File_Syntax_Flag;		// 1.3 C-TYDE
	Old_File_Syntax_Flag = Invalid_File_Syntax(OLD_FILE_NAME);		// 1.4 C-ASS
	if (Old_File_Syntax_Flag == 0) {		// 1.5 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.5.0 C-ASS
		*ERRNO = EINVAL;		// 1.5.1 C-ASS
		return;		// 1.5.2 C-RET
	}
	APEX_INTEGER Old_File_Path_Prefix_Flag;		// 1.6 C-TYDE
	Old_File_Path_Prefix_Flag = Invalid_File_Path_Prefix(OLD_FILE_NAME);		// 1.7 C-ASS
	if (Old_File_Path_Prefix_Flag == 0) {		// 1.8 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.8.0 C-ASS
		*ERRNO = ENOTDIR;		// 1.8.1 C-ASS
		return;		// 1.8.2 C-RET
	}
	APEX_INTEGER New_File_length_Flag;		// 1.9 C-TYDE
	New_File_length_Flag = Invalid_File_Length(NEW_FILE_NAME);		// 1.10 C-ASS
	if (New_File_length_Flag == 0) {		// 1.11 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.11.0 C-ASS
		*ERRNO = ENAMETOOLONG;		// 1.11.1 C-ASS
		return;		// 1.11.2 C-RET
	}
	APEX_INTEGER New_File_Syntax_Flag;		// 1.12 C-TYDE
	New_File_Syntax_Flag = Invalid_File_Syntax(NEW_FILE_NAME);		// 1.13 C-ASS
	if (New_File_Syntax_Flag == 0) {		// 1.14 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.14.0 C-ASS
		*ERRNO = EINVAL;		// 1.14.1 C-ASS
		return;		// 1.14.2 C-RET
	}
	APEX_INTEGER New_File_Path_Prefix_Flag;		// 1.15 C-TYDE
	New_File_Path_Prefix_Flag = Invalid_File_Path_Prefix(NEW_FILE_NAME);		// 1.16 C-ASS
	if (New_File_Path_Prefix_Flag == 0) {		// 1.17 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.17.0 C-ASS
		*ERRNO = ENOTDIR;		// 1.17.1 C-ASS
		return;		// 1.17.2 C-RET
	}
	APEX_INTEGER Partition_Access_Rights_Flag;		// 1.18 C-TYDE
	Partition_Access_Rights_Flag = Invalid_Partition_Read_Write_Access_Rights(OLD_FILE_NAME);		// 1.19 C-ASS
	if (Partition_Access_Rights_Flag == 0) {		// 1.20 C-IFS
		*RETURN_CODE = INVALID_CONFIG;		// 1.20.0 C-ASS
		*ERRNO = EACCES;		// 1.20.1 C-ASS
		return;		// 1.20.2 C-RET
	}
	APEX_INTEGER File_Name_Operation_Flag;		// 1.21 C-TYDE
	File_Name_Operation_Flag = Invalid_File_Name_has_Operation(OLD_FILE_NAME);		// 1.22 C-ASS
	if (File_Name_Operation_Flag == 0) {		// 1.23 C-IFS
		*RETURN_CODE = NOT_AVAILABLE;		// 1.23.0 C-ASS
		*ERRNO = EBUSY;		// 1.23.1 C-ASS
		return;		// 1.23.2 C-RET
	}
	APEX_INTEGER Device_Protected_Flag;		// 1.24 C-TYDE
	Device_Protected_Flag = Invalid_Device_Is_Write_Protected();		// 1.25 C-ASS
	if (Device_Protected_Flag == 0) {		// 1.26 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.26.0 C-ASS
		*ERRNO = EROFS;		// 1.26.1 C-ASS
		return;		// 1.26.2 C-RET
	}
	APEX_INTEGER File_Name_Identical_Flag;		// 1.27 C-TYDE
	File_Name_Identical_Flag = Invalid_OLD_New_File_Name_Volume_Identical(OLD_FILE_NAME, NEW_FILE_NAME);		// 1.28 C-ASS
	if (File_Name_Identical_Flag == 0) {		// 1.29 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.29.0 C-ASS
		*ERRNO = EINVAL;		// 1.29.1 C-ASS
		return;		// 1.29.2 C-RET
	}
	APEX_INTEGER Create_File_in_New_Directory_Flag;		// 1.30 C-TYDE
	Create_File_in_New_Directory_Flag = Invalid_Create_File_in_New_Directory(NEW_FILE_NAME);		// 1.31 C-ASS
	if (Create_File_in_New_Directory_Flag == 0) {		// 1.32 C-IFS
		*RETURN_CODE = INVALID_CONFIG;		// 1.32.0 C-ASS
		*ERRNO = ENOSPC;		// 1.32.1 C-ASS
		return;		// 1.32.2 C-RET
	}
	APEX_INTEGER Old_Existing_Directory_Flag;		// 1.33 C-TYDE
	Old_Existing_Directory_Flag = Invalid_Existing_Directory(OLD_FILE_NAME);		// 1.34 C-ASS
	if (Old_Existing_Directory_Flag == 0) {		// 1.35 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.35.0 C-ASS
		*ERRNO = EPERM;		// 1.35.1 C-ASS
		return;		// 1.35.2 C-RET
	}
	APEX_INTEGER New_Existing_Directory_Flag;		// 1.36 C-TYDE
	New_Existing_Directory_Flag = Invalid_Existing_Directory(NEW_FILE_NAME);		// 1.37 C-ASS
	if (New_Existing_Directory_Flag == 0) {		// 1.38 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.38.0 C-ASS
		*ERRNO = EISDIR;		// 1.38.1 C-ASS
		return;		// 1.38.2 C-RET
	}
	APEX_INTEGER Old_Existing_File_Flag;		// 1.39 C-TYDE
	Old_Existing_File_Flag = Invalid_Existing_File(OLD_FILE_NAME);		// 1.40 C-ASS
	if (Old_Existing_File_Flag == 0) {		// 1.41 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.41.0 C-ASS
		*ERRNO = ENOENT;		// 1.41.1 C-ASS
		return;		// 1.41.2 C-RET
	}
	APEX_INTEGER New_Existing_File_Flag;		// 1.42 C-TYDE
	New_Existing_File_Flag = Invalid_Existing_File(NEW_FILE_NAME);		// 1.43 C-ASS
	if (New_Existing_File_Flag == 1) {		// 1.44 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.44.0 C-ASS
		*ERRNO = EEXIST;		// 1.44.1 C-ASS
		return;		// 1.44.2 C-RET
	}
	APEX_INTEGER Old_File_Name_Open_Flag;		// 1.45 C-TYDE
	Old_File_Name_Open_Flag = Invalid_File_Name_is_Open(OLD_FILE_NAME);		// 1.46 C-ASS
	if (Old_File_Name_Open_Flag > 0) {		// 1.47 C-IFS
		*RETURN_CODE = NOT_AVAILABLE;		// 1.47.0 C-ASS
		*ERRNO = EBUSY;		// 1.47.1 C-ASS
		return;		// 1.47.2 C-RET
	}
	APEX_INTEGER Old_Storage_Device_Contain_File_Name_Flag;		// 1.48 C-TYDE
	Old_Storage_Device_Contain_File_Name_Flag = Invalid_Storage_Device_Contain_File_Name(OLD_FILE_NAME);		// 1.49 C-ASS
	if (Old_Storage_Device_Contain_File_Name_Flag == 0) {		// 1.50 C-IFS
		*RETURN_CODE = NOT_AVAILABLE;		// 1.50.0 C-ASS
		*ERRNO = EIO;		// 1.50.1 C-ASS
		return;		// 1.50.2 C-RET
	}
	APEX_INTEGER New_Storage_Device_Contain_File_Name_Flag;		// 1.51 C-TYDE
	New_Storage_Device_Contain_File_Name_Flag = Invalid_Storage_Device_Contain_File_Name(NEW_FILE_NAME);		// 1.52 C-ASS
	if (New_Storage_Device_Contain_File_Name_Flag == 0) {		// 1.53 C-IFS
		*RETURN_CODE = NOT_AVAILABLE;		// 1.53.0 C-ASS
		*ERRNO = EIO;		// 1.53.1 C-ASS
		return;		// 1.53.2 C-RET
	}
	if (LOCK_LEVEL > 0) {		// 1.54 C-IFS
		*RETURN_CODE = INVALID_MODE;		// 1.54.0 C-ASS
		*ERRNO = EACCES;		// 1.54.1 C-ASS
		return;		// 1.54.2 C-RET
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {		// 1.55 C-IFS
		*RETURN_CODE = INVALID_MODE;		// 1.55.0 C-ASS
		*ERRNO = EACCES;		// 1.55.1 C-ASS
		return;		// 1.55.2 C-RET
	}
	APEX_BYTE old_path_prefix[MAX_FILE_NAME_LENGTH];		// 1.56 C-TYDE
	get_file_prefix(OLD_FILE_NAME,old_path_prefix);		// 1.57 C-ASS
	APEX_BYTE new_path_prefix[MAX_FILE_NAME_LENGTH];		// 1.58 C-TYDE
	get_file_prefix(NEW_FILE_NAME,new_path_prefix);		// 1.59 C-ASS
	APEX_INTEGER OLD_DIR_ID,NEW_DIR_ID,FILE_ID;		// 1.60 C-TYDE
	
	OLD_DIR_ID = ismember4(old_path_prefix, Directory_Name_Set,MAX_DIRECTORY_NUMBER);		// 1.62 C-EISM
	NEW_DIR_ID = ismember4(new_path_prefix, Directory_Name_Set,MAX_DIRECTORY_NUMBER);		// 1.63 C-EISM
	FILE_ID = search_directory(OLD_DIR_ID, OLD_FILE_NAME);		// 1.64 C-ASS
	write_directory(NEW_DIR_ID, NEW_FILE_NAME, FILE_ID);		// 1.65 C-FUC
	*RETURN_CODE = NO_ERROR;		// 1.66 C-ASS
	*ERRNO = EUNCHANGE;		// 1.67 C-ASS
	return;		// 1.68 C-RET
}



