#include "arinc_fs.h"
#include "libc.h"
#include "types.h"



static APEX_INTEGER Invalid_Device_Is_Write_Protected(void) {		// 1 C-FUCD
	APEX_INTEGER index;		// 1.0 C-TYDE
	index = 1;		// 1.1 C-ASS
	return index;		// 1.2 C-RET
}




