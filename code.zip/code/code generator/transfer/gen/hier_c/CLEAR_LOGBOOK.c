#include "arinc_fs.h"
#include "libc.h"
#include "types.h"




void CLEAR_LOGBOOK(LOGBOOK_ID_TYPE LOGBOOK_ID, RETURN_CODE_TYPE *RETURN_CODE) {		// 1 C-FUCD
	if (LOGBOOK_ID != CURRENT_LOGBOOK_ID) {		// 1.0 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.0.0 C-ASS
		return;		// 1.0.1 C-RET
	}
	init_set();		// 1.1 C-FUC
	CURRENT_LOGGED_MESSAGE_NUMBER = 0;		// 1.2 C-ASS
	CURRENT_IN_PROGRESS_MESSAGE_NUMBER = 0;		// 1.3 C-ASS
	CURRENT_ABORTED_MESSAGE_NUMBER = 0;		// 1.4 C-ASS
	*RETURN_CODE = NO_ERROR;		// 1.5 C-ASS
	return;		// 1.6 C-RET
}



