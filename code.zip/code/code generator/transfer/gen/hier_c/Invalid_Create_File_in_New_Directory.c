#include "arinc_fs.h"
#include "libc.h"
#include "types.h"


extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];
extern bool inode_bitmap[INODE_NUM];
extern bool block_bitmap[BLOCK_NUM];
extern char Directory_Name_Set[INODE_NUM][MAX_FILE_NAME_LENGTH];
extern SuperBlock *super_block;
extern int8_t blocks[2621440];
extern int8_t blocks[2621440];
extern Inode inodes[512];
extern int32_t ROOT_DIRECTORY_ID;
extern int32_t CURRENT_DIRECTORY_ID;
extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];

static APEX_INTEGER Invalid_Create_File_in_New_Directory(FILE_NAME_TYPE NEW_FILE_NAME) {		// 1 C-FUCD
	APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];		// 1.0 C-TYDE
	get_file_prefix(NEW_FILE_NAME,path_prefix);		// 1.1 C-ASS
	APEX_INTEGER DIR_ID,index;		// 1.2 C-TYDE
	
	DIR_ID = ismember4(path_prefix, Directory_Name_Set,MAX_DIRECTORY_NUMBER);		// 1.4 C-EISM
	if (inodes[DIR_ID].cnt < DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS) {		// 1.5 C-IFS
		index = 1;		// 1.5.0 C-ASS
	} else {		// 1.6 C-ELS
		index = 0;		// 1.6.0 C-ASS
	}
	return index;		// 1.7 C-RET
}




