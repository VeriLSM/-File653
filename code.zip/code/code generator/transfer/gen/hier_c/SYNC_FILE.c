#include "arinc_fs.h"
#include "libc.h"
#include "types.h"


extern APEX_INTEGER CurrentProcess;		//  C-GLBD
extern APEX_INTEGER ERROR_HANDLER_PROCESS_ID;		//  C-GLBD
extern APEX_INTEGER LOCK_LEVEL;		//  C-GLBD


void SYNC_FILE(FILE_ID_TYPE FILE_ID, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {		// 1 C-FUCD
	APEX_INTEGER File_Id_In_Current_Partition_Flag;		// 1.0 C-TYDE
	File_Id_In_Current_Partition_Flag = Invalid_File_Id_In_Current_Partition(FILE_ID);		// 1.1 C-ASS
	if (File_Id_In_Current_Partition_Flag == 0) {		// 1.2 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.2.0 C-ASS
		*ERRNO = EBADF;		// 1.2.1 C-ASS
		return;		// 1.2.2 C-RET
	}
	APEX_INTEGER File_Id_has_Operation_Flag;		// 1.3 C-TYDE
	File_Id_has_Operation_Flag = Invalid_File_Id_has_Operation(FILE_ID);		// 1.4 C-ASS
	if (File_Id_has_Operation_Flag == 0) {		// 1.5 C-IFS
		*RETURN_CODE = NOT_AVAILABLE;		// 1.5.0 C-ASS
		*ERRNO = EBUSY;		// 1.5.1 C-ASS
		return;		// 1.5.2 C-RET
	}
	APEX_INTEGER File_Id_has_Read_Write_Access_Mode_Flag;		// 1.6 C-TYDE
	File_Id_has_Read_Write_Access_Mode_Flag = Invalid_File_Id_has_Read_Write_Access_Mode(FILE_ID);		// 1.7 C-ASS
	if (File_Id_has_Read_Write_Access_Mode_Flag == 0) {		// 1.8 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.8.0 C-ASS
		*ERRNO = EACCES;		// 1.8.1 C-ASS
		return;		// 1.8.2 C-RET
	}
	APEX_INTEGER Storage_Device_Contain_File_Id_Flag;		// 1.9 C-TYDE
	Storage_Device_Contain_File_Id_Flag = Invalid_Storage_Device_Contain_File_Id(FILE_ID);		// 1.10 C-ASS
	if (Storage_Device_Contain_File_Id_Flag == 0) {		// 1.11 C-IFS
		*RETURN_CODE = NOT_AVAILABLE;		// 1.11.0 C-ASS
		*ERRNO = EIO;		// 1.11.1 C-ASS
		return;		// 1.11.2 C-RET
	}
	if (LOCK_LEVEL > 0) {		// 1.12 C-IFS
		*RETURN_CODE = INVALID_MODE;		// 1.12.0 C-ASS
		*ERRNO = EACCES;		// 1.12.1 C-ASS
		return;		// 1.12.2 C-RET
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {		// 1.13 C-IFS
		*RETURN_CODE = INVALID_MODE;		// 1.13.0 C-ASS
		*ERRNO = EACCES;		// 1.13.1 C-ASS
		return;		// 1.13.2 C-RET
	}
	*RETURN_CODE = NO_ERROR;		// 1.14 C-ASS
	*ERRNO = EUNCHANGE;		// 1.15 C-ASS
	return;		// 1.16 C-RET
}



