#include "arinc_fs.h"
#include "libc.h"
#include "types.h"


extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];
extern bool inode_bitmap[INODE_NUM];
extern bool block_bitmap[BLOCK_NUM];
extern char Directory_Name_Set[INODE_NUM][MAX_FILE_NAME_LENGTH];
extern SuperBlock *super_block;
extern int8_t blocks[2621440];
extern int8_t blocks[2621440];
extern Inode inodes[512];
extern int32_t ROOT_DIRECTORY_ID;
extern int32_t CURRENT_DIRECTORY_ID;
extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];

static APEX_INTEGER Invalid_File_Name_is_Existing_File_Directory_Volume(FILE_NAME_TYPE FILE_NAME) {		// 1 C-FUCD
	APEX_BYTE volume_name[MAX_FILE_NAME_LENGTH];		// 1.0 C-TYDE
	APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];		// 1.1 C-TYDE
	APEX_INTEGER VOL_ID,DIR_ID,index;		// 1.2 C-TYDE
	get_volume_name(FILE_NAME,volume_name);		// 1.3 C-ASS
	get_file_prefix(FILE_NAME,path_prefix);		// 1.4 C-ASS
			// 1.5 C-ETKS
	VOL_ID = ismember4(volume_name, Directory_Name_Set,MAX_DIRECTORY_NUMBER);		// 1.6 C-EISM
	index = VOL_ID +1;		// 1.7 C-ASS
	if (index == 0) {		// 1.8 C-IFS
		return index;		// 1.8.0 C-RET
	}
	DIR_ID = ismember4(path_prefix, Directory_Name_Set,MAX_DIRECTORY_NUMBER);		// 1.9 C-EISM
	index = DIR_ID +1;		// 1.10 C-ASS
	if (index == 0) {		// 1.11 C-IFS
		return index;		// 1.11.0 C-RET
	}
	ID = ismember4(FILE_NAME, Directory_Name_Set,MAX_DIRECTORY_NUMBER);		// 1.12 C-EISM
	index = ID +1;		// 1.13 C-ASS
	return index;		// 1.14 C-RET
}




