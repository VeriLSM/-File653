#include "arinc_fs.h"
#include "libc.h"
#include "types.h"


extern APEX_INTEGER LOCK_LEVEL;		//  C-GLBD
extern APEX_INTEGER PARTION_OPEN_FILES_NUMBERS;		//  C-GLBD
extern APEX_INTEGER CurrentProcess;		//  C-GLBD
extern APEX_INTEGER ERROR_HANDLER_PROCESS_ID;		//  C-GLBD
extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];
extern bool inode_bitmap[INODE_NUM];
extern bool block_bitmap[BLOCK_NUM];
extern char Directory_Name_Set[INODE_NUM][MAX_FILE_NAME_LENGTH];
extern SuperBlock *super_block;
extern int8_t blocks[2621440];
extern int8_t blocks[2621440];
extern Inode inodes[512];
extern int32_t ROOT_DIRECTORY_ID;
extern int32_t CURRENT_DIRECTORY_ID;
extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];


void OPEN_FILE(FILE_NAME_TYPE FILE_NAME, FILE_MODE_TYPE FILE_MODE, FILE_ID_TYPE *FILE_ID, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {		// 1 C-FUCD
	APEX_INTEGER Fileindex;		// 1.0 C-TYDE
	Fileindex = CapacityofOpenFile();		// 1.1 C-ASS
	if (Fileindex == 0) {		// 1.2 C-IFS
		*FILE_ID = -1;		// 1.2.0 C-ASS
		*RETURN_CODE = INVALID_CONFIG;		// 1.2.1 C-ASS
		*ERRNO = EMFILE;		// 1.2.2 C-ASS
		return;		// 1.2.3 C-RET
	}
	APEX_INTEGER File_Length_Flag;		// 1.3 C-TYDE
	File_Length_Flag = Invalid_File_Length(FILE_NAME);		// 1.4 C-ASS
	if (File_Length_Flag == 0) {		// 1.5 C-IFS
		*FILE_ID = -1;		// 1.5.0 C-ASS
		*RETURN_CODE = INVALID_PARAM;		// 1.5.1 C-ASS
		*ERRNO = ENAMETOOLONG;		// 1.5.2 C-ASS
		return;		// 1.5.3 C-RET
	}
	APEX_INTEGER File_Syntax_Flag;		// 1.6 C-TYDE
	File_Syntax_Flag = Invalid_File_Syntax(FILE_NAME);		// 1.7 C-ASS
	if (File_Syntax_Flag == 0) {		// 1.8 C-IFS
		*FILE_ID = -1;		// 1.8.0 C-ASS
		*RETURN_CODE = INVALID_PARAM;		// 1.8.1 C-ASS
		*ERRNO = EINVAL;		// 1.8.2 C-ASS
		return;		// 1.8.3 C-RET
	}
	APEX_INTEGER File_Path_Prefix_Flag;		// 1.9 C-TYDE
	File_Path_Prefix_Flag = Invalid_File_Path_Prefix(FILE_NAME);		// 1.10 C-ASS
	if (File_Path_Prefix_Flag == 0) {		// 1.11 C-IFS
		*FILE_ID = -1;		// 1.11.0 C-ASS
		*RETURN_CODE = INVALID_PARAM;		// 1.11.1 C-ASS
		*ERRNO = ENOTDIR;		// 1.11.2 C-ASS
		return;		// 1.11.3 C-RET
	}
	APEX_INTEGER Partition_Mode_Flag;		// 1.12 C-TYDE
	Partition_Mode_Flag = Invalid_FILE_MODE(FILE_MODE);		// 1.13 C-ASS
	if (Partition_Mode_Flag == 0) {		// 1.14 C-IFS
		*FILE_ID = -1;		// 1.14.0 C-ASS
		*RETURN_CODE = INVALID_PARAM;		// 1.14.1 C-ASS
		*ERRNO = EINVAL;		// 1.14.2 C-ASS
		return;		// 1.14.3 C-RET
	}
	APEX_INTEGER Existing_Directory_Flag;		// 1.15 C-TYDE
	Existing_Directory_Flag = Invalid_Existing_Directory(FILE_NAME);		// 1.16 C-ASS
	if (Existing_Directory_Flag == 0) {		// 1.17 C-IFS
		*FILE_ID = -1;		// 1.17.0 C-ASS
		*RETURN_CODE = INVALID_PARAM;		// 1.17.1 C-ASS
		*ERRNO = EISDIR;		// 1.17.2 C-ASS
		return;		// 1.17.3 C-RET
	}
	APEX_INTEGER Existing_File_Flag;		// 1.18 C-TYDE
	Existing_File_Flag = Invalid_Existing_File(FILE_NAME);		// 1.19 C-ASS
	if (Existing_File_Flag > 0) {		// 1.20 C-IFS
		*FILE_ID = -1;		// 1.20.0 C-ASS
		*RETURN_CODE = INVALID_PARAM;		// 1.20.1 C-ASS
		*ERRNO = EEXIST;		// 1.20.2 C-ASS
		return;		// 1.20.3 C-RET
	}
	APEX_INTEGER Existing_Filename_Is_Read_Write_Flag;		// 1.21 C-TYDE
	Existing_Filename_Is_Read_Write_Flag = Invalid_Existing_Filename_Is_Read_Write(FILE_NAME);		// 1.22 C-ASS
	if (Existing_Filename_Is_Read_Write_Flag == 1 && FILE_MODE == READ_WRITE) {		// 1.23 C-IFS
		*FILE_ID = -1;		// 1.23.0 C-ASS
		*RETURN_CODE = INVALID_PARAM;		// 1.23.1 C-ASS
		*ERRNO = EACCES;		// 1.23.2 C-ASS
		return;		// 1.23.3 C-RET
	}
	APEX_INTEGER Partition_Access_Rights_Flag;		// 1.24 C-TYDE
	Partition_Access_Rights_Flag = Invalid_Partition_Access_Rights(FILE_MODE, FILE_NAME);		// 1.25 C-ASS
	if (Partition_Access_Rights_Flag == 0) {		// 1.26 C-IFS
		*FILE_ID = -1;		// 1.26.0 C-ASS
		*RETURN_CODE = INVALID_CONFIG;		// 1.26.1 C-ASS
		*ERRNO = EACCES;		// 1.26.2 C-ASS
		return;		// 1.26.3 C-RET
	}
	APEX_INTEGER Device_Write_Protected_Flag;		// 1.27 C-TYDE
	Device_Write_Protected_Flag = Invalid_Device_Is_Write_Protected();		// 1.28 C-ASS
	if (Device_Write_Protected_Flag == 0 && FILE_MODE == READ_WRITE) {		// 1.29 C-IFS
		*FILE_ID = -1;		// 1.29.0 C-ASS
		*RETURN_CODE = INVALID_PARAM;		// 1.29.1 C-ASS
		*ERRNO = EROFS;		// 1.29.2 C-ASS
		return;		// 1.29.3 C-RET
	}
	APEX_INTEGER Storage_Device_Contain_File_ID_Flag;		// 1.30 C-TYDE
	Storage_Device_Contain_File_ID_Flag = Invalid_Storage_Device_Contain_File_Name(FILE_NAME);		// 1.31 C-ASS
	if (Storage_Device_Contain_File_ID_Flag == 0) {		// 1.32 C-IFS
		*FILE_ID = -1;		// 1.32.0 C-ASS
		*RETURN_CODE = NOT_AVAILABLE;		// 1.32.1 C-ASS
		*ERRNO = EIO;		// 1.32.2 C-ASS
		return;		// 1.32.3 C-RET
	}
	if (LOCK_LEVEL > 0) {		// 1.33 C-IFS
		*FILE_ID = -1;		// 1.33.0 C-ASS
		*RETURN_CODE = INVALID_MODE;		// 1.33.1 C-ASS
		*ERRNO = EACCES;		// 1.33.2 C-ASS
		return;		// 1.33.3 C-RET
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {		// 1.34 C-IFS
		*FILE_ID = -1;		// 1.34.0 C-ASS
		*RETURN_CODE = INVALID_MODE;		// 1.34.1 C-ASS
		*ERRNO = EACCES;		// 1.34.2 C-ASS
		return;		// 1.34.3 C-RET
	}
	APEX_INTEGER ID;		// 1.35 C-TYDE
			// 1.36 C-ETKS
	ID = ismember4(FILE_NAME, Directory_Name_Set,MAX_DIRECTORY_NUMBER);		// 1.37 C-EISM
	APEX_INTEGER tag;		// 1.38 C-TYDE
	tag = inode_bitmap[ID];		// 1.39 C-ASS
	if (tag == 0) {		// 1.40 C-IFS
		inodes[ID].nb_of_changes = 0;		// 1.40.0 C-ASS
		inodes[ID].nb_of_write_errors = 0;		// 1.40.1 C-ASS
	}
	inode_bitmap[ID] = 1;		// 1.41 C-ASS
	inodes[ID].position = 0;		// 1.42 C-ASS
	PARTION_OPEN_FILES_NUMBERS = PARTION_OPEN_FILES_NUMBERS + 1;		// 1.43 C-ASS
	*FILE_ID = ID;		// 1.44 C-ASS
	*RETURN_CODE = NO_ERROR;		// 1.45 C-ASS
	*ERRNO = EUNCHANGE;		// 1.46 C-ASS
	return;		// 1.47 C-RET
}



