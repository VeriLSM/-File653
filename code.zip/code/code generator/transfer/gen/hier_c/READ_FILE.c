#include "arinc_fs.h"
#include "libc.h"
#include "types.h"


extern APEX_INTEGER CurrentProcess;		//  C-GLBD
extern APEX_INTEGER ERROR_HANDLER_PROCESS_ID;		//  C-GLBD
extern APEX_INTEGER LOCK_LEVEL;		//  C-GLBD
extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];
extern bool inode_bitmap[INODE_NUM];
extern bool block_bitmap[BLOCK_NUM];
extern char Directory_Name_Set[INODE_NUM][MAX_FILE_NAME_LENGTH];
extern SuperBlock *super_block;
extern int8_t blocks[2621440];
extern int8_t blocks[2621440];
extern Inode inodes[512];
extern int32_t ROOT_DIRECTORY_ID;
extern int32_t CURRENT_DIRECTORY_ID;
extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];


void READ_FILE(FILE_ID_TYPE FILE_ID, MESSAGE_ADDR_TYPE MESSAGE_ADDR, MESSAGE_SIZE_TYPE IN_LENGTH, MESSAGE_SIZE_TYPE *OUT_LENGTH, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {		// 1 C-FUCD
	APEX_INTEGER File_Id_In_Current_Partition_Flag;		// 1.0 C-TYDE
	File_Id_In_Current_Partition_Flag = Invalid_File_Id_In_Current_Partition(FILE_ID);		// 1.1 C-ASS
	if (File_Id_In_Current_Partition_Flag == 0) {		// 1.2 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.2.0 C-ASS
		*ERRNO = EBADF;		// 1.2.1 C-ASS
		*OUT_LENGTH = -1;		// 1.2.2 C-ASS
		return;		// 1.2.3 C-RET
	}
	APEX_INTEGER File_Id_has_Operation_Flag;		// 1.3 C-TYDE
	File_Id_has_Operation_Flag = Invalid_File_Id_has_Operation(FILE_ID);		// 1.4 C-ASS
	if (File_Id_has_Operation_Flag == 0) {		// 1.5 C-IFS
		*RETURN_CODE = NOT_AVAILABLE;		// 1.5.0 C-ASS
		*ERRNO = EBUSY;		// 1.5.1 C-ASS
		*OUT_LENGTH = -1;		// 1.5.2 C-ASS
		return;		// 1.5.3 C-RET
	}
	APEX_INTEGER File_Id_Due_to_Owner_Action_Flag;		// 1.6 C-TYDE
	File_Id_Due_to_Owner_Action_Flag = Invalid_File_Id_Due_to_Owner_Action(FILE_ID);		// 1.7 C-ASS
	if (File_Id_Due_to_Owner_Action_Flag == 0) {		// 1.8 C-IFS
		*RETURN_CODE = NOT_AVAILABLE;		// 1.8.0 C-ASS
		*ERRNO = ESTALE;		// 1.8.1 C-ASS
		*OUT_LENGTH = -1;		// 1.8.2 C-ASS
		return;		// 1.8.3 C-RET
	}
	if (IN_LENGTH <= 0) {		// 1.9 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.9.0 C-ASS
		*ERRNO = EINVAL;		// 1.9.1 C-ASS
		*OUT_LENGTH = -1;		// 1.9.2 C-ASS
		return;		// 1.9.3 C-RET
	}
	if (IN_LENGTH > MAX_ATOMIC_SIZE) {		// 1.10 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.10.0 C-ASS
		*ERRNO = EFBIG;		// 1.10.1 C-ASS
		*OUT_LENGTH = -1;		// 1.10.2 C-ASS
		return;		// 1.10.3 C-RET
	}
	APEX_INTEGER Storage_Device_Contain_File_Id_Flag;		// 1.11 C-TYDE
	Storage_Device_Contain_File_Id_Flag = Invalid_Storage_Device_Contain_File_Id(FILE_ID);		// 1.12 C-ASS
	if (Storage_Device_Contain_File_Id_Flag == 0) {		// 1.13 C-IFS
		*RETURN_CODE = NOT_AVAILABLE;		// 1.13.0 C-ASS
		*ERRNO = EIO;		// 1.13.1 C-ASS
		*OUT_LENGTH = -1;		// 1.13.2 C-ASS
		return;		// 1.13.3 C-RET
	}
	APEX_INTEGER File_Postion_Greater_than_File_Size_Flag;		// 1.14 C-TYDE
	File_Postion_Greater_than_File_Size_Flag = Invalid_File_Postion_Greater_than_File_Size(FILE_ID);		// 1.15 C-ASS
	if (File_Postion_Greater_than_File_Size_Flag == 0) {		// 1.16 C-IFS
		*RETURN_CODE = INVALID_PARAM;		// 1.16.0 C-ASS
		*ERRNO = EIO;		// 1.16.1 C-ASS
		*OUT_LENGTH = -1;		// 1.16.2 C-ASS
		return;		// 1.16.3 C-RET
	}
	if (LOCK_LEVEL > 0) {		// 1.17 C-IFS
		*RETURN_CODE = INVALID_MODE;		// 1.17.0 C-ASS
		*ERRNO = EACCES;		// 1.17.1 C-ASS
		*OUT_LENGTH = -1;		// 1.17.2 C-ASS
		return;		// 1.17.3 C-RET
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {		// 1.18 C-IFS
		*RETURN_CODE = INVALID_MODE;		// 1.18.0 C-ASS
		*ERRNO = EACCES;		// 1.18.1 C-ASS
		*OUT_LENGTH = -1;		// 1.18.2 C-ASS
		return;		// 1.18.3 C-RET
	}
	APEX_INTEGER ID,File_Position,File_Size;		// 1.19 C-TYDE
	ID = FILE_ID;		// 1.20 C-ASS
	File_Position = inodes[ID].position;		// 1.21 C-ASS
	File_Size = inodes[ID].size;		// 1.22 C-ASS
	APEX_INTEGER Position_Add_Length;		// 1.23 C-TYDE
	Position_Add_Length = File_Position + IN_LENGTH;		// 1.24 C-ASS
	if (Position_Add_Length > File_Size) {		// 1.25 C-IFS
		*OUT_LENGTH = File_Size - File_Position;		// 1.25.0 C-ASS
	} else {		// 1.26 C-ELS
		*OUT_LENGTH = IN_LENGTH;		// 1.26.0 C-ASS
	}
	transfer_to_message(FILE_ID, *OUT_LENGTH,MESSAGE_ADDR);		// 1.27 C-ASS
	inodes[ID].position = File_Position + *OUT_LENGTH;		// 1.28 C-ASS
	*RETURN_CODE = NO_ERROR;		// 1.29 C-ASS
	*ERRNO = EUNCHANGE;		// 1.30 C-ASS
	return;		// 1.31 C-RET
}



