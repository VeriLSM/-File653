#include "arinc_fs.h"
#include "libc.h"
#include "types.h"
#include "fs.h"


extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];
extern bool inode_bitmap[INODE_NUM];
extern bool block_bitmap[BLOCK_NUM];
extern char Directory_Name_Set[INODE_NUM][MAX_FILE_NAME_LENGTH];
extern SuperBlock *super_block;
extern int8_t blocks[2621440];
extern Inode inodes[512];
extern int32_t ROOT_DIRECTORY_ID;
extern int32_t CURRENT_DIRECTORY_ID;

static APEX_INTEGER Invalid_File_Name_is_Open(FILE_NAME_TYPE FILE_NAME) {
	APEX_INTEGER ID,index,FILE_ID,FILE_ID;
	
	ID = ismember4(FILE_NAME, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	FILE_ID = inodes[ID].id;
	index = inode_bitmap[FILE_ID];
	return index;
}


