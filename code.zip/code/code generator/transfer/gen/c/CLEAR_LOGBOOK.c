#include "arinc_fs.h"
#include "libc.h"
#include "types.h"
#include "fs.h"




void CLEAR_LOGBOOK(LOGBOOK_ID_TYPE LOGBOOK_ID, RETURN_CODE_TYPE *RETURN_CODE) {
	if (LOGBOOK_ID != CURRENT_LOGBOOK_ID) {
		*RETURN_CODE = INVALID_PARAM;
		return;
	}
	init_set();
	CURRENT_LOGGED_MESSAGE_NUMBER = 0;
	CURRENT_IN_PROGRESS_MESSAGE_NUMBER = 0;
	CURRENT_ABORTED_MESSAGE_NUMBER = 0;
	*RETURN_CODE = NO_ERROR;
	return;
}

