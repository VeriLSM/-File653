#include "arinc_fs.h"
#include "libc.h"
#include "types.h"
#include "fs.h"



static APEX_INTEGER Invalid_Device_Is_Write_Protected(void) {
	APEX_INTEGER index;
	index = 1;
	return index;
}


