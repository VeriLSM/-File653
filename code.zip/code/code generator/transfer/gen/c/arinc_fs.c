#include "arinc_fs.h"
#include "libc.h"
#include "types.h"
#include "fs.h"
#include "ls.h"
#include "arinc_ls.h"


extern APEX_INTEGER PARTION_OPEN_FILES_NUMBERS;
extern APEX_INTEGER PARTION_EXIT_FILES_NUMBERS;
extern APEX_INTEGER LOCK_LEVEL;
extern APEX_INTEGER CurrentProcess;
extern APEX_INTEGER ERROR_HANDLER_PROCESS_ID;
extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];
extern bool inode_bitmap[INODE_NUM];
extern bool block_bitmap[BLOCK_NUM];
extern char Directory_Name_Set[INODE_NUM][MAX_FILE_NAME_LENGTH];
extern SuperBlock *super_block;
extern int8_t blocks[2621440];
extern Inode inodes[512];
extern int32_t ROOT_DIRECTORY_ID;
extern int32_t CURRENT_DIRECTORY_ID;

static APEX_INTEGER CapacityofDirectory(void) {
	APEX_INTEGER index;
	if (PARTION_OPEN_FILES_NUMBERS < PARTION_LIMIT_OPEN_FILE_NUMBERS) {
		index = PARTION_OPEN_FILES_NUMBERS + 1;
	} else {
		index = 0;
	}
	return index;
}

static APEX_INTEGER CapacityofFile(void) {
	APEX_INTEGER index;
	if ((PARTION_OPEN_FILES_NUMBERS < PARTION_LIMIT_OPEN_FILE_NUMBERS) && (PARTION_EXIT_FILES_NUMBERS < MAX_DIRECTORY_NUMBER)) {
		index = PARTION_EXIT_FILES_NUMBERS + 1;
	} else {
		index = 0;
	}
	return index;
}

static APEX_INTEGER CapacityofOpenFile(void) {
	APEX_INTEGER index;
	if (PARTION_OPEN_FILES_NUMBERS < PARTION_LIMIT_OPEN_FILE_NUMBERS) {
		index = PARTION_OPEN_FILES_NUMBERS + 1;
	} else {
		index = 0;
	}
	return index;
}

static void delete_directory(APEX_INTEGER DIRECTORY_ID,APEX_INTEGER DIR_ID){
    DirItem dir_list[8];
    int block_num = inodes[DIR_ID].dirBlock[0];
    memcpy(dir_list,blocks+BLOCK_SIZE*block_num,sizeof(dir_list));
    strcpy(dir_list[DIRECTORY_ID].itemName,"");
    dir_list[DIRECTORY_ID].inode = -1;
    memcpy(blocks+BLOCK_SIZE*block_num,dir_list,sizeof(dir_list));
    inodes[DIRECTORY_ID].id = -1;
    inodes[DIRECTORY_ID].cnt = 0;
    inodes[DIRECTORY_ID].size = 0;
    inodes[DIRECTORY_ID].position = 0;
    inodes[DIRECTORY_ID].nb_of_changes = 0;
    inodes[DIRECTORY_ID].nb_of_write_errors = 0;
    inodes[DIRECTORY_ID].is_open = false;
    inodes[DIRECTORY_ID].mode = READ_WRITE;
    inodes[DIRECTORY_ID].entry = OTHER_ENTRY;
    inodes[DIRECTORY_ID].dirBlock[0] = -1;
    super_block->free_block_num++;
    super_block->free_inode_num++;
    inode_bitmap[DIRECTORY_ID] = false;
}


static void delete_file(APEX_INTEGER FILE_ID,APEX_INTEGER DIR_ID){
    DirItem dir_list[8];
    int block_num = inodes[DIR_ID].dirBlock[0];
    memcpy(dir_list,blocks+BLOCK_SIZE*block_num,sizeof(dir_list));
    strcpy(dir_list[FILE_ID].itemName,"");
    dir_list[FILE_ID].inode = -1;
    memcpy(blocks+BLOCK_SIZE*block_num,dir_list,sizeof(dir_list));
    inodes[DIR_ID].cnt = inodes[DIR_ID].cnt - 1;
    inodes[FILE_ID].id = -1;
    inodes[FILE_ID].cnt = 0;
    inodes[FILE_ID].size = 0;
    inodes[FILE_ID].position = 0;
    inodes[FILE_ID].nb_of_changes = 0;
    inodes[FILE_ID].nb_of_write_errors = 0;
    inodes[FILE_ID].is_open = false;
    inodes[FILE_ID].mode = READ_WRITE;
    inodes[FILE_ID].entry = OTHER_ENTRY;
    inodes[FILE_ID].dirBlock[0] = -1;
    super_block->free_block_num++;
    super_block->free_inode_num++;
    inode_bitmap[FILE_ID] = false;
}


static void get_volume_name(FILE_NAME_TYPE FILE_NAME,FILE_NAME_TYPE volume_name){
    strcpy(volume_name,"C:/");
}


static APEX_INTEGER Invalid_Create_File_in_New_Directory(FILE_NAME_TYPE NEW_FILE_NAME) {
	APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];
	get_file_prefix(NEW_FILE_NAME,path_prefix);
	APEX_INTEGER DIR_ID,index;
	
	DIR_ID = ismember4(path_prefix, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	if (inodes[DIR_ID].cnt < DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS) {
		index = 1;
	} else {
		index = 0;
	}
	return index;
}

static APEX_INTEGER Invalid_Device_Is_Write_Protected(void) {
	APEX_INTEGER index;
	index = 1;
	return index;
}

static APEX_INTEGER Invalid_Directory_Id_Due_to_Owner_Action(DIRECTORY_ID_TYPE DIRECTORY_ID) {
	APEX_INTEGER index;
	index = 1;
	return index;
}

static APEX_INTEGER Invalid_Directory_Id_has_Operation(DIRECTORY_ID_TYPE DIRECTORY_ID) {
	APEX_INTEGER index;
	index = 1;
	return index;
}

static APEX_INTEGER Invalid_Directory_Id_In_Current_Partition(DIRECTORY_ID_TYPE DIRECTORY_ID) {
	APEX_INTEGER index;
	if (DIRECTORY_ID <= 0 || DIRECTORY_ID > SYSTEM_LIMIT_FILE_SIZE) {
		index = 0;
	} else {
		index = inode_bitmap[DIRECTORY_ID];
	}
	return index;
}

static APEX_INTEGER Invalid_Directory_is_Open_by_Owning_Partion(FILE_NAME_TYPE DIRECTORY_NAME) {
	APEX_INTEGER index;
	index = 1;
	return index;
}

static APEX_INTEGER Invalid_Directory_Length(FILE_NAME_TYPE DIRECTORY_NAME) {
	APEX_INTEGER index,len;
	len = strlength(DIRECTORY_NAME);
	if (len > 0 && len < MAX_DIRECTORY_ENTRY_LENGTH) {
		index = 1;
	} else {
		index = 0;
	}
	return index;
}

static APEX_INTEGER Invalid_Directory_Name_is_not_Empty(FILE_NAME_TYPE DIRECTORY_NAME) {
	APEX_INTEGER DIR_ID;
	
	DIR_ID = ismember4(DIRECTORY_NAME, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	APEX_INTEGER index;
	if (inodes[DIR_ID].cnt == 0) {
		index = 1;
	} else {
		index = 0;
	}
	return index;
}

static APEX_INTEGER Invalid_Directory_Name_is_Root_Directory(FILE_NAME_TYPE DIRECTORY_NAME){
    APEX_INTEGER index;
    if (strcmp(DIRECTORY_NAME,"C:/") == 0){
        index = 0;
    }
    else{
        index = 1;
    }
    return index;
}


static APEX_INTEGER Invalid_Directory_Syntax(FILE_NAME_TYPE DIRECTORY_NAME){
    APEX_INTEGER index;
    index = 1;
    return index;
}


static APEX_INTEGER Invalid_Existing_Directory(FILE_NAME_TYPE FILE_NAME) {
	APEX_INTEGER DIR_ID,index;
	
	DIR_ID = ismember4(FILE_NAME, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	if (DIR_ID == 0) {
		index = 1;
		return index;
	}
	if (inodes[DIR_ID].entry != DIRECTORY_ENTRY) {
		index = 1;
		return index;
	}
	index = 0;
	return index;
}

static APEX_INTEGER Invalid_Existing_File(FILE_NAME_TYPE FILE_NAME) {
	APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];
	APEX_INTEGER DIR_ID,index,pos,ID;
    //	path_prefix = get_file_prefix(FILE_NAME);
    get_file_prefix(FILE_NAME,path_prefix);

	DIR_ID = ismember4(path_prefix, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	if (DIR_ID == -1) {
		index = 0;
		return index;
	}
	DirItem dir_list[8];
	int block_num = inodes[CURRENT_DIRECTORY_ID].dirBlock[0];
    memcpy(dir_list,blocks+BLOCK_SIZE*block_num,sizeof(dir_list));
    char Sub_Directory_Set[DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS][MAX_FILE_NAME_LENGTH];
	for (int i = 0; i < DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS; i++) {
		strcpy(Sub_Directory_Set[i],dir_list[i].itemName);
		}
	pos = ismember4(FILE_NAME, Sub_Directory_Set,DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS);
	if (pos == -1) {
		index = 0;
		return index;
	}
	ID = ismember4(FILE_NAME, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	if (inodes[ID].entry != FILE_ENTRY) {
		index = 0;
	} else {
		index = 1;
	}
	return index;
}


static APEX_INTEGER Invalid_Existing_Filename_Is_Read_Write(FILE_NAME_TYPE FILE_NAME) {
	APEX_INTEGER ID,index,j;
	
	ID = ismember4(FILE_NAME, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	if (ID == 0) {
		index = 0;
		return index;
	}
	if (inodes[ID].mode == READ) {
		index = 0;
		return index;
	}
	j = inode_bitmap[ID];
	if (j == 0) {
		index = 0;
		return index;
	}
	index = 1;
	return index;
}

static APEX_INTEGER Invalid_File_Id_Due_to_Owner_Action(FILE_ID_TYPE FILE_ID) {
	APEX_INTEGER index;
	index = 1;
	return index;
}

static APEX_INTEGER Invalid_File_Id_has_Operation(FILE_ID_TYPE FILE_ID) {
	APEX_INTEGER index;
	index = 1;
	return index;
}

static APEX_INTEGER Invalid_File_Id_has_Read_Write_Access_Mode(FILE_ID_TYPE FILE_ID) {
	APEX_INTEGER index;
	APEX_INTEGER ID;
	ID = FILE_ID;
	if (inodes[ID].is_open == READ_WRITE) {
		index = 1;
	} else {
		index = 0;
	}
	return index;
}

static APEX_INTEGER Invalid_File_Id_In_Current_Partition(FILE_ID_TYPE FILE_ID) {
	APEX_INTEGER index;
	if (FILE_ID <= 0 || FILE_ID > SYSTEM_LIMIT_FILE_SIZE) {
		index = 0;
	} else {
		index = inode_bitmap[FILE_ID];
	}
	return index;
}

static APEX_INTEGER Invalid_File_Id_is_Read_Only(FILE_ID_TYPE FILE_ID) {
	APEX_INTEGER index;
	APEX_INTEGER ID;
	ID = FILE_ID;
	if (inodes[ID].mode == READ) {
		index = 0;
	} else {
		index = 1;
	}
	return index;
}

static APEX_INTEGER Invalid_File_Length(FILE_NAME_TYPE FILE_NAME) {
	APEX_INTEGER index,len;
	len = strlength(FILE_NAME);
	if (len > 0 && len < MAX_FILE_NAME_LENGTH) {
		index = 1;
	} else {
		index = 0;
	}
	return index;
}

static APEX_INTEGER Invalid_FILE_MODE(FILE_MODE_TYPE FILE_MODE) {
	APEX_INTEGER index;
	if (FILE_MODE == READ || FILE_MODE == READ_WRITE) {
		index = 1;
	} else {
		index = 0;
	}
	return index;
}

static APEX_INTEGER Invalid_File_Name_has_Operation(FILE_NAME_TYPE FILE_NAME) {
	APEX_INTEGER index;
	index = 1;
	return index;
}

static APEX_INTEGER Invalid_File_Name_is_Existing_File_Directory_Volume(FILE_NAME_TYPE FILE_NAME) {
	APEX_BYTE volume_name[MAX_FILE_NAME_LENGTH];
	APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];
	APEX_INTEGER VOL_ID,DIR_ID,index,ID;
	get_volume_name(FILE_NAME,volume_name);
	get_file_prefix(FILE_NAME,path_prefix);
	
	VOL_ID = ismember4(volume_name, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	index = VOL_ID +1;
	if (index == 0) {
		return index;
	}
	DIR_ID = ismember4(path_prefix, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	index = DIR_ID +1;
	if (index == 0) {
		return index;
	}
	ID = ismember4(FILE_NAME, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	index = ID +1;
	return index;
}

static APEX_INTEGER Invalid_File_Name_is_Open(FILE_NAME_TYPE FILE_NAME) {
	APEX_INTEGER ID,index,FILE_ID;
	
	ID = ismember4(FILE_NAME, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	FILE_ID = inodes[ID].id;
	index = inode_bitmap[FILE_ID];
	return index;
}

static APEX_INTEGER Invalid_File_Path_Prefix(FILE_NAME_TYPE FILE_NAME) {
	APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];
	APEX_INTEGER index,DIR_ID;
	get_file_prefix(FILE_NAME,path_prefix);
	
	DIR_ID = ismember4(path_prefix, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	index = DIR_ID +1;
	return index;
}

static APEX_INTEGER Invalid_File_Postion_Greater_than_File_Size(FILE_ID_TYPE FILE_ID) {
	APEX_INTEGER ID,File_Position;
	APEX_INTEGER File_Size,index;
	ID = FILE_ID;
	File_Position = inodes[ID].position;
	File_Size = inodes[ID].size;
	if (File_Position > File_Size) {
		index = 0;
		return index;
	}
	index = 1;
	return index;
}

static APEX_INTEGER Invalid_File_Syntax(FILE_NAME_TYPE FILE_NAME){
    APEX_INTEGER index;
    index = 1;
    return index;
}


static APEX_INTEGER Invalid_Length_Greater_than_Miximun(MESSAGE_SIZE_TYPE LENGTH) {
	APEX_INTEGER index;
	if (LENGTH <= MAX_ATOMIC_SIZE) {
		index = 1;
	} else {
		index = 0;
	}
	return index;
}

static APEX_INTEGER Invalid_Offset_value(FILE_SIZE_TYPE OFFSET, FILE_SIZE_TYPE File_Size) {
	APEX_INTEGER index;
	if (OFFSET >= 0 && OFFSET < File_Size) {
		index = 1;
		return index;
	}
	index = 0;
	return index;
}

static APEX_INTEGER Invalid_OLD_New_File_Name_Volume_Identical(FILE_NAME_TYPE OLD_FILE_NAME,FILE_NAME_TYPE NEW_FILE_NAME){
    APEX_INTEGER index;
    index = 1;
    return index;
}


static APEX_INTEGER Invalid_Partion_Has_Write_Read_Rights(FILE_NAME_TYPE FILE_NAME) {
	APEX_INTEGER index;
	index = 1;
	return index;
}

static APEX_INTEGER Invalid_Partition_Access_Rights(FILE_MODE_TYPE FILE_MODE, FILE_NAME_TYPE FILE_NAME) {
	APEX_INTEGER index;
	index = 1;
	return index;
}

static APEX_INTEGER Invalid_Partition_Read_Write_Access_Rights(FILE_NAME_TYPE File_NAME) {
	APEX_INTEGER index;
	index = 1;
	return index;
}

static APEX_INTEGER Invalid_Storage_Device_Contain_Directory(FILE_NAME_TYPE DIRECTORY_NAME) {
	APEX_INTEGER index;
	index = 1;
	return index;
}

static APEX_INTEGER Invalid_Storage_Device_Contain_Directory_Id(DIRECTORY_ID_TYPE DIRECTORY_ID) {
	APEX_INTEGER index;
	index = 1;
	return index;
}

static APEX_INTEGER Invalid_Storage_Device_Contain_Directory_Name(FILE_NAME_TYPE DIRECTORY_NAME) {
	APEX_INTEGER index;
	index = 1;
	return index;
}

static APEX_INTEGER Invalid_Storage_Device_Contain_File_Id(FILE_ID_TYPE FILE_ID) {
	APEX_INTEGER index;
	index = 1;
	return index;
}

static APEX_INTEGER Invalid_Storage_Device_Contain_File_Name(FILE_NAME_TYPE File_NAME) {
	APEX_INTEGER index;
	index = 1;
	return index;
}

static APEX_INTEGER Invalid_Volume_Space_Available(FILE_NAME_TYPE FILE_NAME) {
    APEX_INTEGER free_bytes,index;
    free_bytes = super_block->free_block_num;
    if (free_bytes > 1) {
        index = 1;
    } else {
        index = 0;
    }
    return index;
}


static APEX_INTEGER Invalid_Volume_Space_Available_Length(MESSAGE_SIZE_TYPE LENGTH) {
    APEX_INTEGER free_bytes,index;
    free_bytes = super_block->free_block_num;
    if (free_bytes > 1) {
        index = 1;
    } else {
        index = 0;
    }
    return index;
}


static APEX_INTEGER Invalid_Volume_Space_Available_to_New_Size(FILE_ID_TYPE FILE_ID, FILE_SIZE_TYPE NEW_SIZE) {
	APEX_INTEGER index;
	if (super_block->free_block_num > NEW_SIZE) {
		index = 1;
	} else {
		index = 0;
	}
	return index;
}

static APEX_INTEGER Invalid_Whence_Type(FILE_SEEK_TYPE WHENCE) {
	APEX_INTEGER index;
	index = 0;
	if (WHENCE == SEEK_SET_TYPE || WHENCE == SEEK_CUR_TYPE || WHENCE == SEEK_END_TYPE) {
		index = 1;
	}
	return index;
}

static APEX_INTEGER search_directory(APEX_INTEGER DIR_ID,FILE_NAME_TYPE FILE_NAME){
    APEX_INTEGER FILE_ID = -1;
    DirItem dir_list[8];
    int block_num = inodes[DIR_ID].dirBlock[0];
    memcpy(dir_list,blocks+BLOCK_SIZE*block_num,sizeof(dir_list));
    int32_t cnt = inodes[DIR_ID].cnt;
    for (int i = 0;i<=cnt;i++){
        if (strcmp(FILE_NAME,dir_list[i].itemName)==0){
            FILE_ID = dir_list[i].inode;
        }
    }
    return FILE_ID;
}


static void transfer_from_message(FILE_ID_TYPE FILE_ID,MESSAGE_ADDR_TYPE MESSAGE_ADDR,MESSAGE_SIZE_TYPE LENGTH){
    int block_num = inodes[FILE_ID].dirBlock[0];
    memcpy(blocks+BLOCK_SIZE*block_num,MESSAGE_ADDR,LENGTH);
}


static void transfer_to_message(FILE_ID_TYPE FILE_ID,MESSAGE_SIZE_TYPE LENGTH,MESSAGE_ADDR_TYPE MESSAGE_ADDR){
    int block_num = inodes[FILE_ID].dirBlock[0];
    memcpy(MESSAGE_ADDR,blocks+BLOCK_SIZE*block_num,LENGTH);
}


static void write_directory(APEX_INTEGER DIR_ID,FILE_NAME_TYPE FILE_NAME,APEX_INTEGER Fileindex){
    DirItem dir_list[8];
    int block_num = inodes[CURRENT_DIRECTORY_ID].dirBlock[0];
    memcpy(dir_list,blocks+BLOCK_SIZE*block_num,sizeof(dir_list));
    int32_t cnt = inodes[DIR_ID].cnt;
    int flag = 0;
    for(int i = 0;i<=cnt;i++){
        if(dir_list[i].inode==Fileindex){
            flag = 1;
            strcpy(dir_list[i].itemName,FILE_NAME);
            break;
        }
    }
    if (flag==0){
        strcpy(dir_list[cnt].itemName,FILE_NAME);
        dir_list[cnt].inode = Fileindex;
    }
    memcpy(blocks+BLOCK_SIZE*block_num,dir_list,sizeof(dir_list));
    strcpy(Directory_Name_Set[Fileindex],FILE_NAME);
}



void CLOSE_DIRECTORY(DIRECTORY_ID_TYPE DIRECTORY_ID, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER Directory_Id_In_Current_Partition_Flag;
	Directory_Id_In_Current_Partition_Flag = Invalid_Directory_Id_In_Current_Partition(DIRECTORY_ID);
	if (Directory_Id_In_Current_Partition_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EBADF;
		return;
	}
	APEX_INTEGER Directory_Id_has_Operation_Flag;
	Directory_Id_has_Operation_Flag = Invalid_Directory_Id_has_Operation(DIRECTORY_ID);
	if (Directory_Id_has_Operation_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EBUSY;
		return;
	}
	APEX_INTEGER Storage_Device_Contain_Directory_Id_Flag;
	Storage_Device_Contain_Directory_Id_Flag = Invalid_Storage_Device_Contain_Directory_Id(DIRECTORY_ID);
	if (Storage_Device_Contain_Directory_Id_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER DIR_ID;
	DIR_ID = DIRECTORY_ID;
	inode_bitmap[DIR_ID] = 0;
	PARTION_OPEN_FILES_NUMBERS = PARTION_OPEN_FILES_NUMBERS - 1;
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

void CLOSE_FILE(FILE_ID_TYPE FILE_ID, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER File_Id_In_Current_Partition_Flag;
	File_Id_In_Current_Partition_Flag = Invalid_File_Id_In_Current_Partition(FILE_ID);
	if (File_Id_In_Current_Partition_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EBADF;
		return;
	}
	APEX_INTEGER File_Id_has_Operation_Flag;
	File_Id_has_Operation_Flag = Invalid_File_Id_has_Operation(FILE_ID);
	if (File_Id_has_Operation_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EBUSY;
		return;
	}
	APEX_INTEGER Storage_Device_Contain_File_ID_Flag;
	Storage_Device_Contain_File_ID_Flag = Invalid_Storage_Device_Contain_File_Id(FILE_ID);
	if (Storage_Device_Contain_File_ID_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	FILE_MODE_TYPE access_right;
	APEX_INTEGER ID;
	ID = FILE_ID;
	access_right = inodes[ID].mode;
	if (access_right == READ_WRITE) {
	}
	inode_bitmap[FILE_ID] = 0;
	PARTION_OPEN_FILES_NUMBERS = PARTION_OPEN_FILES_NUMBERS - 1;
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

void GET_FILE_STATUS(FILE_ID_TYPE FILE_ID, FILE_STATUS_TYPE *FILE_STATUS, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER File_Id_Current_Partition_Flag;
	File_Id_Current_Partition_Flag = Invalid_File_Id_In_Current_Partition(FILE_ID);
	if (File_Id_Current_Partition_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EBADF;
		FILE_STATUS->POSITION = -1;
		FILE_STATUS->SIZE = -1;
		FILE_STATUS->NB_OF_CHANGES = -1;
		FILE_STATUS->NB_OF_WRITE_ERRORS = -1;
		return;
	}
	APEX_INTEGER File_Id_has_Operation_Flag;
	File_Id_has_Operation_Flag = Invalid_File_Id_has_Operation(FILE_ID);
	if (File_Id_has_Operation_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EBUSY;
		FILE_STATUS->POSITION = -1;
		FILE_STATUS->SIZE = -1;
		FILE_STATUS->NB_OF_CHANGES = -1;
		FILE_STATUS->NB_OF_WRITE_ERRORS = -1;
		return;
	}
	APEX_INTEGER File_Id_Owner_Action_Flag;
	File_Id_Owner_Action_Flag = Invalid_File_Id_Due_to_Owner_Action(FILE_ID);
	if (File_Id_Owner_Action_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = ESTALE;
		FILE_STATUS->POSITION = -1;
		FILE_STATUS->SIZE = -1;
		FILE_STATUS->NB_OF_CHANGES = -1;
		FILE_STATUS->NB_OF_WRITE_ERRORS = -1;
		return;
	}
	APEX_INTEGER Storage_Device_Flag;
	Storage_Device_Flag = Invalid_Storage_Device_Contain_File_Id(FILE_ID);
	if (Storage_Device_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		FILE_STATUS->POSITION = -1;
		FILE_STATUS->SIZE = -1;
		FILE_STATUS->NB_OF_CHANGES = -1;
		FILE_STATUS->NB_OF_WRITE_ERRORS = -1;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		FILE_STATUS->POSITION = -1;
		FILE_STATUS->SIZE = -1;
		FILE_STATUS->NB_OF_CHANGES = -1;
		FILE_STATUS->NB_OF_WRITE_ERRORS = -1;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		FILE_STATUS->POSITION = -1;
		FILE_STATUS->SIZE = -1;
		FILE_STATUS->NB_OF_CHANGES = -1;
		FILE_STATUS->NB_OF_WRITE_ERRORS = -1;
		return;
	}
	APEX_INTEGER ID;
	ID = FILE_ID;
	FILE_STATUS->POSITION = inodes[ID].position;
	FILE_STATUS->SIZE = inodes[ID].size;
	FILE_STATUS->NB_OF_CHANGES = inodes[ID].nb_of_changes;
	FILE_STATUS->NB_OF_WRITE_ERRORS = inodes[ID].nb_of_write_errors;
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

void GET_VOLUME_STATUS(FILE_NAME_TYPE FILE_NAME, VOLUME_STATUS_TYPE *VOLUME_STATUS, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER File_length_Flag;
	File_length_Flag = Invalid_File_Length(FILE_NAME);
	if (File_length_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENAMETOOLONG;
		VOLUME_STATUS->TOTAL_BYTES = 0;
		VOLUME_STATUS->USED_BYTES = 0;
		return;
	}
	APEX_INTEGER File_Syntax_Flag;
	File_Syntax_Flag = Invalid_File_Syntax(FILE_NAME);
	if (File_Syntax_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		VOLUME_STATUS->TOTAL_BYTES = 0;
		VOLUME_STATUS->USED_BYTES = 0;
		VOLUME_STATUS->FREE_BYTES = 0;
		return;
	}
	APEX_INTEGER File_Path_Prefix_Flag;
	File_Path_Prefix_Flag = Invalid_File_Path_Prefix(FILE_NAME);
	if (File_Path_Prefix_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENOTDIR;
		VOLUME_STATUS->TOTAL_BYTES = 0;
		VOLUME_STATUS->USED_BYTES = 0;
		VOLUME_STATUS->FREE_BYTES = 0;
		return;
	}
	APEX_INTEGER File_Name_is_Directory_Volume_Flag;
	File_Name_is_Directory_Volume_Flag = Invalid_File_Name_is_Existing_File_Directory_Volume(FILE_NAME);
	if (File_Name_is_Directory_Volume_Flag == 0) {
		*RETURN_CODE = INVALID_CONFIG;
		*ERRNO = ENOENT;
		VOLUME_STATUS->TOTAL_BYTES = 0;
		VOLUME_STATUS->USED_BYTES = 0;
		VOLUME_STATUS->FREE_BYTES = 0;
		return;
	}
	APEX_INTEGER Partion_Has_Write_Read_Rights_Flag;
	Partion_Has_Write_Read_Rights_Flag = Invalid_Partion_Has_Write_Read_Rights(FILE_NAME);
	if (Partion_Has_Write_Read_Rights_Flag == 0) {
		*RETURN_CODE = INVALID_CONFIG;
		*ERRNO = EACCES;
		VOLUME_STATUS->TOTAL_BYTES = 0;
		VOLUME_STATUS->USED_BYTES = 0;
		VOLUME_STATUS->FREE_BYTES = 0;
		return;
	}
	APEX_INTEGER Storage_Device_Contain_File_Name_Flag;
	Storage_Device_Contain_File_Name_Flag = Invalid_Storage_Device_Contain_File_Name(FILE_NAME);
	if (Storage_Device_Contain_File_Name_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		VOLUME_STATUS->TOTAL_BYTES = 0;
		VOLUME_STATUS->USED_BYTES = 0;
		VOLUME_STATUS->FREE_BYTES = 0;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		VOLUME_STATUS->TOTAL_BYTES = 0;
		VOLUME_STATUS->USED_BYTES = 0;
		VOLUME_STATUS->FREE_BYTES = 0;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		VOLUME_STATUS->TOTAL_BYTES = 0;
		VOLUME_STATUS->USED_BYTES = 0;
		VOLUME_STATUS->FREE_BYTES = 0;
		return;
	}
	VOLUME_STATUS->TOTAL_BYTES = super_block->block_num;
	VOLUME_STATUS->USED_BYTES = super_block->block_num - super_block->free_block_num;
	VOLUME_STATUS->FREE_BYTES = super_block->free_block_num;
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

void MAKE_DIRECTORY(FILE_NAME_TYPE DIRECTORY_NAME, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER Directory_length_Flag;
	Directory_length_Flag = Invalid_Directory_Length(DIRECTORY_NAME);
	if (Directory_length_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENAMETOOLONG;
		return;
	}
	APEX_INTEGER Directory_Syntax_Flag;
	Directory_Syntax_Flag = Invalid_Directory_Syntax(DIRECTORY_NAME);
	if (Directory_Syntax_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		return;
	}
	APEX_INTEGER File_Path_Prefix_Flag;
	File_Path_Prefix_Flag = Invalid_File_Path_Prefix(DIRECTORY_NAME);
	if (File_Path_Prefix_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENOTDIR;
		return;
	}
	APEX_INTEGER Partition_Read_Write_Access_Rights_Flag;
	Partition_Read_Write_Access_Rights_Flag = Invalid_Partition_Read_Write_Access_Rights(DIRECTORY_NAME);
	if (Partition_Read_Write_Access_Rights_Flag == 0) {
		*RETURN_CODE = INVALID_CONFIG;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER Device_Is_Write_Protected_Flag;
	Device_Is_Write_Protected_Flag = Invalid_Device_Is_Write_Protected();
	if (Device_Is_Write_Protected_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EROFS;
		return;
	}
	APEX_INTEGER Existing_Directory_Flag;
	Existing_Directory_Flag = Invalid_Existing_Directory(DIRECTORY_NAME);
	if (Existing_Directory_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EISDIR;
		return;
	}
	APEX_INTEGER Existing_File_Flag;
	Existing_File_Flag = Invalid_Existing_File(DIRECTORY_NAME);
	if (Existing_File_Flag != 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EEXIST;
		return;
	}
	APEX_INTEGER Volume_Space_Available_Flag;
	Volume_Space_Available_Flag = Invalid_Volume_Space_Available(DIRECTORY_NAME);
	if (Volume_Space_Available_Flag == 0) {
		*RETURN_CODE = INVALID_CONFIG;
		*ERRNO = ENOSPC;
		return;
	}
	APEX_INTEGER Volume_Storage_Device_Contain_Directory_Flag;
	Volume_Storage_Device_Contain_Directory_Flag = Invalid_Storage_Device_Contain_Directory(DIRECTORY_NAME);
	if (Volume_Storage_Device_Contain_Directory_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER DirectoryId;
	DirectoryId = CapacityofFile();
	APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];
	get_file_prefix(DIRECTORY_NAME,path_prefix);
	APEX_INTEGER DIR_ID;
	
	DIR_ID = ismember4(path_prefix, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	write_directory(DIR_ID, DIRECTORY_NAME, DirectoryId);
	inodes[DIR_ID].cnt = inodes[DIR_ID].cnt + 1;
	APEX_INTEGER ID;
	ID = DirectoryId;
	inodes[ID].id = DirectoryId;
	inodes[ID].position = 0;
	inodes[ID].size = 0;
	inodes[ID].nb_of_changes = 0;
	inodes[ID].nb_of_write_errors = 0;
	//inode.content = "";
	inodes[ID].is_open = 1;
	inodes[ID].mode = READ_WRITE;
	inodes[ID].entry = DIRECTORY_ENTRY;
	inodes[ID].cnt = 0;
	PARTION_EXIT_FILES_NUMBERS = PARTION_EXIT_FILES_NUMBERS + 1;
	super_block->block_num = super_block->block_num - 1;
	super_block->free_inode_num = super_block->free_inode_num - 1;
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

void OPEN_DIRECTORY(FILE_NAME_TYPE DIRECTORY_NAME, DIRECTORY_ID_TYPE *DIRECTORY_ID, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER Directory_index;
	Directory_index = CapacityofDirectory();
	if (Directory_index == 0) {
		*DIRECTORY_ID = -1;
		*RETURN_CODE = INVALID_CONFIG;
		*ERRNO = EMFILE;
		return;
	}
	APEX_INTEGER Directory_length_Flag;
	Directory_length_Flag = Invalid_Directory_Length(DIRECTORY_NAME);
	if (Directory_length_Flag == 0) {
		*DIRECTORY_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENAMETOOLONG;
		return;
	}
	APEX_INTEGER Directory_Syntax_Flag;
	Directory_Syntax_Flag = Invalid_Directory_Syntax(DIRECTORY_NAME);
	if (Directory_Syntax_Flag == 0) {
		*DIRECTORY_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		return;
	}
	APEX_INTEGER File_Path_Prefix_Flag;
	File_Path_Prefix_Flag = Invalid_File_Path_Prefix(DIRECTORY_NAME);
	if (File_Path_Prefix_Flag == 0) {
		*DIRECTORY_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENOTDIR;
		return;
	}
	APEX_INTEGER Existing_File_Flag;
	Existing_File_Flag = Invalid_Existing_File(DIRECTORY_NAME);
	if (Existing_File_Flag != 0) {
		*DIRECTORY_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EEXIST;
		return;
	}
	APEX_INTEGER Existing_Directory_Flag;
	Existing_Directory_Flag = Invalid_Existing_Directory(DIRECTORY_NAME);
	if (Existing_Directory_Flag == 1) {
		*DIRECTORY_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EISDIR;
		return;
	}
	APEX_INTEGER Partition_Access_Rights_Flag;
	Partition_Access_Rights_Flag = Invalid_Partition_Access_Rights(READ_WRITE, DIRECTORY_NAME);
	if (Partition_Access_Rights_Flag == 0) {
		*DIRECTORY_ID = -1;
		*RETURN_CODE = INVALID_CONFIG;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER Storage_Device_Contain_File_Name_Flag;
	Storage_Device_Contain_File_Name_Flag = Invalid_Storage_Device_Contain_File_Name(DIRECTORY_NAME);
	if (Storage_Device_Contain_File_Name_Flag == 0) {
		*DIRECTORY_ID = -1;
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*DIRECTORY_ID = -1;
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*DIRECTORY_ID = -1;
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER DIR_ID;
	
	DIR_ID = ismember4(DIRECTORY_NAME, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	*DIRECTORY_ID = DIR_ID;
	APEX_INTEGER tag;
	tag = inode_bitmap[DIR_ID];
	if (tag == 0) {
		inodes[DIR_ID].nb_of_changes = 0;
		inodes[DIR_ID].nb_of_write_errors = 0;
	}
	inode_bitmap[DIR_ID] = 1;
	inodes[DIR_ID].position = 0;
	PARTION_OPEN_FILES_NUMBERS = PARTION_OPEN_FILES_NUMBERS + 1;
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

void OPEN_FILE(FILE_NAME_TYPE FILE_NAME, FILE_MODE_TYPE FILE_MODE, FILE_ID_TYPE *FILE_ID, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER Fileindex;
	Fileindex = CapacityofOpenFile();
	if (Fileindex == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_CONFIG;
		*ERRNO = EMFILE;
		return;
	}
	APEX_INTEGER File_Length_Flag;
	File_Length_Flag = Invalid_File_Length(FILE_NAME);
	if (File_Length_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENAMETOOLONG;
		return;
	}
	APEX_INTEGER File_Syntax_Flag;
	File_Syntax_Flag = Invalid_File_Syntax(FILE_NAME);
	if (File_Syntax_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		return;
	}
	APEX_INTEGER File_Path_Prefix_Flag;
	File_Path_Prefix_Flag = Invalid_File_Path_Prefix(FILE_NAME);
	if (File_Path_Prefix_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENOTDIR;
		return;
	}
	APEX_INTEGER Partition_Mode_Flag;
	Partition_Mode_Flag = Invalid_FILE_MODE(FILE_MODE);
	if (Partition_Mode_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		return;
	}
	APEX_INTEGER Existing_Directory_Flag;
	Existing_Directory_Flag = Invalid_Existing_Directory(FILE_NAME);
	if (Existing_Directory_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EISDIR;
		return;
	}
	APEX_INTEGER Existing_File_Flag;
	Existing_File_Flag = Invalid_Existing_File(FILE_NAME);
	if (Existing_File_Flag > 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EEXIST;
		return;
	}
	APEX_INTEGER Existing_Filename_Is_Read_Write_Flag;
	Existing_Filename_Is_Read_Write_Flag = Invalid_Existing_Filename_Is_Read_Write(FILE_NAME);
	if (Existing_Filename_Is_Read_Write_Flag == 1 && FILE_MODE == READ_WRITE) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER Partition_Access_Rights_Flag;
	Partition_Access_Rights_Flag = Invalid_Partition_Access_Rights(FILE_MODE, FILE_NAME);
	if (Partition_Access_Rights_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_CONFIG;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER Device_Write_Protected_Flag;
	Device_Write_Protected_Flag = Invalid_Device_Is_Write_Protected();
	if (Device_Write_Protected_Flag == 0 && FILE_MODE == READ_WRITE) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EROFS;
		return;
	}
	APEX_INTEGER Storage_Device_Contain_File_ID_Flag;
	Storage_Device_Contain_File_ID_Flag = Invalid_Storage_Device_Contain_File_Name(FILE_NAME);
	if (Storage_Device_Contain_File_ID_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER ID;
	
	ID = ismember4(FILE_NAME, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	APEX_INTEGER tag;
	tag = inode_bitmap[ID];
	if (tag == 0) {
		inodes[ID].nb_of_changes = 0;
		inodes[ID].nb_of_write_errors = 0;
	}
	inode_bitmap[ID] = 1;
	inodes[ID].position = 0;
	PARTION_OPEN_FILES_NUMBERS = PARTION_OPEN_FILES_NUMBERS + 1;
	*FILE_ID = ID;
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

void OPEN_NEW_FILE(FILE_NAME_TYPE FILE_NAME, FILE_ID_TYPE *FILE_ID, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER Fileindex;
	Fileindex = CapacityofFile();
	if (Fileindex == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_CONFIG;
		*ERRNO = EMFILE;
		return;
	}
	APEX_INTEGER File_Length_Flag;
	File_Length_Flag = Invalid_File_Length(FILE_NAME);
	if (File_Length_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENAMETOOLONG;
		return;
	}
	APEX_INTEGER File_Syntax_Flag;
	File_Syntax_Flag = Invalid_File_Syntax(FILE_NAME);
	if (File_Syntax_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		return;
	}
	APEX_INTEGER File_Path_Prefix_Flag;
	File_Path_Prefix_Flag = Invalid_File_Path_Prefix(FILE_NAME);
	if (File_Path_Prefix_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENOTDIR;
		return;
	}
	APEX_INTEGER Invalid_Partition_Mode_Flag;
	Invalid_Partition_Mode_Flag = Invalid_Partition_Read_Write_Access_Rights(FILE_NAME);
	if (Invalid_Partition_Mode_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_CONFIG;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER Invalid_Device_Write_Protected_Flag;
	Invalid_Device_Write_Protected_Flag = Invalid_Device_Is_Write_Protected();
	if (Invalid_Device_Write_Protected_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EROFS;
		return;
	}
	APEX_INTEGER Existing_File_Flag;
	Existing_File_Flag = Invalid_Existing_File(FILE_NAME);
	if (Existing_File_Flag > 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EEXIST;
		return;
	}
	APEX_INTEGER Existing_Directory_Flag;
	Existing_Directory_Flag = Invalid_Existing_Directory(FILE_NAME);
	if (Existing_Directory_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EISDIR;
		return;
	}
	APEX_INTEGER Volume_Space_Flag;
	Volume_Space_Flag = Invalid_Volume_Space_Available(FILE_NAME);
	if (Volume_Space_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_CONFIG;
		*ERRNO = ENOSPC;
		return;
	}
	APEX_INTEGER Storage_Device_Flag;
	Storage_Device_Flag = Invalid_Storage_Device_Contain_File_Name(FILE_NAME);
	if (Storage_Device_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];
	get_file_prefix(FILE_NAME,path_prefix);
	APEX_INTEGER DIR_ID;
	
	DIR_ID = ismember4(path_prefix, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	write_directory(DIR_ID, FILE_NAME, Fileindex);
	inodes[DIR_ID].cnt = inodes[DIR_ID].cnt + 1;
	APEX_INTEGER ID;
	ID = Fileindex;
	*FILE_ID = ID;
	inodes[ID].id = ID;
	inodes[ID].position = 0;
	inodes[ID].size = 0;
	inodes[ID].nb_of_changes = 0;
	inodes[ID].nb_of_write_errors = 0;
	//inode.content = "";
	inodes[ID].is_open = 1;
	inodes[ID].mode = READ_WRITE;
	inodes[ID].entry = FILE_ENTRY;
	inodes[ID].cnt = 0;
	inodes[ID].dirBlock[0] = ID;
	PARTION_OPEN_FILES_NUMBERS = PARTION_OPEN_FILES_NUMBERS + 1;
	PARTION_EXIT_FILES_NUMBERS = PARTION_EXIT_FILES_NUMBERS + 1;
	inode_bitmap[ID] = 1;
	super_block->free_block_num = super_block->free_block_num - 1;
	super_block->free_inode_num = super_block->free_inode_num - 1;
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

void READ_DIRECTORY(DIRECTORY_ID_TYPE DIRECTORY_ID, DIRECTORY_ENTRY_TYPE *ENTRY_NAME, ENTRY_KIND_TYPE *ENTRY_KIND, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_BYTE tmp[MAX_FILE_NAME_LENGTH];
	APEX_INTEGER Directory_Id_In_Current_Partition_Flag;
	Directory_Id_In_Current_Partition_Flag = Invalid_Directory_Id_In_Current_Partition(DIRECTORY_ID);
	if (Directory_Id_In_Current_Partition_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EBADF;
		strcpy(*ENTRY_NAME, "");
		*ENTRY_KIND = DIRECTORY_ENTRY;
		return;
	}
	APEX_INTEGER Directory_Id_has_Operation_Flag;
	Directory_Id_has_Operation_Flag = Invalid_Directory_Id_has_Operation(DIRECTORY_ID);
	if (Directory_Id_has_Operation_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EBUSY;
		strcpy(*ENTRY_NAME, "");
		*ENTRY_KIND = DIRECTORY_ENTRY;
		return;
	}
	APEX_INTEGER Directory_Id_Due_to_Owner_Action_Flag;
	Directory_Id_Due_to_Owner_Action_Flag = Invalid_Directory_Id_Due_to_Owner_Action(DIRECTORY_ID);
	if (Directory_Id_Due_to_Owner_Action_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = ESTALE;
		strcpy(*ENTRY_NAME, "");
		*ENTRY_KIND = DIRECTORY_ENTRY;
		return;
	}
	APEX_INTEGER Storage_Device_Contain_Directory_Id_Flag;
	Storage_Device_Contain_Directory_Id_Flag = Invalid_Storage_Device_Contain_Directory_Id(DIRECTORY_ID);
	if (Storage_Device_Contain_Directory_Id_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		strcpy(*ENTRY_NAME, "");
		*ENTRY_KIND = DIRECTORY_ENTRY;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		strcpy(*ENTRY_NAME, "");
		*ENTRY_KIND = DIRECTORY_ENTRY;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		strcpy(*ENTRY_NAME, "");
		*ENTRY_KIND = DIRECTORY_ENTRY;
		return;
	}
	APEX_INTEGER position,ID;
	APEX_BYTE DIR_NAME[MAX_FILE_NAME_LENGTH];
	position = inodes[ID].position;
	if (position < DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS) {
		if (inodes[ID].entry == DIRECTORY_ENTRY) {
			strcpy(*ENTRY_NAME, DIR_NAME);
			*ENTRY_KIND = DIRECTORY_ENTRY;
		} else if (inodes[ID].entry == FILE_ENTRY) {
			strcpy(*ENTRY_NAME, DIR_NAME);
			*ENTRY_KIND = FILE_ENTRY;
		}
		inodes[ID].position = position + 1;
	} else {
		strcpy(*ENTRY_NAME, "");
		*ENTRY_KIND = DIRECTORY_ENTRY;
	}
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

void READ_FILE(FILE_ID_TYPE FILE_ID, MESSAGE_ADDR_TYPE MESSAGE_ADDR, MESSAGE_SIZE_TYPE IN_LENGTH, MESSAGE_SIZE_TYPE *OUT_LENGTH, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER File_Id_In_Current_Partition_Flag;
	File_Id_In_Current_Partition_Flag = Invalid_File_Id_In_Current_Partition(FILE_ID);
	if (File_Id_In_Current_Partition_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EBADF;
		*OUT_LENGTH = -1;
		return;
	}
	APEX_INTEGER File_Id_has_Operation_Flag;
	File_Id_has_Operation_Flag = Invalid_File_Id_has_Operation(FILE_ID);
	if (File_Id_has_Operation_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EBUSY;
		*OUT_LENGTH = -1;
		return;
	}
	APEX_INTEGER File_Id_Due_to_Owner_Action_Flag;
	File_Id_Due_to_Owner_Action_Flag = Invalid_File_Id_Due_to_Owner_Action(FILE_ID);
	if (File_Id_Due_to_Owner_Action_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = ESTALE;
		*OUT_LENGTH = -1;
		return;
	}
	if (IN_LENGTH <= 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		*OUT_LENGTH = -1;
		return;
	}
	if (IN_LENGTH > MAX_ATOMIC_SIZE) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EFBIG;
		*OUT_LENGTH = -1;
		return;
	}
	APEX_INTEGER Storage_Device_Contain_File_Id_Flag;
	Storage_Device_Contain_File_Id_Flag = Invalid_Storage_Device_Contain_File_Id(FILE_ID);
	if (Storage_Device_Contain_File_Id_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		*OUT_LENGTH = -1;
		return;
	}
	APEX_INTEGER File_Postion_Greater_than_File_Size_Flag;
	File_Postion_Greater_than_File_Size_Flag = Invalid_File_Postion_Greater_than_File_Size(FILE_ID);
	if (File_Postion_Greater_than_File_Size_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EIO;
		*OUT_LENGTH = -1;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		*OUT_LENGTH = -1;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		*OUT_LENGTH = -1;
		return;
	}
	APEX_INTEGER ID,File_Position,File_Size;
	ID = FILE_ID;
	File_Position = inodes[ID].position;
	File_Size = inodes[ID].size;
	APEX_INTEGER Position_Add_Length;
	Position_Add_Length = File_Position + IN_LENGTH;
	if (Position_Add_Length > File_Size) {
		*OUT_LENGTH = File_Size - File_Position;
	} else {
		*OUT_LENGTH = IN_LENGTH;
	}
	transfer_to_message(FILE_ID, *OUT_LENGTH,MESSAGE_ADDR);
	inodes[ID].position = File_Position + *OUT_LENGTH;
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

void REMOVE_DIRECTORY(FILE_NAME_TYPE DIRECTORY_NAME, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER Directory_length_Flag;
	Directory_length_Flag = Invalid_Directory_Length(DIRECTORY_NAME);
	if (Directory_length_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENAMETOOLONG;
		return;
	}
	APEX_INTEGER Directory_Synta_Flag;
	Directory_Synta_Flag = Invalid_Directory_Syntax(DIRECTORY_NAME);
	if (Directory_Synta_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		return;
	}
	APEX_INTEGER File_Path_Prefix_Flag;
	File_Path_Prefix_Flag = Invalid_File_Path_Prefix(DIRECTORY_NAME);
	if (File_Path_Prefix_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENOTDIR;
		return;
	}
	APEX_INTEGER Existing_File_Flag;
	Existing_File_Flag = Invalid_Existing_File(DIRECTORY_NAME);
	if (Existing_File_Flag != 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EEXIST;
		return;
	}
	APEX_INTEGER Existing_Directory_Flag;
	Existing_Directory_Flag = Invalid_Existing_Directory(DIRECTORY_NAME);
	if (Existing_Directory_Flag == 1) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EISDIR;
		return;
	}
	APEX_INTEGER Partition_Read_Write_Access_Rights_Flag;
	Partition_Read_Write_Access_Rights_Flag = Invalid_Partition_Read_Write_Access_Rights(DIRECTORY_NAME);
	if (Partition_Read_Write_Access_Rights_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER Directory_Name_is_Root_Directory_Flag;
	Directory_Name_is_Root_Directory_Flag = Invalid_Directory_Name_is_Root_Directory(DIRECTORY_NAME);
	if (Directory_Name_is_Root_Directory_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER Directory_Name_is_not_Empty_Flag;
	Directory_Name_is_not_Empty_Flag = Invalid_Directory_Name_is_not_Empty(DIRECTORY_NAME);
	if (Directory_Name_is_not_Empty_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENOTEMPTY;
		return;
	}
	APEX_INTEGER Directory_is_Open_by_Owning_Partion_Flag;
	Directory_is_Open_by_Owning_Partion_Flag = Invalid_Directory_is_Open_by_Owning_Partion(DIRECTORY_NAME);
	if (Directory_is_Open_by_Owning_Partion_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EBUSY;
		return;
	}
	APEX_INTEGER Storage_Device_Contain_Directory_Name_Flag;
	Storage_Device_Contain_Directory_Name_Flag = Invalid_Storage_Device_Contain_Directory_Name(DIRECTORY_NAME);
	if (Storage_Device_Contain_Directory_Name_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];
	get_file_prefix(DIRECTORY_NAME,path_prefix);
	APEX_INTEGER DIR_ID,DIRECTORY_ID;
	
	DIR_ID = ismember4(path_prefix, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	DIRECTORY_ID = search_directory(DIR_ID, DIRECTORY_NAME);
	delete_directory(DIRECTORY_ID, DIR_ID);
	inodes[DIR_ID].cnt = inodes[DIR_ID].cnt - 1;
	PARTION_EXIT_FILES_NUMBERS = PARTION_EXIT_FILES_NUMBERS - 1;
	super_block->block_num = super_block->block_num - 1;
	super_block->free_inode_num = super_block->free_inode_num - 1;
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

void REMOVE_FILE(FILE_NAME_TYPE FILE_NAME, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER File_length_Flag;
	File_length_Flag = Invalid_File_Length(FILE_NAME);
	if (File_length_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENAMETOOLONG;
		return;
	}
	APEX_INTEGER File_Syntax_Flag;
	File_Syntax_Flag = Invalid_File_Syntax(FILE_NAME);
	if (File_Syntax_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		return;
	}
	APEX_INTEGER File_Path_Prefix_Flag;
	File_Path_Prefix_Flag = Invalid_File_Path_Prefix(FILE_NAME);
	if (File_Path_Prefix_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENOTDIR;
		return;
	}
	APEX_INTEGER Existing_Directory_Flag;
	Existing_Directory_Flag = Invalid_Existing_Directory(FILE_NAME);
	if (Existing_Directory_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EPERM;
		return;
	}
	APEX_INTEGER Existing_File_Flag;
	Existing_File_Flag = Invalid_Existing_File(FILE_NAME);
	if (Existing_File_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENOENT;
		return;
	}
	APEX_INTEGER Partition_Read_Write_Access_Rights_Flag;
	Partition_Read_Write_Access_Rights_Flag = Invalid_Partition_Read_Write_Access_Rights(FILE_NAME);
	if (Partition_Read_Write_Access_Rights_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER File_Name_has_Operation_Flag;
	File_Name_has_Operation_Flag = Invalid_File_Name_has_Operation(FILE_NAME);
	if (File_Name_has_Operation_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EBUSY;
		return;
	}
	APEX_INTEGER Device_Protected_Flag;
	Device_Protected_Flag = Invalid_Device_Is_Write_Protected();
	if (Device_Protected_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EROFS;
		return;
	}
	APEX_INTEGER File_Name_Open_Flag;
	File_Name_Open_Flag = Invalid_File_Name_is_Open(FILE_NAME);
	if (File_Name_Open_Flag != 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EBUSY;
		return;
	}
	APEX_INTEGER Storage_Device_Contain_File_Name_Flag;
	Storage_Device_Contain_File_Name_Flag = Invalid_Storage_Device_Contain_File_Name(FILE_NAME);
	if (Storage_Device_Contain_File_Name_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];
	get_file_prefix(FILE_NAME,path_prefix);
	APEX_INTEGER DIR_ID,FILE_ID;
	
	DIR_ID = ismember4(path_prefix, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	FILE_ID = search_directory(DIR_ID, FILE_NAME);
	delete_file(FILE_ID, DIR_ID);
	inode_bitmap[FILE_ID] = 0;
	PARTION_EXIT_FILES_NUMBERS = PARTION_EXIT_FILES_NUMBERS - 1;
	super_block->block_num = super_block->block_num - 1;
	super_block->free_inode_num = super_block->free_inode_num - 1;
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

void RENAME_FILE(FILE_NAME_TYPE OLD_FILE_NAME, FILE_NAME_TYPE NEW_FILE_NAME, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER Old_File_length_Flag;
	Old_File_length_Flag = Invalid_File_Length(OLD_FILE_NAME);
	if (Old_File_length_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENAMETOOLONG;
		return;
	}
	APEX_INTEGER Old_File_Syntax_Flag;
	Old_File_Syntax_Flag = Invalid_File_Syntax(OLD_FILE_NAME);
	if (Old_File_Syntax_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		return;
	}
	APEX_INTEGER Old_File_Path_Prefix_Flag;
	Old_File_Path_Prefix_Flag = Invalid_File_Path_Prefix(OLD_FILE_NAME);
	if (Old_File_Path_Prefix_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENOTDIR;
		return;
	}
	APEX_INTEGER New_File_length_Flag;
	New_File_length_Flag = Invalid_File_Length(NEW_FILE_NAME);
	if (New_File_length_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENAMETOOLONG;
		return;
	}
	APEX_INTEGER New_File_Syntax_Flag;
	New_File_Syntax_Flag = Invalid_File_Syntax(NEW_FILE_NAME);
	if (New_File_Syntax_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		return;
	}
	APEX_INTEGER New_File_Path_Prefix_Flag;
	New_File_Path_Prefix_Flag = Invalid_File_Path_Prefix(NEW_FILE_NAME);
	if (New_File_Path_Prefix_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENOTDIR;
		return;
	}
	APEX_INTEGER Partition_Access_Rights_Flag;
	Partition_Access_Rights_Flag = Invalid_Partition_Read_Write_Access_Rights(OLD_FILE_NAME);
	if (Partition_Access_Rights_Flag == 0) {
		*RETURN_CODE = INVALID_CONFIG;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER File_Name_Operation_Flag;
	File_Name_Operation_Flag = Invalid_File_Name_has_Operation(OLD_FILE_NAME);
	if (File_Name_Operation_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EBUSY;
		return;
	}
	APEX_INTEGER Device_Protected_Flag;
	Device_Protected_Flag = Invalid_Device_Is_Write_Protected();
	if (Device_Protected_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EROFS;
		return;
	}
	APEX_INTEGER File_Name_Identical_Flag;
	File_Name_Identical_Flag = Invalid_OLD_New_File_Name_Volume_Identical(OLD_FILE_NAME, NEW_FILE_NAME);
	if (File_Name_Identical_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		return;
	}
	APEX_INTEGER Create_File_in_New_Directory_Flag;
	Create_File_in_New_Directory_Flag = Invalid_Create_File_in_New_Directory(NEW_FILE_NAME);
	if (Create_File_in_New_Directory_Flag == 0) {
		*RETURN_CODE = INVALID_CONFIG;
		*ERRNO = ENOSPC;
		return;
	}
	APEX_INTEGER Old_Existing_Directory_Flag;
	Old_Existing_Directory_Flag = Invalid_Existing_Directory(OLD_FILE_NAME);
	if (Old_Existing_Directory_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EPERM;
		return;
	}
	APEX_INTEGER New_Existing_Directory_Flag;
	New_Existing_Directory_Flag = Invalid_Existing_Directory(NEW_FILE_NAME);
	if (New_Existing_Directory_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EISDIR;
		return;
	}
	APEX_INTEGER Old_Existing_File_Flag;
	Old_Existing_File_Flag = Invalid_Existing_File(OLD_FILE_NAME);
	if (Old_Existing_File_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENOENT;
		return;
	}
	APEX_INTEGER New_Existing_File_Flag;
	New_Existing_File_Flag = Invalid_Existing_File(NEW_FILE_NAME);
	if (New_Existing_File_Flag == 1) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EEXIST;
		return;
	}
	APEX_INTEGER Old_File_Name_Open_Flag;
	Old_File_Name_Open_Flag = Invalid_File_Name_is_Open(OLD_FILE_NAME);
	if (Old_File_Name_Open_Flag > 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EBUSY;
		return;
	}
	APEX_INTEGER Old_Storage_Device_Contain_File_Name_Flag;
	Old_Storage_Device_Contain_File_Name_Flag = Invalid_Storage_Device_Contain_File_Name(OLD_FILE_NAME);
	if (Old_Storage_Device_Contain_File_Name_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		return;
	}
	APEX_INTEGER New_Storage_Device_Contain_File_Name_Flag;
	New_Storage_Device_Contain_File_Name_Flag = Invalid_Storage_Device_Contain_File_Name(NEW_FILE_NAME);
	if (New_Storage_Device_Contain_File_Name_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	APEX_BYTE old_path_prefix[MAX_FILE_NAME_LENGTH];
	get_file_prefix(OLD_FILE_NAME,old_path_prefix);
	APEX_BYTE new_path_prefix[MAX_FILE_NAME_LENGTH];
	get_file_prefix(NEW_FILE_NAME,new_path_prefix);
	APEX_INTEGER OLD_DIR_ID,NEW_DIR_ID,FILE_ID;
	
	OLD_DIR_ID = ismember4(old_path_prefix, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	NEW_DIR_ID = ismember4(new_path_prefix, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	FILE_ID = search_directory(OLD_DIR_ID, OLD_FILE_NAME);
	write_directory(NEW_DIR_ID, NEW_FILE_NAME, FILE_ID);
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

void RESIZE_FILE(FILE_ID_TYPE FILE_ID, FILE_SIZE_TYPE NEW_SIZE, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER File_Id_In_Current_Partition_Flag;
	File_Id_In_Current_Partition_Flag = Invalid_File_Id_In_Current_Partition(FILE_ID);
	if (File_Id_In_Current_Partition_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EBADF;
		return;
	}
	APEX_INTEGER File_Id_has_Operation_Flag;
	File_Id_has_Operation_Flag = Invalid_File_Id_has_Operation(FILE_ID);
	if (File_Id_has_Operation_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EBUSY;
		return;
	}
	APEX_INTEGER File_Id_is_Read_Only_Flag;
	File_Id_is_Read_Only_Flag = Invalid_File_Id_is_Read_Only(FILE_ID);
	if (File_Id_is_Read_Only_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EACCES;
		return;
	}
	if (NEW_SIZE < 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		return;
	}
	APEX_INTEGER Volume_Space_Available_to_New_Size_Flag;
	Volume_Space_Available_to_New_Size_Flag = Invalid_Volume_Space_Available_to_New_Size(FILE_ID, NEW_SIZE);
	if (Volume_Space_Available_to_New_Size_Flag == 0) {
		*RETURN_CODE = INVALID_CONFIG;
		*ERRNO = ENOSPC;
		return;
	}
	APEX_INTEGER Storage_Device_Contain_File_Id_Flag;
	Storage_Device_Contain_File_Id_Flag = Invalid_Storage_Device_Contain_File_Id(FILE_ID);
	if (Storage_Device_Contain_File_Id_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER File_Size,File_Position,ID;
	ID = FILE_ID;
	File_Size = inodes[ID].size;
	super_block->block_size = super_block->block_size + File_Size - NEW_SIZE;
	super_block->block_num = super_block->block_num - File_Size + NEW_SIZE;
	inodes[ID].size = NEW_SIZE;
	File_Position = inodes[ID].position;
	if (NEW_SIZE < File_Position) {
		inodes[ID].position = NEW_SIZE;
	}
	inodes[ID].nb_of_changes = inodes[ID].nb_of_changes + 1;
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

void REWIND_DIRECTORY(DIRECTORY_ID_TYPE DIRECTORY_ID, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER Directory_Id_In_Current_Partition_Flag;
	Directory_Id_In_Current_Partition_Flag = Invalid_Directory_Id_In_Current_Partition(DIRECTORY_ID);
	if (Directory_Id_In_Current_Partition_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EBADF;
		return;
	}
	APEX_INTEGER Directory_Id_has_Operation_Flag;
	Directory_Id_has_Operation_Flag = Invalid_Directory_Id_has_Operation(DIRECTORY_ID);
	if (Directory_Id_has_Operation_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EBUSY;
		return;
	}
	APEX_INTEGER Directory_Id_Due_to_Owner_Action_Flag;
	Directory_Id_Due_to_Owner_Action_Flag = Invalid_Directory_Id_Due_to_Owner_Action(DIRECTORY_ID);
	if (Directory_Id_Due_to_Owner_Action_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = ESTALE;
		return;
	}
	APEX_INTEGER Storage_Device_Contain_Directory_Id_Flag;
	Storage_Device_Contain_Directory_Id_Flag = Invalid_Storage_Device_Contain_Directory_Id(DIRECTORY_ID);
	if (Storage_Device_Contain_Directory_Id_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER DIR_ID;
	DIR_ID = DIRECTORY_ID;
	inodes[DIR_ID].position = 0;
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
}

void SEEK_FILE(FILE_ID_TYPE FILE_ID, FILE_SIZE_TYPE OFFSET, FILE_SEEK_TYPE WHENCE, FILE_SIZE_TYPE *POSITION, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER File_Id_In_Current_Partition_Flag;
	File_Id_In_Current_Partition_Flag = Invalid_File_Id_In_Current_Partition(FILE_ID);
	if (File_Id_In_Current_Partition_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EBADF;
		*POSITION = -1;
		return;
	}
	APEX_INTEGER File_Id_has_Operation_Flag;
	File_Id_has_Operation_Flag = Invalid_File_Id_has_Operation(FILE_ID);
	if (File_Id_has_Operation_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EBUSY;
		*POSITION = -1;
		return;
	}
	APEX_INTEGER File_Id_Due_to_Owner_Action_Flag;
	File_Id_Due_to_Owner_Action_Flag = Invalid_File_Id_Due_to_Owner_Action(FILE_ID);
	if (File_Id_Due_to_Owner_Action_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = ESTALE;
		*POSITION = -1;
		return;
	}
	APEX_INTEGER APEX_INTEGER_Flag;
	APEX_INTEGER_Flag = Invalid_Whence_Type(WHENCE);
	if (APEX_INTEGER_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		*POSITION = -1;
		return;
	}
	APEX_INTEGER File_Position,File_Size,ID;
	ID = FILE_ID;
	File_Position = inodes[ID].position;
	File_Size = inodes[ID].size;
	APEX_INTEGER Offset_value_Flag;
	Offset_value_Flag = Invalid_Offset_value(OFFSET, File_Size);
	if (WHENCE == SEEK_SET_TYPE && Offset_value_Flag < 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		*POSITION = -1;
		return;
	}
	Offset_value_Flag = Invalid_Offset_value(File_Position + OFFSET, File_Size);
	if (WHENCE == SEEK_CUR_TYPE && Offset_value_Flag < 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		*POSITION = -1;
		return;
	}
	Offset_value_Flag = Invalid_Offset_value(File_Size + OFFSET, File_Size);
	if (WHENCE == SEEK_END_TYPE && Offset_value_Flag < 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		*POSITION = -1;
		return;
	}
	APEX_INTEGER Storage_Device_Contain_File_Id_Flag;
	Storage_Device_Contain_File_Id_Flag = Invalid_Storage_Device_Contain_File_Id(FILE_ID);
	if (Storage_Device_Contain_File_Id_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		*POSITION = -1;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		*POSITION = -1;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		*POSITION = -1;
		return;
	}
	if (WHENCE == SEEK_SET_TYPE) {
		inodes[ID].position = OFFSET;
		*POSITION = OFFSET;
	} else if (WHENCE == SEEK_CUR_TYPE) {
		inodes[ID].position = File_Position + OFFSET;
		*POSITION = File_Position + OFFSET;
	} else {
		inodes[ID].position = File_Size + OFFSET;
		*POSITION = File_Size + OFFSET;
	}
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

void SYNC_FILE(FILE_ID_TYPE FILE_ID, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER File_Id_In_Current_Partition_Flag;
	File_Id_In_Current_Partition_Flag = Invalid_File_Id_In_Current_Partition(FILE_ID);
	if (File_Id_In_Current_Partition_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EBADF;
		return;
	}
	APEX_INTEGER File_Id_has_Operation_Flag;
	File_Id_has_Operation_Flag = Invalid_File_Id_has_Operation(FILE_ID);
	if (File_Id_has_Operation_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EBUSY;
		return;
	}
	APEX_INTEGER File_Id_has_Read_Write_Access_Mode_Flag;
	File_Id_has_Read_Write_Access_Mode_Flag = Invalid_File_Id_has_Read_Write_Access_Mode(FILE_ID);
	if (File_Id_has_Read_Write_Access_Mode_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER Storage_Device_Contain_File_Id_Flag;
	Storage_Device_Contain_File_Id_Flag = Invalid_Storage_Device_Contain_File_Id(FILE_ID);
	if (Storage_Device_Contain_File_Id_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

void WRITE_FILE(FILE_ID_TYPE FILE_ID, MESSAGE_ADDR_TYPE MESSAGE_ADDR, MESSAGE_SIZE_TYPE LENGTH, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER File_Id_In_Current_Partition_Flag;
	File_Id_In_Current_Partition_Flag = Invalid_File_Id_In_Current_Partition(FILE_ID);
	if (File_Id_In_Current_Partition_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EBADF;
		return;
	}
	APEX_INTEGER File_Id_has_Operation_Flag;
	File_Id_has_Operation_Flag = Invalid_File_Id_has_Operation(FILE_ID);
	if (File_Id_has_Operation_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EBUSY;
		return;
	}
	APEX_INTEGER File_Id_has_Read_Write_Access_Mode_Flag;
	File_Id_has_Read_Write_Access_Mode_Flag = Invalid_File_Id_has_Read_Write_Access_Mode(FILE_ID);
	if (File_Id_has_Read_Write_Access_Mode_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EACCES;
		return;
	}
	if (LENGTH <= 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		return;
	}
	APEX_INTEGER Volume_Space_Flag;
	Volume_Space_Flag = Invalid_Volume_Space_Available_Length(LENGTH);
	if (Volume_Space_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENOSPC;
		return;
	}
	APEX_INTEGER Length_Greater_than_Miximun_Flag;
	Length_Greater_than_Miximun_Flag = Invalid_Length_Greater_than_Miximun(LENGTH);
	if (Length_Greater_than_Miximun_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EFBIG;
		return;
	}
	APEX_INTEGER Storage_Device_Contain_File_ID_Flag;
	Storage_Device_Contain_File_ID_Flag = Invalid_Storage_Device_Contain_File_Id(FILE_ID);
	if (Storage_Device_Contain_File_ID_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER File_Position,File_Size,File_Nb_Of_Changes,ID;
	ID = FILE_ID;
	File_Position = inodes[ID].position + LENGTH;
	inodes[ID].position = File_Position;
	File_Size = inodes[ID].size;
	File_Nb_Of_Changes = inodes[ID].nb_of_changes;
	transfer_from_message(FILE_ID, MESSAGE_ADDR, LENGTH);
	if (File_Position > File_Size) {
		inodes[ID].size = File_Position;
	}
	inodes[ID].nb_of_changes = File_Nb_Of_Changes + 1;
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

