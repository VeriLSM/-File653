#include "arinc_fs.h"
#include "libc.h"
#include "types.h"
#include "fs.h"


extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];
extern bool inode_bitmap[INODE_NUM];
extern bool block_bitmap[BLOCK_NUM];
extern char Directory_Name_Set[INODE_NUM][MAX_FILE_NAME_LENGTH];
extern SuperBlock *super_block;
extern int8_t blocks[2621440];
extern Inode inodes[512];
extern int32_t ROOT_DIRECTORY_ID;
extern int32_t CURRENT_DIRECTORY_ID;

static APEX_INTEGER Invalid_File_Id_In_Current_Partition(FILE_ID_TYPE FILE_ID) {
	APEX_INTEGER index;
	if (*FILE_ID <= 0 || *FILE_ID > SYSTEM_LIMIT_FILE_SIZE) {
		index = 0;
	} else {
		index = inode_bitmap[FILE_ID];
	}
	return index;
}


