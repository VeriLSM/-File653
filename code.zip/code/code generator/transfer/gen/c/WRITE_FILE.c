#include "arinc_fs.h"
#include "libc.h"
#include "types.h"
#include "fs.h"


extern APEX_INTEGER CurrentProcess;
extern APEX_INTEGER ERROR_HANDLER_PROCESS_ID;
extern APEX_INTEGER LOCK_LEVEL;
extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];
extern bool inode_bitmap[INODE_NUM];
extern bool block_bitmap[BLOCK_NUM];
extern char Directory_Name_Set[INODE_NUM][MAX_FILE_NAME_LENGTH];
extern SuperBlock *super_block;
extern int8_t blocks[2621440];
extern Inode inodes[512];
extern int32_t ROOT_DIRECTORY_ID;
extern int32_t CURRENT_DIRECTORY_ID;


void WRITE_FILE(FILE_ID_TYPE FILE_ID, MESSAGE_ADDR_TYPE MESSAGE_ADDR, MESSAGE_SIZE_TYPE LENGTH, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER File_Id_In_Current_Partition_Flag;
	File_Id_In_Current_Partition_Flag = Invalid_File_Id_In_Current_Partition(FILE_ID);
	if (File_Id_In_Current_Partition_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EBADF;
		return;
	}
	APEX_INTEGER File_Id_has_Operation_Flag;
	File_Id_has_Operation_Flag = Invalid_File_Id_has_Operation(FILE_ID);
	if (File_Id_has_Operation_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EBUSY;
		return;
	}
	APEX_INTEGER File_Id_has_Read_Write_Access_Mode_Flag;
	File_Id_has_Read_Write_Access_Mode_Flag = Invalid_File_Id_has_Read_Write_Access_Mode(FILE_ID);
	if (File_Id_has_Read_Write_Access_Mode_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EACCES;
		return;
	}
	if (LENGTH <= 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		return;
	}
	APEX_INTEGER Volume_Space_Flag;
	Volume_Space_Flag = Invalid_Volume_Space_Available_Length(LENGTH);
	if (Volume_Space_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENOSPC;
		return;
	}
	APEX_INTEGER Length_Greater_than_Miximun_Flag;
	Length_Greater_than_Miximun_Flag = Invalid_Length_Greater_than_Miximun(LENGTH);
	if (Length_Greater_than_Miximun_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EFBIG;
		return;
	}
	APEX_INTEGER Storage_Device_Contain_File_ID_Flag;
	Storage_Device_Contain_File_ID_Flag = Invalid_Storage_Device_Contain_File_Id(FILE_ID);
	if (Storage_Device_Contain_File_ID_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	if (File_Id_In_Current_Partition_Flag != 0 && File_Id_has_Operation_Flag != 0 && File_Id_has_Read_Write_Access_Mode_Flag != 0 && LENGTH > 0 && Volume_Space_Flag != 0 && Length_Greater_than_Miximun_Flag != 0 && Storage_Device_Contain_File_ID_Flag != 0 && LOCK_LEVEL == 0 && CurrentProcess != ERROR_HANDLER_PROCESS_ID) {
		APEX_INTEGER File_Position,File_Size,File_Nb_Of_Changes,ID;
		ID = *FILE_ID;
		File_Position = inodes[ID].position + LENGTH;
		File_Size = inodes[ID].size;
		File_Nb_Of_Changes = inodes[ID].nb_of_changes;
		transfer_from_message(FILE_ID, MESSAGE_ADDR);
		if (File_Position > File_Size) {
			inodes[ID].size = File_Position;
		}
		inodes[ID].nb_of_changes = File_Nb_Of_Changes + 1;
		*RETURN_CODE = NO_ERROR;
		return;
	}
}

