#include "arinc_fs.h"
#include "libc.h"
#include "types.h"
#include "fs.h"


extern APEX_INTEGER CurrentProcess;
extern APEX_INTEGER ERROR_HANDLER_PROCESS_ID;
extern APEX_INTEGER LOCK_LEVEL;
extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];
extern bool inode_bitmap[INODE_NUM];
extern bool block_bitmap[BLOCK_NUM];
extern char Directory_Name_Set[INODE_NUM][MAX_FILE_NAME_LENGTH];
extern SuperBlock *super_block;
extern int8_t blocks[2621440];
extern Inode inodes[512];
extern int32_t ROOT_DIRECTORY_ID;
extern int32_t CURRENT_DIRECTORY_ID;


void READ_FILE(FILE_ID_TYPE FILE_ID, MESSAGE_ADDR_TYPE MESSAGE_ADDR, MESSAGE_SIZE_TYPE IN_LENGTH, MESSAGE_SIZE_TYPE *OUT_LENGTH, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER File_Id_In_Current_Partition_Flag;
	File_Id_In_Current_Partition_Flag = Invalid_File_Id_In_Current_Partition(FILE_ID);
	if (File_Id_In_Current_Partition_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EBADF;
		*OUT_LENGTH = -1;
		return;
	}
	APEX_INTEGER File_Id_has_Operation_Flag;
	File_Id_has_Operation_Flag = Invalid_File_Id_has_Operation(FILE_ID);
	if (File_Id_has_Operation_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EBUSY;
		*OUT_LENGTH = -1;
		return;
	}
	APEX_INTEGER File_Id_Due_to_Owner_Action_Flag;
	File_Id_Due_to_Owner_Action_Flag = Invalid_File_Id_Due_to_Owner_Action(FILE_ID);
	if (File_Id_Due_to_Owner_Action_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = ESTALE;
		*OUT_LENGTH = -1;
		return;
	}
	if (IN_LENGTH <= 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		*OUT_LENGTH = -1;
		return;
	}
	if (IN_LENGTH > MAX_ATOMIC_SIZE) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EFBIG;
		*OUT_LENGTH = -1;
		return;
	}
	APEX_INTEGER Storage_Device_Contain_File_Id_Flag;
	Storage_Device_Contain_File_Id_Flag = Invalid_Storage_Device_Contain_File_Id(FILE_ID);
	if (Storage_Device_Contain_File_Id_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		*OUT_LENGTH = -1;
		return;
	}
	APEX_INTEGER File_Postion_Greater_than_File_Size_Flag;
	File_Postion_Greater_than_File_Size_Flag = Invalid_File_Postion_Greater_than_File_Size(FILE_ID);
	if (File_Postion_Greater_than_File_Size_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EIO;
		*OUT_LENGTH = -1;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		*OUT_LENGTH = -1;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		*OUT_LENGTH = -1;
		return;
	}
	APEX_INTEGER ID,File_Position,File_Size;
	ID = FILE_ID;
	File_Position = inodes[ID].position;
	File_Size = inodes[ID].size;
	APEX_INTEGER Position_Add_Length;
	Position_Add_Length = File_Position + IN_LENGTH;
	if (Position_Add_Length > File_Size) {
		*OUT_LENGTH = File_Size - File_Position;
	} else {
		*OUT_LENGTH = IN_LENGTH;
	}
	transfer_to_message(FILE_ID, *OUT_LENGTH,MESSAGE_ADDR);
	inodes[ID].position = File_Position + *OUT_LENGTH;
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

