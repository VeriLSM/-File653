#include "arinc_fs.h"
#include "libc.h"
#include "types.h"
#include "fs.h"


extern APEX_INTEGER CurrentProcess;
extern APEX_INTEGER ERROR_HANDLER_PROCESS_ID;
extern APEX_INTEGER LOCK_LEVEL;


void SYNC_FILE(FILE_ID_TYPE FILE_ID, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER File_Id_In_Current_Partition_Flag;
	File_Id_In_Current_Partition_Flag = Invalid_File_Id_In_Current_Partition(FILE_ID);
	if (File_Id_In_Current_Partition_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EBADF;
		return;
	}
	APEX_INTEGER File_Id_has_Operation_Flag;
	File_Id_has_Operation_Flag = Invalid_File_Id_has_Operation(FILE_ID);
	if (File_Id_has_Operation_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EBUSY;
		return;
	}
	APEX_INTEGER File_Id_has_Read_Write_Access_Mode_Flag;
	File_Id_has_Read_Write_Access_Mode_Flag = Invalid_File_Id_has_Read_Write_Access_Mode(FILE_ID);
	if (File_Id_has_Read_Write_Access_Mode_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER Storage_Device_Contain_File_Id_Flag;
	Storage_Device_Contain_File_Id_Flag = Invalid_Storage_Device_Contain_File_Id(FILE_ID);
	if (Storage_Device_Contain_File_Id_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

