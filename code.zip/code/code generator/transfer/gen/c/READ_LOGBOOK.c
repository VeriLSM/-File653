#include "arinc_fs.h"
#include "libc.h"
#include "types.h"
#include "fs.h"




void READ_LOGBOOK(LOGBOOK_ID_TYPE LOGBOOK_ID, MESSAGE_RANGE_TYPE LOGBOOK_ENTRY, MESSAGE_ADDR_TYPE MESSAGE_ADDR, MESSAGE_SIZE_TYPE *LENGTH, WRITE_STATUS_TYPE *WRITE_STATUS, RETURN_CODE_TYPE *RETURN_CODE) {
	if (LOGBOOK_ID != CURRENT_LOGBOOK_ID) {
		*LENGTH = 0;
		*WRITE_STATUS = NOUSE;
		*RETURN_CODE = INVALID_PARAM;
		return;
	}
	if (LOGBOOK_ENTRY > CURRENT_IN_PROGRESS_MESSAGE_NUMBER) {
		*LENGTH = 0;
		*WRITE_STATUS = NOUSE;
		*RETURN_CODE = INVALID_PARAM;
		return;
	}
	
	
	index1 = ismember4(MESSAGE_ADDR, In_Progress_Log_Set,MAX_NB_IN_PROGRESS_MESSAGES_LIMITED);
	index2 = ismember4(MESSAGE_ADDR, Logbook_Set,MAX_NB_LOGGED_MESSAGES_LIMITED);
	if (index1 != 0) {
		*LENGTH = strlength(In_Progress_Log_Set[index1]);
		*WRITE_STATUS = IN_PROGRESS;
		*RETURN_CODE = NO_ERROR;
		return;
	}
	if (index2 != 0) {
		*LENGTH = strlength(Logbook_Set[index2]);
		*WRITE_STATUS = COMPLETE;
		*RETURN_CODE = NO_ERROR;
		return;
	}
	*LENGTH = 0;
	*WRITE_STATUS = ABORTED;
	*RETURN_CODE = NO_ERROR;
	return;
}

