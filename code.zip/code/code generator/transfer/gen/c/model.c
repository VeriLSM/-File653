
//直接对应生成的函数
static APEX_INTEGER Invalid_Existing_File(FILE_NAME_TYPE FILE_NAME) {
	APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];
	APEX_INTEGER DIR_ID,index,pos,ID;
//	path_prefix = get_file_prefix(FILE_NAME);
    get_file_prefix(FILE_NAME,path_prefix)

	DIR_ID = ismember4(path_prefix, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	if (DIR_ID == 0) {
		index = 0;
		return index;
	}
	DirItem dir_list[8];
	int block_num = inodes[CURRENT_DIRECTORY_ID].dirBlock[0]; //增加
    memcpy(blocks+BLOCK_SIZE*block_num,dir_list,sizeof(dir_list)); //增加
    char Sub_Directory_Set[DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS][MAX_FILE_NAME_LENGTH];
	for (int i = 0; i < DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS; i++) {
		strcpy(Sub_Directory_Set[i],dir_list[i].itemName);
		}
	pos = ismember4(FILE_NAME, Sub_Directory_Set,DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS);
	if (pos == 0) {
		index = 0;
		return index;
	}
	ID = ismember4(FILE_NAME, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	if (inodes[ID].entry != FILE_ENTRY) {
		index = 0;
	} else {
		index = 1;
	}
	return index;
}

static void write_directory(APEX_INTEGER DIR_ID,FILE_NAME_TYPE FILE_NAME,APEX_INTEGER Fileindex){
    DirItem dir_list[8];
    int block_num = inodes[CURRENT_DIRECTORY_ID].dirBlock[0]; //增加
    memcpy(dir_list,blocks+BLOCK_SIZE*block_num,sizeof(dir_list)); //增加
    int32_t cnt = inodes[DIR_ID].cnt;
    int flag = 0;
    for(int i = 0;i<=cnt;i++){
        if(dir_list[i].inode==Fileindex){
            flag = 1;
            strcpy(dir_list[i].itemName,FILE_NAME);
            break;
        }
    }
    if (flag==0){
        strcpy(dir_list[cnt].itemName,FILE_NAME);
        dir_list[cnt].inode = Fileindex;
    }
    memcpy(blocks+BLOCK_SIZE*block_num,dir_list,sizeof(dir_list));
    strcpy(Directory_Name_Set[Fileindex],FILE_NAME);
}

static APEX_INTEGER Invalid_Volume_Space_Available(FILE_NAME_TYPE FILE_NAME) {
    APEX_INTEGER free_bytes,index;
    free_bytes = super_block->free_block_num;
    if (free_bytes > 1) {
        index = 1;
    } else {
        index = 0;
    }
    return index;
}

static APEX_INTEGER Invalid_Volume_Space_Available_Length(MESSAGE_SIZE_TYPE LENGTH) {
    APEX_INTEGER free_bytes,index;
    free_bytes = super_block->free_block_num;
    if (free_bytes > 1) {
        index = 1;
    } else {
        index = 0;
    }
    return index;
}

static APEX_INTEGER Invalid_File_Syntax(FILE_NAME_TYPE FILE_NAME){
    APEX_INTEGER index;
    index = 1;
    return index;
}

static APEX_INTEGER Invalid_OLD_New_File_Name_Volume_Identical(FILE_NAME_TYPE OLD_FILE_NAME,FILE_NAME_TYPE NEW_FILE_NAME){
    APEX_INTEGER index;
    index = 1;
    return index;
}

static APEX_INTEGER Invalid_Directory_Syntax(FILE_NAME_TYPE DIRECTORY_NAME){
    APEX_INTEGER index;
    index = 1;
    return index;
}

static void transfer_from_message(FILE_ID_TYPE FILE_ID,MESSAGE_ADDR_TYPE MESSAGE_ADDR,MESSAGE_SIZE_TYPE LENGTH){
    int block_num = inodes[FILE_ID].dirBlock[0]; //增加
    memcpy(blocks+BLOCK_SIZE*block_num,MESSAGE_ADDR,LENGTH); //增加
}

static void transfer_to_message(FILE_ID_TYPE FILE_ID,MESSAGE_ADDR_TYPE MESSAGE_ADDR,MESSAGE_SIZE_TYPE LENGTH){
    int block_num = inodes[FILE_ID].dirBlock[0]; //增加
    memcpy(MESSAGE_ADDR,blocks+BLOCK_SIZE*block_num,LENGTH); //增加
}

static APEX_INTEGER search_directory(APEX_INTEGER DIR_ID,FILE_NAME_TYPE FILE_NAME){
    APEX_INTEGER FILE_ID = -1;
    DirItem dir_list[8];
    int block_num = inodes[DIR_ID].dirBlock[0];
    memcpy(dir_list,blocks+BLOCK_SIZE*block_num,sizeof(dir_list));
    int32_t cnt = inodes[DIR_ID].cnt;
    for (int i = 0;i<=cnt;i++){
        if (strcmp(FILE_NAME,dir_list[i].itemName)==0){
            FILE_ID = dir_list[i].inode;
        }
    }
    return FILE_ID;
}

static void delete_file(APEX_INTEGER FILE_ID,APEX_INTEGER DIR_ID){
    DirItem dir_list[8];
    int block_num = inodes[DIR_ID].dirBlock[0];
    memcpy(dir_list,blocks+BLOCK_SIZE*block_num,sizeof(dir_list));
    strcpy(dir_list[FILE_ID].itemName,"");
    dir_list[FILE_ID].inode = -1;
    memcpy(blocks+BLOCK_SIZE*block_num,dir_list,sizeof(dir_list));
    inodes[DIR_ID].cnt = inodes[DIR_ID].cnt - 1;
    inodes[FILE_ID].id = -1;
    inodes[FILE_ID].cnt = 0;
    inodes[FILE_ID].size = 0;
    inodes[FILE_ID].position = 0;
    inodes[FILE_ID].nb_of_changes = 0;
    inodes[FILE_ID].nb_of_write_errors = 0;
    inodes[FILE_ID].is_open = false;
    inodes[FILE_ID].mode = READ_WRITE;
    inodes[FILE_ID].entry = FILE_ENTRY;
    inodes[FILE_ID].dirBlock[0] = -1;
    super_block->free_block_num++;
    super_block->free_inode_num++;
    inode_bitmap[FILE_ID] = false;
}

static APEX_INTEGER Invalid_Directory_Name_is_Root_Directory(FILE_NAME_TYPE DIRECTORY_NAME){ //新增加
    APEX_INTEGER index;
    if (strcmp(DIRECTORY_NAME,"C:/") == 0){
        index = 0;
    }
    else{
        index = 1;
    }
    return index;
}

static void delete_directory(APEX_INTEGER DIRECTORY_ID,APEX_INTEGER DIR_ID){
    DirItem dir_list[8];
    int block_num = inodes[DIR_ID].dirBlock[0];
    memcpy(dir_list,blocks+BLOCK_SIZE*block_num,sizeof(dir_list));
    strcpy(dir_list[DIRECTORY_ID].itemName,"");
    dir_list[DIRECTORY_ID].inode = -1;
    memcpy(blocks+BLOCK_SIZE*block_num,dir_list,sizeof(dir_list));
    inodes[DIR_ID].cnt = inodes[DIR_ID].cnt - 1;
    inodes[DIRECTORY_ID].id = -1;
    inodes[DIRECTORY_ID].cnt = 0;
    inodes[DIRECTORY_ID].size = 0;
    inodes[DIRECTORY_ID].position = 0;
    inodes[DIRECTORY_ID].nb_of_changes = 0;
    inodes[DIRECTORY_ID].nb_of_write_errors = 0;
    inodes[DIRECTORY_ID].is_open = false;
    inodes[DIRECTORY_ID].mode = READ_WRITE;
    inodes[DIRECTORY_ID].entry = DIRECTORY_ENTRY;
    inodes[DIRECTORY_ID].dirBlock[0] = -1;
    super_block->free_block_num++;
    super_block->free_inode_num++;
    inode_bitmap[DIRECTORY_ID] = false;
}


static FILE_NAME_TYPE get_volume_name(FILE_NAME_TYPE FILE_NAME){
    FILE_NAME_TYPE volume_name = "C:/";
    return volume_name;
}
