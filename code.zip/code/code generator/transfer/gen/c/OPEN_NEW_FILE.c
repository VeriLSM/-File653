#include "arinc_fs.h"
#include "libc.h"
#include "types.h"
#include "fs.h"
#include "ls.h"
#include "arinc_ls.h"


extern APEX_INTEGER LOCK_LEVEL;
extern APEX_INTEGER CurrentProcess;
extern APEX_INTEGER ERROR_HANDLER_PROCESS_ID;
extern APEX_INTEGER PARTION_OPEN_FILES_NUMBERS;
extern APEX_INTEGER PARTION_EXIT_FILES_NUMBERS;
extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];
extern bool inode_bitmap[INODE_NUM];
extern bool block_bitmap[BLOCK_NUM];
extern char Directory_Name_Set[INODE_NUM][MAX_FILE_NAME_LENGTH];
extern SuperBlock *super_block;
extern int8_t blocks[2621440];
extern Inode inodes[512];
extern int32_t ROOT_DIRECTORY_ID;
extern int32_t CURRENT_DIRECTORY_ID;


void OPEN_NEW_FILE(FILE_NAME_TYPE FILE_NAME, FILE_ID_TYPE *FILE_ID, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER Fileindex;
	Fileindex = CapacityofFile();
	if (Fileindex == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_CONFIG;
		*ERRNO = EMFILE;
		return;
	}
	APEX_INTEGER File_Length_Flag;
	File_Length_Flag = Invalid_File_Length(FILE_NAME);
	if (File_Length_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENAMETOOLONG;
		return;
	}
	APEX_INTEGER File_Syntax_Flag;
	File_Syntax_Flag = Invalid_File_Syntax(FILE_NAME);
	if (File_Syntax_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		return;
	}
	APEX_INTEGER File_Path_Prefix_Flag;
	File_Path_Prefix_Flag = Invalid_File_Path_Prefix(FILE_NAME);
	if (File_Path_Prefix_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENOTDIR;
		return;
	}
	APEX_INTEGER Invalid_Partition_Mode_Flag;
	Invalid_Partition_Mode_Flag = Invalid_Partition_Read_Write_Access_Rights(FILE_NAME);
	if (Invalid_Partition_Mode_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_CONFIG;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER Invalid_Device_Write_Protected_Flag;
	Invalid_Device_Write_Protected_Flag = Invalid_Device_Is_Write_Protected();
	if (Invalid_Device_Write_Protected_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EROFS;
		return;
	}
	APEX_INTEGER Existing_File_Flag;
	Existing_File_Flag = Invalid_Existing_File(FILE_NAME);
	if (Existing_File_Flag > 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EEXIST;
		return;
	}
	APEX_INTEGER Existing_Directory_Flag;
	Existing_Directory_Flag = Invalid_Existing_Directory(FILE_NAME);
	if (Existing_Directory_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EISDIR;
		return;
	}
	APEX_INTEGER Volume_Space_Flag;
	Volume_Space_Flag = Invalid_Volume_Space_Available(FILE_NAME);
	if (Volume_Space_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_CONFIG;
		*ERRNO = ENOSPC;
		return;
	}
	APEX_INTEGER Storage_Device_Flag;
	Storage_Device_Flag = Invalid_Storage_Device_Contain_File_Name(FILE_NAME);
	if (Storage_Device_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];
	get_file_prefix(FILE_NAME,path_prefix);
	APEX_INTEGER DIR_ID;
	
	DIR_ID = ismember4(path_prefix, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	write_directory(DIR_ID, FILE_NAME, Fileindex);
	inodes[DIR_ID].cnt = inodes[DIR_ID].cnt + 1;
	APEX_INTEGER ID;
	ID = Fileindex;
	*FILE_ID = ID;
	inodes[ID].id = ID;
	inodes[ID].position = 0;
	inodes[ID].size = 0;
	inodes[ID].nb_of_changes = 0;
	inodes[ID].nb_of_write_errors = 0;
	//inode.content = "";
	inodes[ID].is_open = 1;
	inodes[ID].mode = READ_WRITE;
	inodes[ID].entry = FILE_ENTRY;
	inodes[ID].cnt = 0;
	inodes[ID].dirBlock[0] = ID;
	PARTION_OPEN_FILES_NUMBERS = PARTION_OPEN_FILES_NUMBERS + 1;
	PARTION_EXIT_FILES_NUMBERS = PARTION_EXIT_FILES_NUMBERS + 1;
	inode_bitmap[ID] = 1;
	super_block->free_block_num = super_block->free_block_num - 1;
	super_block->free_inode_num = super_block->free_inode_num - 1;
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

