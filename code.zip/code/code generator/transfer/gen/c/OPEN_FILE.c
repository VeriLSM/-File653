#include "arinc_fs.h"
#include "libc.h"
#include "types.h"
#include "fs.h"
#include "ls.h"
#include "arinc_ls.h"


extern APEX_INTEGER LOCK_LEVEL;
extern APEX_INTEGER PARTION_OPEN_FILES_NUMBERS;
extern APEX_INTEGER CurrentProcess;
extern APEX_INTEGER ERROR_HANDLER_PROCESS_ID;
extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];
extern bool inode_bitmap[INODE_NUM];
extern bool block_bitmap[BLOCK_NUM];
extern char Directory_Name_Set[INODE_NUM][MAX_FILE_NAME_LENGTH];
extern SuperBlock *super_block;
extern int8_t blocks[2621440];
extern Inode inodes[512];
extern int32_t ROOT_DIRECTORY_ID;
extern int32_t CURRENT_DIRECTORY_ID;


void OPEN_FILE(FILE_NAME_TYPE FILE_NAME, FILE_MODE_TYPE FILE_MODE, FILE_ID_TYPE *FILE_ID, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER Fileindex;
	Fileindex = CapacityofOpenFile();
	if (Fileindex == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_CONFIG;
		*ERRNO = EMFILE;
		return;
	}
	APEX_INTEGER File_Length_Flag;
	File_Length_Flag = Invalid_File_Length(FILE_NAME);
	if (File_Length_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENAMETOOLONG;
		return;
	}
	APEX_INTEGER File_Syntax_Flag;
	File_Syntax_Flag = Invalid_File_Syntax(FILE_NAME);
	if (File_Syntax_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		return;
	}
	APEX_INTEGER File_Path_Prefix_Flag;
	File_Path_Prefix_Flag = Invalid_File_Path_Prefix(FILE_NAME);
	if (File_Path_Prefix_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENOTDIR;
		return;
	}
	APEX_INTEGER Partition_Mode_Flag;
	Partition_Mode_Flag = Invalid_FILE_MODE(FILE_MODE);
	if (Partition_Mode_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		return;
	}
	APEX_INTEGER Existing_Directory_Flag;
	Existing_Directory_Flag = Invalid_Existing_Directory(FILE_NAME);
	if (Existing_Directory_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EISDIR;
		return;
	}
	APEX_INTEGER Existing_File_Flag;
	Existing_File_Flag = Invalid_Existing_File(FILE_NAME);
	if (Existing_File_Flag > 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EEXIST;
		return;
	}
	APEX_INTEGER Existing_Filename_Is_Read_Write_Flag;
	Existing_Filename_Is_Read_Write_Flag = Invalid_Existing_Filename_Is_Read_Write(FILE_NAME);
	if (Existing_Filename_Is_Read_Write_Flag == 1 && FILE_MODE == READ_WRITE) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER Partition_Access_Rights_Flag;
	Partition_Access_Rights_Flag = Invalid_Partition_Access_Rights(FILE_MODE, FILE_NAME);
	if (Partition_Access_Rights_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_CONFIG;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER Device_Write_Protected_Flag;
	Device_Write_Protected_Flag = Invalid_Device_Is_Write_Protected();
	if (Device_Write_Protected_Flag == 0 && FILE_MODE == READ_WRITE) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EROFS;
		return;
	}
	APEX_INTEGER Storage_Device_Contain_File_ID_Flag;
	Storage_Device_Contain_File_ID_Flag = Invalid_Storage_Device_Contain_File_Name(FILE_NAME);
	if (Storage_Device_Contain_File_ID_Flag == 0) {
		*FILE_ID = -1;
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*FILE_ID = -1;
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER ID;
	
	ID = ismember4(FILE_NAME, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	APEX_INTEGER tag;
	tag = inode_bitmap[ID];
	if (tag == 0) {
		inodes[ID].nb_of_changes = 0;
		inodes[ID].nb_of_write_errors = 0;
	}
	inode_bitmap[ID] = 1;
	inodes[ID].position = 0;
	PARTION_OPEN_FILES_NUMBERS = PARTION_OPEN_FILES_NUMBERS + 1;
	*FILE_ID = ID;
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

