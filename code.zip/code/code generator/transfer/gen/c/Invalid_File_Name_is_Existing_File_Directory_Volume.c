#include "arinc_fs.h"
#include "libc.h"
#include "types.h"
#include "fs.h"


extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];
extern bool inode_bitmap[INODE_NUM];
extern bool block_bitmap[BLOCK_NUM];
extern char Directory_Name_Set[INODE_NUM][MAX_FILE_NAME_LENGTH];
extern SuperBlock *super_block;
extern int8_t blocks[2621440];
extern Inode inodes[512];
extern int32_t ROOT_DIRECTORY_ID;
extern int32_t CURRENT_DIRECTORY_ID;

static APEX_INTEGER Invalid_File_Name_is_Existing_File_Directory_Volume(FILE_NAME_TYPE FILE_NAME) {
	APEX_BYTE volume_name[MAX_FILE_NAME_LENGTH];
	APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];
	APEX_INTEGER VOL_ID,DIR_ID,index;
	get_volume_name(FILE_NAME,volume_name);
	get_file_prefix(FILE_NAME,path_prefix);
	
	VOL_ID = ismember4(volume_name, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	index = VOL_ID +1;
	if (index == 0) {
		return index;
	}
	DIR_ID = ismember4(path_prefix, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	index = DIR_ID +1;
	if (index == 0) {
		return index;
	}
	ID = ismember4(FILE_NAME, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	index = ID +1;
	return index;
}


