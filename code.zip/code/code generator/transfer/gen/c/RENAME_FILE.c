#include "arinc_fs.h"
#include "libc.h"
#include "types.h"
#include "fs.h"
#include "ls.h"
#include "arinc_ls.h"


extern APEX_INTEGER LOCK_LEVEL;
extern APEX_INTEGER CurrentProcess;
extern APEX_INTEGER ERROR_HANDLER_PROCESS_ID;
extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];
extern bool inode_bitmap[INODE_NUM];
extern bool block_bitmap[BLOCK_NUM];
extern char Directory_Name_Set[INODE_NUM][MAX_FILE_NAME_LENGTH];
extern SuperBlock *super_block;
extern int8_t blocks[2621440];
extern Inode inodes[512];
extern int32_t ROOT_DIRECTORY_ID;
extern int32_t CURRENT_DIRECTORY_ID;


void RENAME_FILE(FILE_NAME_TYPE OLD_FILE_NAME, FILE_NAME_TYPE NEW_FILE_NAME, RETURN_CODE_TYPE *RETURN_CODE, FILE_ERRNO_TYPE *ERRNO) {
	APEX_INTEGER Old_File_length_Flag;
	Old_File_length_Flag = Invalid_File_Length(OLD_FILE_NAME);
	if (Old_File_length_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENAMETOOLONG;
		return;
	}
	APEX_INTEGER Old_File_Syntax_Flag;
	Old_File_Syntax_Flag = Invalid_File_Syntax(OLD_FILE_NAME);
	if (Old_File_Syntax_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		return;
	}
	APEX_INTEGER Old_File_Path_Prefix_Flag;
	Old_File_Path_Prefix_Flag = Invalid_File_Path_Prefix(OLD_FILE_NAME);
	if (Old_File_Path_Prefix_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENOTDIR;
		return;
	}
	APEX_INTEGER New_File_length_Flag;
	New_File_length_Flag = Invalid_File_Length(NEW_FILE_NAME);
	if (New_File_length_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENAMETOOLONG;
		return;
	}
	APEX_INTEGER New_File_Syntax_Flag;
	New_File_Syntax_Flag = Invalid_File_Syntax(NEW_FILE_NAME);
	if (New_File_Syntax_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		return;
	}
	APEX_INTEGER New_File_Path_Prefix_Flag;
	New_File_Path_Prefix_Flag = Invalid_File_Path_Prefix(NEW_FILE_NAME);
	if (New_File_Path_Prefix_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENOTDIR;
		return;
	}
	APEX_INTEGER Partition_Access_Rights_Flag;
	Partition_Access_Rights_Flag = Invalid_Partition_Read_Write_Access_Rights(OLD_FILE_NAME);
	if (Partition_Access_Rights_Flag == 0) {
		*RETURN_CODE = INVALID_CONFIG;
		*ERRNO = EACCES;
		return;
	}
	APEX_INTEGER File_Name_Operation_Flag;
	File_Name_Operation_Flag = Invalid_File_Name_has_Operation(OLD_FILE_NAME);
	if (File_Name_Operation_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EBUSY;
		return;
	}
	APEX_INTEGER Device_Protected_Flag;
	Device_Protected_Flag = Invalid_Device_Is_Write_Protected();
	if (Device_Protected_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EROFS;
		return;
	}
	APEX_INTEGER File_Name_Identical_Flag;
	File_Name_Identical_Flag = Invalid_OLD_New_File_Name_Volume_Identical(OLD_FILE_NAME, NEW_FILE_NAME);
	if (File_Name_Identical_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EINVAL;
		return;
	}
	APEX_INTEGER Create_File_in_New_Directory_Flag;
	Create_File_in_New_Directory_Flag = Invalid_Create_File_in_New_Directory(NEW_FILE_NAME);
	if (Create_File_in_New_Directory_Flag == 0) {
		*RETURN_CODE = INVALID_CONFIG;
		*ERRNO = ENOSPC;
		return;
	}
	APEX_INTEGER Old_Existing_Directory_Flag;
	Old_Existing_Directory_Flag = Invalid_Existing_Directory(OLD_FILE_NAME);
	if (Old_Existing_Directory_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EPERM;
		return;
	}
	APEX_INTEGER New_Existing_Directory_Flag;
	New_Existing_Directory_Flag = Invalid_Existing_Directory(NEW_FILE_NAME);
	if (New_Existing_Directory_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EISDIR;
		return;
	}
	APEX_INTEGER Old_Existing_File_Flag;
	Old_Existing_File_Flag = Invalid_Existing_File(OLD_FILE_NAME);
	if (Old_Existing_File_Flag == 0) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = ENOENT;
		return;
	}
	APEX_INTEGER New_Existing_File_Flag;
	New_Existing_File_Flag = Invalid_Existing_File(NEW_FILE_NAME);
	if (New_Existing_File_Flag == 1) {
		*RETURN_CODE = INVALID_PARAM;
		*ERRNO = EEXIST;
		return;
	}
	APEX_INTEGER Old_File_Name_Open_Flag;
	Old_File_Name_Open_Flag = Invalid_File_Name_is_Open(OLD_FILE_NAME);
	if (Old_File_Name_Open_Flag > 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EBUSY;
		return;
	}
	APEX_INTEGER Old_Storage_Device_Contain_File_Name_Flag;
	Old_Storage_Device_Contain_File_Name_Flag = Invalid_Storage_Device_Contain_File_Name(OLD_FILE_NAME);
	if (Old_Storage_Device_Contain_File_Name_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		return;
	}
	APEX_INTEGER New_Storage_Device_Contain_File_Name_Flag;
	New_Storage_Device_Contain_File_Name_Flag = Invalid_Storage_Device_Contain_File_Name(NEW_FILE_NAME);
	if (New_Storage_Device_Contain_File_Name_Flag == 0) {
		*RETURN_CODE = NOT_AVAILABLE;
		*ERRNO = EIO;
		return;
	}
	if (LOCK_LEVEL > 0) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	if (CurrentProcess == ERROR_HANDLER_PROCESS_ID) {
		*RETURN_CODE = INVALID_MODE;
		*ERRNO = EACCES;
		return;
	}
	APEX_BYTE old_path_prefix[MAX_FILE_NAME_LENGTH];
	get_file_prefix(OLD_FILE_NAME,old_path_prefix);
	APEX_BYTE new_path_prefix[MAX_FILE_NAME_LENGTH];
	get_file_prefix(NEW_FILE_NAME,new_path_prefix);
	APEX_INTEGER OLD_DIR_ID,NEW_DIR_ID,FILE_ID;
	
	OLD_DIR_ID = ismember4(old_path_prefix, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	NEW_DIR_ID = ismember4(new_path_prefix, Directory_Name_Set,MAX_DIRECTORY_NUMBER);
	FILE_ID = search_directory(OLD_DIR_ID, OLD_FILE_NAME);
	write_directory(NEW_DIR_ID, NEW_FILE_NAME, FILE_ID);
	*RETURN_CODE = NO_ERROR;
	*ERRNO = EUNCHANGE;
	return;
}

