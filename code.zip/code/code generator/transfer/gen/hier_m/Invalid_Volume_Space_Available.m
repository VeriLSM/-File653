function [index] = Invalid_Volume_Space_Available(FILE_NAME)		%% 1 M*-FUCD

	global File_System_Configuation_Table;		%%  M*-GLBD
	global MAX_ATOMIC_SIZE;		%%  M*-GLBD

	% APEX_INTEGER free_bytes,index;		%% 1.0 M*-TYDE
	free_bytes = File_System_Configuation_Table{1,3};		%% 1.1 M*-ASS
	if free_bytes > MAX_ATOMIC_SIZE		%% 1.2 M*-IFS
		index = 1;		%% 1.2.0 M*-ASS
	else		%% 1.3 M*-ELS
		index = 0;		%% 1.3.0 M*-ASS
	end
	return;		%% 1.4 M*-RET

end


