function [RETURN_CODE,ERRNO] = RENAME_FILE(OLD_FILE_NAME,NEW_FILE_NAME,ERRNO)		%% 1 M*-FUCD

	global RETURN_CODE_TYPE;		%%  M*-GLBD
	global ERRNO_ERROR_TYPE;		%%  M*-GLBD
	global CURRENT_PARTITION;		%%  M*-GLBD
	global CurrentProcess;		%%  M*-GLBD
	global ERROR_HANDLER_PROCESS_ID;		%%  M*-GLBD
	global File_Set;		%%  M*-GLBD
	global Directory_Set;		%%  M*-GLBD

	% APEX_INTEGER Old_File_length_Flag;		%% 1.0 M*-TYDE
	Old_File_length_Flag = Invalid_File_Length(OLD_FILE_NAME);		%% 1.1 M*-ASS
	return;		%% 1.2.2 M*-RET
	if Old_File_length_Flag == 0		%% 1.2 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.2.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.ENAMETOOLONG;		%% 1.2.1 M*-ASS
		return;		%% 1.2.2 M*-RET
	end
	% APEX_INTEGER Old_File_Syntax_Flag;		%% 1.3 M*-TYDE
	Old_File_Syntax_Flag = Invalid_File_Syntax(OLD_FILE_NAME);		%% 1.4 M*-ASS
	return;		%% 1.5.2 M*-RET
	if Old_File_Syntax_Flag == 0		%% 1.5 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.5.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EINVAL;		%% 1.5.1 M*-ASS
		return;		%% 1.5.2 M*-RET
	end
	% APEX_INTEGER Old_File_Path_Prefix_Flag;		%% 1.6 M*-TYDE
	Old_File_Path_Prefix_Flag = Invalid_File_Path_Prefix(OLD_FILE_NAME);		%% 1.7 M*-ASS
	return;		%% 1.8.2 M*-RET
	if Old_File_Path_Prefix_Flag == 0		%% 1.8 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.8.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.ENOTDIR;		%% 1.8.1 M*-ASS
		return;		%% 1.8.2 M*-RET
	end
	% APEX_INTEGER New_File_length_Flag;		%% 1.9 M*-TYDE
	New_File_length_Flag = Invalid_File_Length(NEW_FILE_NAME);		%% 1.10 M*-ASS
	return;		%% 1.11.2 M*-RET
	if New_File_length_Flag == 0		%% 1.11 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.11.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.ENAMETOOLONG;		%% 1.11.1 M*-ASS
		return;		%% 1.11.2 M*-RET
	end
	% APEX_INTEGER New_File_Syntax_Flag;		%% 1.12 M*-TYDE
	New_File_Syntax_Flag = Invalid_File_Syntax(NEW_FILE_NAME);		%% 1.13 M*-ASS
	return;		%% 1.14.2 M*-RET
	if New_File_Syntax_Flag == 0		%% 1.14 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.14.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EINVAL;		%% 1.14.1 M*-ASS
		return;		%% 1.14.2 M*-RET
	end
	% APEX_INTEGER New_File_Path_Prefix_Flag;		%% 1.15 M*-TYDE
	New_File_Path_Prefix_Flag = Invalid_File_Path_Prefix(NEW_FILE_NAME);		%% 1.16 M*-ASS
	return;		%% 1.17.2 M*-RET
	if New_File_Path_Prefix_Flag == 0		%% 1.17 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.17.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.ENOTDIR;		%% 1.17.1 M*-ASS
		return;		%% 1.17.2 M*-RET
	end
	% APEX_INTEGER Partition_Access_Rights_Flag;		%% 1.18 M*-TYDE
	Partition_Access_Rights_Flag = Invalid_Partition_Read_Write_Access_Rights(OLD_FILE_NAME);		%% 1.19 M*-ASS
	return;		%% 1.20.2 M*-RET
	if Partition_Access_Rights_Flag == 0		%% 1.20 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;		%% 1.20.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EACCES;		%% 1.20.1 M*-ASS
		return;		%% 1.20.2 M*-RET
	end
	% APEX_INTEGER File_Name_Operation_Flag;		%% 1.21 M*-TYDE
	File_Name_Operation_Flag = Invalid_File_Name_has_Operation(OLD_FILE_NAME);		%% 1.22 M*-ASS
	return;		%% 1.23.2 M*-RET
	if File_Name_Operation_Flag == 0		%% 1.23 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;		%% 1.23.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EBUSY;		%% 1.23.1 M*-ASS
		return;		%% 1.23.2 M*-RET
	end
	% APEX_INTEGER Device_Protected_Flag;		%% 1.24 M*-TYDE
	Device_Protected_Flag = Invalid_Device_Is_Write_Protected;		%% 1.25 M*-ASS
	return;		%% 1.26.2 M*-RET
	if Device_Protected_Flag == 0		%% 1.26 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.26.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EROFS;		%% 1.26.1 M*-ASS
		return;		%% 1.26.2 M*-RET
	end
	% APEX_INTEGER File_Name_Identical_Flag;		%% 1.27 M*-TYDE
	File_Name_Identical_Flag = Invalid_OLD_New_File_Name_Volume_Identical(OLD_FILE_NAME,NEW_FILE_NAME);		%% 1.28 M*-ASS
	return;		%% 1.29.2 M*-RET
	if File_Name_Identical_Flag == 0		%% 1.29 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.29.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EINVAL;		%% 1.29.1 M*-ASS
		return;		%% 1.29.2 M*-RET
	end
	% APEX_INTEGER Create_File_in_New_Directory_Flag;		%% 1.30 M*-TYDE
	Create_File_in_New_Directory_Flag = Invalid_Create_File_in_New_Directory(NEW_FILE_NAME);		%% 1.31 M*-ASS
	return;		%% 1.32.2 M*-RET
	if Create_File_in_New_Directory_Flag == 0		%% 1.32 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;		%% 1.32.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.ENOSPC;		%% 1.32.1 M*-ASS
		return;		%% 1.32.2 M*-RET
	end
	% APEX_INTEGER Old_Existing_Directory_Flag;		%% 1.33 M*-TYDE
	Old_Existing_Directory_Flag = Invalid_Existing_Directory(OLD_FILE_NAME);		%% 1.34 M*-ASS
	return;		%% 1.35.2 M*-RET
	if Old_Existing_Directory_Flag == 0		%% 1.35 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.35.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EPERM;		%% 1.35.1 M*-ASS
		return;		%% 1.35.2 M*-RET
	end
	% APEX_INTEGER New_Existing_Directory_Flag;		%% 1.36 M*-TYDE
	New_Existing_Directory_Flag = Invalid_Existing_Directory(NEW_FILE_NAME);		%% 1.37 M*-ASS
	return;		%% 1.38.2 M*-RET
	if New_Existing_Directory_Flag == 0		%% 1.38 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.38.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EISDIR;		%% 1.38.1 M*-ASS
		return;		%% 1.38.2 M*-RET
	end
	% APEX_INTEGER Old_Existing_File_Flag;		%% 1.39 M*-TYDE
	Old_Existing_File_Flag = Invalid_Existing_File(OLD_FILE_NAME);		%% 1.40 M*-ASS
	return;		%% 1.41.2 M*-RET
	if Old_Existing_File_Flag == 0		%% 1.41 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.41.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.ENOENT;		%% 1.41.1 M*-ASS
		return;		%% 1.41.2 M*-RET
	end
	% APEX_INTEGER New_Existing_File_Flag;		%% 1.42 M*-TYDE
	New_Existing_File_Flag = Invalid_Existing_File(NEW_FILE_NAME);		%% 1.43 M*-ASS
	return;		%% 1.44.2 M*-RET
	if New_Existing_File_Flag == 1		%% 1.44 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.44.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EEXIST;		%% 1.44.1 M*-ASS
		return;		%% 1.44.2 M*-RET
	end
	% APEX_INTEGER Old_File_Name_Open_Flag;		%% 1.45 M*-TYDE
	Old_File_Name_Open_Flag = Invalid_File_Name_is_Open(OLD_FILE_NAME);		%% 1.46 M*-ASS
	return;		%% 1.47.2 M*-RET
	if Old_File_Name_Open_Flag > 0		%% 1.47 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;		%% 1.47.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EBUSY;		%% 1.47.1 M*-ASS
		return;		%% 1.47.2 M*-RET
	end
	% APEX_INTEGER Old_Storage_Device_Contain_File_Name_Flag;		%% 1.48 M*-TYDE
	Old_Storage_Device_Contain_File_Name_Flag = Invalid_Storage_Device_Contain_File_Name(OLD_FILE_NAME);		%% 1.49 M*-ASS
	return;		%% 1.50.2 M*-RET
	if Old_Storage_Device_Contain_File_Name_Flag == 0		%% 1.50 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;		%% 1.50.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EIO;		%% 1.50.1 M*-ASS
		return;		%% 1.50.2 M*-RET
	end
	% APEX_INTEGER New_Storage_Device_Contain_File_Name_Flag;		%% 1.51 M*-TYDE
	New_Storage_Device_Contain_File_Name_Flag = Invalid_Storage_Device_Contain_File_Name(NEW_FILE_NAME);		%% 1.52 M*-ASS
	return;		%% 1.53.2 M*-RET
	if New_Storage_Device_Contain_File_Name_Flag == 0		%% 1.53 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;		%% 1.53.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EIO;		%% 1.53.1 M*-ASS
		return;		%% 1.53.2 M*-RET
	end
	return;		%% 1.54.2 M*-RET
	if CURRENT_PARTITION.LOCK_LEVEL > 0		%% 1.54 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;		%% 1.54.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EACCES;		%% 1.54.1 M*-ASS
		return;		%% 1.54.2 M*-RET
	end
	return;		%% 1.55.2 M*-RET
	if CurrentProcess == ERROR_HANDLER_PROCESS_ID		%% 1.55 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;		%% 1.55.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EACCES;		%% 1.55.1 M*-ASS
		return;		%% 1.55.2 M*-RET
	end
	% APEX_BYTE old_path_prefix[MAX_FILE_NAME_LENGTH];		%% 1.56 M*-TYDE
	old_path_prefix = get_file_prefix(OLD_FILE_NAME);		%% 1.57 M*-ASS
	% APEX_BYTE new_path_prefix[MAX_FILE_NAME_LENGTH];		%% 1.58 M*-TYDE
	new_path_prefix = get_file_prefix(NEW_FILE_NAME);		%% 1.59 M*-ASS
	% APEX_INTEGER OLD_DIR_ID,NEW_DIR_ID,FILE_ID;		%% 1.60 M*-TYDE
	Directory_Name_Set=[Directory_Set{:,1}];		%% 1.61 M*-ETKS
	[~,OLD_DIR_ID] = ismember(old_path_prefix, Directory_Name_Set);		%% 1.62 M*-EISM
	[~,NEW_DIR_ID] = ismember(new_path_prefix, Directory_Name_Set);		%% 1.63 M*-EISM
	FILE_ID = search_directory(OLD_DIR_ID,OLD_FILE_NAME);		%% 1.64 M*-ASS
	File_Set{FILE_ID,1} = NEW_FILE_NAME;		%% 1.66 M*-ASS
	RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;		%% 1.67 M*-ASS
	ERRNO = ERRNO_ERROR_TYPE.EUNCHANGE;		%% 1.68 M*-ASS
	return;		%% 1.69 M*-RET

end


