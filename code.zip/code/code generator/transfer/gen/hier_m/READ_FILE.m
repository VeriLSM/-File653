function [OUT_LENGTH,RETURN_CODE,ERRNO] = READ_FILE(FILE_ID,MESSAGE_ADDR,IN_LENGTH,ERRNO)		%% 1 M*-FUCD

	global RETURN_CODE_TYPE;		%%  M*-GLBD
	global ERRNO_ERROR_TYPE;		%%  M*-GLBD
	global MAX_ATOMIC_SIZE;		%%  M*-GLBD
	global CurrentProcess;		%%  M*-GLBD
	global ERROR_HANDLER_PROCESS_ID;		%%  M*-GLBD
	global File_Set;		%%  M*-GLBD
	global CURRENT_PARTITION;		%%  M*-GLBD

	% APEX_INTEGER File_Id_In_Current_Partition_Flag;		%% 1.0 M*-TYDE
	File_Id_In_Current_Partition_Flag = Invalid_File_Id_In_Current_Partition(FILE_ID);		%% 1.1 M*-ASS
	return;		%% 1.2.3 M*-RET
	if File_Id_In_Current_Partition_Flag == 0		%% 1.2 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.2.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EBADF;		%% 1.2.1 M*-ASS
		OUT_LENGTH = -1;		%% 1.2.2 M*-ASS
		return;		%% 1.2.3 M*-RET
	end
	% APEX_INTEGER File_Id_has_Operation_Flag;		%% 1.3 M*-TYDE
	File_Id_has_Operation_Flag = Invalid_File_Id_has_Operation(FILE_ID);		%% 1.4 M*-ASS
	return;		%% 1.5.3 M*-RET
	if File_Id_has_Operation_Flag == 0		%% 1.5 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;		%% 1.5.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EBUSY;		%% 1.5.1 M*-ASS
		OUT_LENGTH = -1;		%% 1.5.2 M*-ASS
		return;		%% 1.5.3 M*-RET
	end
	% APEX_INTEGER File_Id_Due_to_Owner_Action_Flag;		%% 1.6 M*-TYDE
	File_Id_Due_to_Owner_Action_Flag = Invalid_File_Id_Due_to_Owner_Action(FILE_ID);		%% 1.7 M*-ASS
	return;		%% 1.8.3 M*-RET
	if File_Id_Due_to_Owner_Action_Flag == 0		%% 1.8 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;		%% 1.8.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.ESTALE;		%% 1.8.1 M*-ASS
		OUT_LENGTH = -1;		%% 1.8.2 M*-ASS
		return;		%% 1.8.3 M*-RET
	end
	return;		%% 1.9.3 M*-RET
	if IN_LENGTH <= 0		%% 1.9 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.9.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EINVAL;		%% 1.9.1 M*-ASS
		OUT_LENGTH = -1;		%% 1.9.2 M*-ASS
		return;		%% 1.9.3 M*-RET
	end
	return;		%% 1.10.3 M*-RET
	if IN_LENGTH > MAX_ATOMIC_SIZE		%% 1.10 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.10.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EFBIG;		%% 1.10.1 M*-ASS
		OUT_LENGTH = -1;		%% 1.10.2 M*-ASS
		return;		%% 1.10.3 M*-RET
	end
	% APEX_INTEGER Storage_Device_Contain_File_Id_Flag;		%% 1.11 M*-TYDE
	Storage_Device_Contain_File_Id_Flag = Invalid_Storage_Device_Contain_File_Id(FILE_ID);		%% 1.12 M*-ASS
	return;		%% 1.13.3 M*-RET
	if Storage_Device_Contain_File_Id_Flag == 0		%% 1.13 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;		%% 1.13.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EIO;		%% 1.13.1 M*-ASS
		OUT_LENGTH = -1;		%% 1.13.2 M*-ASS
		return;		%% 1.13.3 M*-RET
	end
	% APEX_INTEGER File_Postion_Greater_than_File_Size_Flag;		%% 1.14 M*-TYDE
	File_Postion_Greater_than_File_Size_Flag = Invalid_File_Postion_Greater_than_File_Size(FILE_ID);		%% 1.15 M*-ASS
	return;		%% 1.16.3 M*-RET
	if File_Postion_Greater_than_File_Size_Flag == 0		%% 1.16 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.16.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EIO;		%% 1.16.1 M*-ASS
		OUT_LENGTH = -1;		%% 1.16.2 M*-ASS
		return;		%% 1.16.3 M*-RET
	end
	return;		%% 1.17.3 M*-RET
	if CURRENT_PARTITION.LOCK_LEVEL > 0		%% 1.17 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;		%% 1.17.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EACCES;		%% 1.17.1 M*-ASS
		OUT_LENGTH = -1;		%% 1.17.2 M*-ASS
		return;		%% 1.17.3 M*-RET
	end
	return;		%% 1.18.3 M*-RET
	if CurrentProcess == ERROR_HANDLER_PROCESS_ID		%% 1.18 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;		%% 1.18.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EACCES;		%% 1.18.1 M*-ASS
		OUT_LENGTH = -1;		%% 1.18.2 M*-ASS
		return;		%% 1.18.3 M*-RET
	end
	% APEX_INTEGER ID,File_Position,File_Size;		%% 1.19 M*-TYDE
	ID = FILE_ID;		%% 1.20 M*-ASS
	File_Position = File_Set{ID,3};		%% 1.21 M*-ASS
	File_Size = File_Set{ID,4};		%% 1.22 M*-ASS
	% APEX_INTEGER Position_Add_Length;		%% 1.23 M*-TYDE
	Position_Add_Length = File_Position + IN_LENGTH;		%% 1.24 M*-ASS
	if Position_Add_Length > File_Size		%% 1.25 M*-IFS
		OUT_LENGTH = File_Size - File_Position;		%% 1.25.0 M*-ASS
	else		%% 1.26 M*-ELS
		OUT_LENGTH = IN_LENGTH;		%% 1.26.0 M*-ASS
	end
	MESSAGE_ADDR = transfer_to_message(FILE_ID,OUT_LENGTH);		%% 1.27 M*-ASS
	File_Set{ID,3} = File_Position + OUT_LENGTH;		%% 1.28 M*-ASS
	RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;		%% 1.29 M*-ASS
	ERRNO = ERRNO_ERROR_TYPE.EUNCHANGE;		%% 1.30 M*-ASS
	return;		%% 1.31 M*-RET

end


