function [RETURN_CODE,ERRNO] = SYNC_FILE(FILE_ID,ERRNO)		%% 1 M*-FUCD

	global RETURN_CODE_TYPE;		%%  M*-GLBD
	global ERRNO_ERROR_TYPE;		%%  M*-GLBD
	global CurrentProcess;		%%  M*-GLBD
	global ERROR_HANDLER_PROCESS_ID;		%%  M*-GLBD
	global CURRENT_PARTITION;		%%  M*-GLBD

	% APEX_INTEGER File_Id_In_Current_Partition_Flag;		%% 1.0 M*-TYDE
	File_Id_In_Current_Partition_Flag = Invalid_File_Id_In_Current_Partition(FILE_ID);		%% 1.1 M*-ASS
	return;		%% 1.2.2 M*-RET
	if File_Id_In_Current_Partition_Flag == 0		%% 1.2 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.2.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EBADF;		%% 1.2.1 M*-ASS
		return;		%% 1.2.2 M*-RET
	end
	% APEX_INTEGER File_Id_has_Operation_Flag;		%% 1.3 M*-TYDE
	File_Id_has_Operation_Flag = Invalid_File_Id_has_Operation(FILE_ID);		%% 1.4 M*-ASS
	return;		%% 1.5.2 M*-RET
	if File_Id_has_Operation_Flag == 0		%% 1.5 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;		%% 1.5.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EBUSY;		%% 1.5.1 M*-ASS
		return;		%% 1.5.2 M*-RET
	end
	% APEX_INTEGER File_Id_has_Read_Write_Access_Mode_Flag;		%% 1.6 M*-TYDE
	File_Id_has_Read_Write_Access_Mode_Flag = Invalid_File_Id_has_Read_Write_Access_Mode(FILE_ID);		%% 1.7 M*-ASS
	return;		%% 1.8.2 M*-RET
	if File_Id_has_Read_Write_Access_Mode_Flag == 0		%% 1.8 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.8.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EACCES;		%% 1.8.1 M*-ASS
		return;		%% 1.8.2 M*-RET
	end
	% APEX_INTEGER Storage_Device_Contain_File_Id_Flag;		%% 1.9 M*-TYDE
	Storage_Device_Contain_File_Id_Flag = Invalid_Storage_Device_Contain_File_Id(FILE_ID);		%% 1.10 M*-ASS
	return;		%% 1.11.2 M*-RET
	if Storage_Device_Contain_File_Id_Flag == 0		%% 1.11 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;		%% 1.11.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EIO;		%% 1.11.1 M*-ASS
		return;		%% 1.11.2 M*-RET
	end
	return;		%% 1.12.2 M*-RET
	if CURRENT_PARTITION.LOCK_LEVEL > 0		%% 1.12 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;		%% 1.12.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EACCES;		%% 1.12.1 M*-ASS
		return;		%% 1.12.2 M*-RET
	end
	return;		%% 1.13.2 M*-RET
	if CurrentProcess == ERROR_HANDLER_PROCESS_ID		%% 1.13 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;		%% 1.13.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EACCES;		%% 1.13.1 M*-ASS
		return;		%% 1.13.2 M*-RET
	end
	RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;		%% 1.14 M*-ASS
	ERRNO = ERRNO_ERROR_TYPE.EUNCHANGE;		%% 1.15 M*-ASS
	return;		%% 1.16 M*-RET

end


