function [FILE_ID,RETURN_CODE,ERRNO] = OPEN_FILE(FILE_NAME,FILE_MODE,ERRNO)		%% 1 M*-FUCD

	global RETURN_CODE_TYPE;		%%  M*-GLBD
	global ERRNO_ERROR_TYPE;		%%  M*-GLBD
	global CURRENT_PARTITION;		%%  M*-GLBD
	global FILE_MODE_TYPE;		%%  M*-GLBD
	global File_Set;		%%  M*-GLBD
	global Open_File_Set;		%%  M*-GLBD
	global PARTION_OPEN_FILES_NUMBERS;		%%  M*-GLBD
	global CurrentProcess;		%%  M*-GLBD
	global ERROR_HANDLER_PROCESS_ID;		%%  M*-GLBD

	% APEX_INTEGER Fileindex;		%% 1.0 M*-TYDE
	Fileindex = CapacityofOpenFile;		%% 1.1 M*-ASS
	return;		%% 1.2.3 M*-RET
	if Fileindex == 0		%% 1.2 M*-IFS
		FILE_ID = -1;		%% 1.2.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;		%% 1.2.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EMFILE;		%% 1.2.2 M*-ASS
		return;		%% 1.2.3 M*-RET
	end
	% APEX_INTEGER File_Length_Flag;		%% 1.3 M*-TYDE
	File_Length_Flag = Invalid_File_Length(FILE_NAME);		%% 1.4 M*-ASS
	return;		%% 1.5.3 M*-RET
	if File_Length_Flag == 0		%% 1.5 M*-IFS
		FILE_ID = -1;		%% 1.5.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.5.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.ENAMETOOLONG;		%% 1.5.2 M*-ASS
		return;		%% 1.5.3 M*-RET
	end
	% APEX_INTEGER File_Syntax_Flag;		%% 1.6 M*-TYDE
	File_Syntax_Flag = Invalid_File_Syntax(FILE_NAME);		%% 1.7 M*-ASS
	return;		%% 1.8.3 M*-RET
	if File_Syntax_Flag == 0		%% 1.8 M*-IFS
		FILE_ID = -1;		%% 1.8.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.8.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EINVAL;		%% 1.8.2 M*-ASS
		return;		%% 1.8.3 M*-RET
	end
	% APEX_INTEGER File_Path_Prefix_Flag;		%% 1.9 M*-TYDE
	File_Path_Prefix_Flag = Invalid_File_Path_Prefix(FILE_NAME);		%% 1.10 M*-ASS
	return;		%% 1.11.3 M*-RET
	if File_Path_Prefix_Flag == 0		%% 1.11 M*-IFS
		FILE_ID = -1;		%% 1.11.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.11.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.ENOTDIR;		%% 1.11.2 M*-ASS
		return;		%% 1.11.3 M*-RET
	end
	% APEX_INTEGER Partition_Mode_Flag;		%% 1.12 M*-TYDE
	Partition_Mode_Flag = Invalid_FILE_MODE(FILE_MODE);		%% 1.13 M*-ASS
	return;		%% 1.14.3 M*-RET
	if Partition_Mode_Flag == 0		%% 1.14 M*-IFS
		FILE_ID = -1;		%% 1.14.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.14.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EINVAL;		%% 1.14.2 M*-ASS
		return;		%% 1.14.3 M*-RET
	end
	% APEX_INTEGER Existing_Directory_Flag;		%% 1.15 M*-TYDE
	Existing_Directory_Flag = Invalid_Existing_Directory(FILE_NAME);		%% 1.16 M*-ASS
	return;		%% 1.17.3 M*-RET
	if Existing_Directory_Flag == 0		%% 1.17 M*-IFS
		FILE_ID = -1;		%% 1.17.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.17.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EISDIR;		%% 1.17.2 M*-ASS
		return;		%% 1.17.3 M*-RET
	end
	% APEX_INTEGER Existing_File_Flag;		%% 1.18 M*-TYDE
	Existing_File_Flag = Invalid_Existing_File(FILE_NAME);		%% 1.19 M*-ASS
	return;		%% 1.20.3 M*-RET
	if Existing_File_Flag > 0		%% 1.20 M*-IFS
		FILE_ID = -1;		%% 1.20.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.20.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EEXIST;		%% 1.20.2 M*-ASS
		return;		%% 1.20.3 M*-RET
	end
	% APEX_INTEGER Existing_Filename_Is_Read_Write_Flag;		%% 1.21 M*-TYDE
	Existing_Filename_Is_Read_Write_Flag = Invalid_Existing_Filename_Is_Read_Write(FILE_NAME);		%% 1.22 M*-ASS
	return;		%% 1.23.3 M*-RET
	if Existing_Filename_Is_Read_Write_Flag == 1 && FILE_MODE == FILE_MODE_TYPE.READ_WRITE		%% 1.23 M*-IFS
		FILE_ID = -1;		%% 1.23.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.23.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EACCES;		%% 1.23.2 M*-ASS
		return;		%% 1.23.3 M*-RET
	end
	% APEX_INTEGER Partition_Access_Rights_Flag;		%% 1.24 M*-TYDE
	Partition_Access_Rights_Flag = Invalid_Partition_Access_Rights(FILE_MODE,FILE_NAME);		%% 1.25 M*-ASS
	return;		%% 1.26.3 M*-RET
	if Partition_Access_Rights_Flag == 0		%% 1.26 M*-IFS
		FILE_ID = -1;		%% 1.26.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;		%% 1.26.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EACCES;		%% 1.26.2 M*-ASS
		return;		%% 1.26.3 M*-RET
	end
	% APEX_INTEGER Device_Write_Protected_Flag;		%% 1.27 M*-TYDE
	Device_Write_Protected_Flag = Invalid_Device_Is_Write_Protected;		%% 1.28 M*-ASS
	return;		%% 1.29.3 M*-RET
	if Device_Write_Protected_Flag == 0 && FILE_MODE == FILE_MODE_TYPE.READ_WRITE		%% 1.29 M*-IFS
		FILE_ID = -1;		%% 1.29.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.29.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EROFS;		%% 1.29.2 M*-ASS
		return;		%% 1.29.3 M*-RET
	end
	% APEX_INTEGER Storage_Device_Contain_File_ID_Flag;		%% 1.30 M*-TYDE
	Storage_Device_Contain_File_ID_Flag = Invalid_Storage_Device_Contain_File_Name(FILE_NAME);		%% 1.31 M*-ASS
	return;		%% 1.32.3 M*-RET
	if Storage_Device_Contain_File_ID_Flag == 0		%% 1.32 M*-IFS
		FILE_ID = -1;		%% 1.32.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;		%% 1.32.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EIO;		%% 1.32.2 M*-ASS
		return;		%% 1.32.3 M*-RET
	end
	return;		%% 1.33.3 M*-RET
	if CURRENT_PARTITION.LOCK_LEVEL > 0		%% 1.33 M*-IFS
		FILE_ID = -1;		%% 1.33.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;		%% 1.33.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EACCES;		%% 1.33.2 M*-ASS
		return;		%% 1.33.3 M*-RET
	end
	return;		%% 1.34.3 M*-RET
	if CurrentProcess == ERROR_HANDLER_PROCESS_ID		%% 1.34 M*-IFS
		FILE_ID = -1;		%% 1.34.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;		%% 1.34.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EACCES;		%% 1.34.2 M*-ASS
		return;		%% 1.34.3 M*-RET
	end
	% APEX_INTEGER ID;		%% 1.35 M*-TYDE
	Directory_Name_Set=[File_Set{:,1}];		%% 1.36 M*-ETKS
	[~,ID] = ismember(FILE_NAME, Directory_Name_Set);		%% 1.37 M*-EISM
	% APEX_INTEGER tag;		%% 1.38 M*-TYDE
	tag = Open_File_Set(ID);		%% 1.39 M*-ASS
	if tag == 0		%% 1.40 M*-IFS
		File_Set{ID,5} = 0;		%% 1.40.0 M*-ASS
		File_Set{ID,6} = 0;		%% 1.40.1 M*-ASS
	end
	Open_File_Set(ID) = 1;		%% 1.41 M*-ASS
	File_Set{ID,3} = 0;		%% 1.42 M*-ASS
	PARTION_OPEN_FILES_NUMBERS = PARTION_OPEN_FILES_NUMBERS + 1;		%% 1.43 M*-ASS
	FILE_ID = ID;		%% 1.44 M*-ASS
	RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;		%% 1.45 M*-ASS
	ERRNO = ERRNO_ERROR_TYPE.EUNCHANGE;		%% 1.46 M*-ASS
	return;		%% 1.47 M*-RET

end


