function [index] = Invalid_File_Name_is_Open(FILE_NAME)		%% 1 M*-FUCD

	global File_Set;		%%  M*-GLBD
	global Open_File_Set;		%%  M*-GLBD

	% APEX_INTEGER ID,index,FILE_ID,FILE_ID;		%% 1.0 M*-TYDE
	Directory_Name_Set=[File_Set{:,1}];		%% 1.1 M*-ETKS
	[~,ID] = ismember(FILE_NAME, Directory_Name_Set);		%% 1.2 M*-EISM
	FILE_ID = File_Set{ID,2};		%% 1.3 M*-ASS
	index = Open_File_Set(FILE_ID);		%% 1.4 M*-ASS
	return;		%% 1.5 M*-RET

end


