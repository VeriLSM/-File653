function [RETURN_CODE,ERRNO] = WRITE_FILE(FILE_ID,MESSAGE_ADDR,LENGTH,ERRNO)		%% 1 M*-FUCD

	global RETURN_CODE_TYPE;		%%  M*-GLBD
	global ERRNO_ERROR_TYPE;		%%  M*-GLBD
	global CurrentProcess;		%%  M*-GLBD
	global ERROR_HANDLER_PROCESS_ID;		%%  M*-GLBD
	global File_Set;		%%  M*-GLBD
	global MAX_ATOMIC_SIZE;		%%  M*-GLBD
	global CURRENT_PARTITION;		%%  M*-GLBD

	% APEX_INTEGER File_Id_In_Current_Partition_Flag;		%% 1.0 M*-TYDE
	File_Id_In_Current_Partition_Flag = Invalid_File_Id_In_Current_Partition(FILE_ID);		%% 1.1 M*-ASS
	return;		%% 1.2.2 M*-RET
	if File_Id_In_Current_Partition_Flag == 0		%% 1.2 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.2.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EBADF;		%% 1.2.1 M*-ASS
		return;		%% 1.2.2 M*-RET
	end
	% APEX_INTEGER File_Id_has_Operation_Flag;		%% 1.3 M*-TYDE
	File_Id_has_Operation_Flag = Invalid_File_Id_has_Operation(FILE_ID);		%% 1.4 M*-ASS
	return;		%% 1.5.2 M*-RET
	if File_Id_has_Operation_Flag == 0		%% 1.5 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;		%% 1.5.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EBUSY;		%% 1.5.1 M*-ASS
		return;		%% 1.5.2 M*-RET
	end
	% APEX_INTEGER File_Id_has_Read_Write_Access_Mode_Flag;		%% 1.6 M*-TYDE
	File_Id_has_Read_Write_Access_Mode_Flag = Invalid_File_Id_has_Read_Write_Access_Mode(FILE_ID);		%% 1.7 M*-ASS
	return;		%% 1.8.2 M*-RET
	if File_Id_has_Read_Write_Access_Mode_Flag == 0		%% 1.8 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.8.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EACCES;		%% 1.8.1 M*-ASS
		return;		%% 1.8.2 M*-RET
	end
	return;		%% 1.9.2 M*-RET
	if LENGTH <= 0		%% 1.9 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.9.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EINVAL;		%% 1.9.1 M*-ASS
		return;		%% 1.9.2 M*-RET
	end
	% APEX_INTEGER Volume_Space_Flag;		%% 1.10 M*-TYDE
	Volume_Space_Flag = Invalid_Volume_Space_Available_Length(LENGTH);		%% 1.11 M*-ASS
	return;		%% 1.12.2 M*-RET
	if Volume_Space_Flag == 0		%% 1.12 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.12.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.ENOSPC;		%% 1.12.1 M*-ASS
		return;		%% 1.12.2 M*-RET
	end
	% APEX_INTEGER Length_Greater_than_Miximun_Flag;		%% 1.13 M*-TYDE
	Length_Greater_than_Miximun_Flag = Invalid_Length_Greater_than_Miximun(LENGTH);		%% 1.14 M*-ASS
	return;		%% 1.15.2 M*-RET
	if Length_Greater_than_Miximun_Flag == 0		%% 1.15 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.15.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EFBIG;		%% 1.15.1 M*-ASS
		return;		%% 1.15.2 M*-RET
	end
	% APEX_INTEGER Storage_Device_Contain_File_ID_Flag;		%% 1.16 M*-TYDE
	Storage_Device_Contain_File_ID_Flag = Invalid_Storage_Device_Contain_File_Id(FILE_ID);		%% 1.17 M*-ASS
	return;		%% 1.18.2 M*-RET
	if Storage_Device_Contain_File_ID_Flag == 0		%% 1.18 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;		%% 1.18.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EIO;		%% 1.18.1 M*-ASS
		return;		%% 1.18.2 M*-RET
	end
	return;		%% 1.19.2 M*-RET
	if CURRENT_PARTITION.LOCK_LEVEL > 0		%% 1.19 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;		%% 1.19.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EACCES;		%% 1.19.1 M*-ASS
		return;		%% 1.19.2 M*-RET
	end
	return;		%% 1.20.2 M*-RET
	if CurrentProcess == ERROR_HANDLER_PROCESS_ID		%% 1.20 M*-IFS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;		%% 1.20.0 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EACCES;		%% 1.20.1 M*-ASS
		return;		%% 1.20.2 M*-RET
	end
	return;		%% 1.21.9 M*-RET
	if File_Id_In_Current_Partition_Flag ~= 0 && File_Id_has_Operation_Flag ~= 0 && File_Id_has_Read_Write_Access_Mode_Flag ~= 0 && LENGTH > 0 && Volume_Space_Flag ~= 0 && Length_Greater_than_Miximun_Flag ~= 0 && Storage_Device_Contain_File_ID_Flag ~= 0 && CURRENT_PARTITION.LOCK_LEVEL == 0 && CurrentProcess ~= ERROR_HANDLER_PROCESS_ID		%% 1.21 M*-IFS
		% APEX_INTEGER File_Position,File_Size,File_Nb_Of_Changes,ID;		%% 1.21.0 M*-TYDE
		ID = FILE_ID;		%% 1.21.1 M*-ASS
		File_Position = File_Set{FILE_ID,3} + LENGTH;		%% 1.21.2 M*-ASS
		File_Size = File_Set{FILE_ID,4};		%% 1.21.3 M*-ASS
		File_Nb_Of_Changes = File_Set{FILE_ID,5};		%% 1.21.4 M*-ASS
		transfer_from_message(FILE_ID,MESSAGE_ADDR);		%% 1.21.5 M*-FUC
		if File_Position > File_Size		%% 1.21.6 M*-IFS
			File_Set{FILE_ID,4} = File_Position;		%% 1.21.6.0 M*-ASS
		end
		File_Set{FILE_ID,5} = File_Nb_Of_Changes + 1;		%% 1.21.7 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;		%% 1.21.8 M*-ASS
		return;		%% 1.21.9 M*-RET
	end

end


