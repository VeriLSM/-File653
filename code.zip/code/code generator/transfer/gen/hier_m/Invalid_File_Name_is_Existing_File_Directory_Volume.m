function [index] = Invalid_File_Name_is_Existing_File_Directory_Volume(FILE_NAME)		%% 1 M*-FUCD

	global Directory_Set;		%%  M*-GLBD
	global File_Set;		%%  M*-GLBD

	% APEX_BYTE volume_name[MAX_FILE_NAME_LENGTH];		%% 1.0 M*-TYDE
	% APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];		%% 1.1 M*-TYDE
	% APEX_INTEGER VOL_ID,DIR_ID,index;		%% 1.2 M*-TYDE
	volume_name = get_volume_name(FILE_NAME);		%% 1.3 M*-ASS
	path_prefix = get_file_prefix(FILE_NAME);		%% 1.4 M*-ASS
	Directory_Name_Set=[File_Set{:,1}];		%% 1.5 M*-ETKS
	[~,VOL_ID] = ismember(volume_name, Directory_Name_Set);		%% 1.6 M*-EISM
	index = VOL_ID;		%% 1.7 M*-ASS
	return;		%% 1.8.0 M*-RET
	if index == 0		%% 1.8 M*-IFS
		return;		%% 1.8.0 M*-RET
	end
	[~,DIR_ID] = ismember(path_prefix, Directory_Name_Set);		%% 1.9 M*-EISM
	index = DIR_ID;		%% 1.10 M*-ASS
	return;		%% 1.11.0 M*-RET
	if index == 0		%% 1.11 M*-IFS
		return;		%% 1.11.0 M*-RET
	end
	[~,ID] = ismember(FILE_NAME, Directory_Name_Set);		%% 1.12 M*-EISM
	index = ID;		%% 1.13 M*-ASS
	return;		%% 1.14 M*-RET

end


