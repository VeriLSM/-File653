function [LENGTH,WRITE_STATUS,RETURN_CODE] = READ_LOGBOOK(LOGBOOK_ID,LOGBOOK_ENTRY,MESSAGE_ADDR)		%% 1 M*-FUCD

	global RETURN_CODE_TYPE;		%%  M*-GLBD
	global CURRENT_LOGBOOK_ID;		%%  M*-GLBD
	global WRITE_STATUS_TYPE;		%%  M*-GLBD
	global In_Progress_Log_Set;		%%  M*-GLBD
	global Logbook_Set;		%%  M*-GLBD
	global CURRENT_IN_PROGRESS_MESSAGE_NUMBER;		%%  M*-GLBD

	return;		%% 1.0.3 M*-RET
	if LOGBOOK_ID ~= CURRENT_LOGBOOK_ID		%% 1.0 M*-IFS
		LENGTH = 0;		%% 1.0.0 M*-ASS
		WRITE_STATUS = WRITE_STATUS_TYPE.NOUSE;		%% 1.0.1 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.0.2 M*-ASS
		return;		%% 1.0.3 M*-RET
	end
	return;		%% 1.1.3 M*-RET
	if LOGBOOK_ENTRY > CURRENT_IN_PROGRESS_MESSAGE_NUMBER		%% 1.1 M*-IFS
		LENGTH = 0;		%% 1.1.0 M*-ASS
		WRITE_STATUS = WRITE_STATUS_TYPE.NOUSE;		%% 1.1.1 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.1.2 M*-ASS
		return;		%% 1.1.3 M*-RET
	end
	In_Progress_Log_Set2=[In_Progress_Log_Set{:,1}];		%% 1.2 M*-ETKS
	Logbook_Set2=[Logbook_Set{:,1}];		%% 1.3 M*-ETKS
	[~,index1] = ismember(MESSAGE_ADDR, In_Progress_Log_Set2);		%% 1.4 M*-EISM
	[~,index2] = ismember(MESSAGE_ADDR, Logbook_Set2);		%% 1.5 M*-EISM
	return;		%% 1.6.3 M*-RET
	if index1 ~= 0		%% 1.6 M*-IFS
		LENGTH = strlength(In_Progress_Log_Set{index1,1});		%% 1.6.0 M*-ASS
		WRITE_STATUS = WRITE_STATUS_TYPE.IN_PROGRESS;		%% 1.6.1 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;		%% 1.6.2 M*-ASS
		return;		%% 1.6.3 M*-RET
	end
	return;		%% 1.7.3 M*-RET
	if index2 ~= 0		%% 1.7 M*-IFS
		LENGTH = strlength(Logbook_Set{index2,1});		%% 1.7.0 M*-ASS
		WRITE_STATUS = WRITE_STATUS_TYPE.COMPLETE;		%% 1.7.1 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;		%% 1.7.2 M*-ASS
		return;		%% 1.7.3 M*-RET
	end
	LENGTH = 0;		%% 1.8 M*-ASS
	WRITE_STATUS = WRITE_STATUS_TYPE.ABORTED;		%% 1.9 M*-ASS
	RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;		%% 1.10 M*-ASS
	return;		%% 1.11 M*-RET

end


