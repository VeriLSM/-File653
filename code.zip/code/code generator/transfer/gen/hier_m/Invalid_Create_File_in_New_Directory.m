function [index] = Invalid_Create_File_in_New_Directory(NEW_FILE_NAME)		%% 1 M*-FUCD

	global Directory_Set;		%%  M*-GLBD
	global DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS;		%%  M*-GLBD
	global File_Set;		%%  M*-GLBD

	% APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];		%% 1.0 M*-TYDE
	path_prefix = get_file_prefix(NEW_FILE_NAME);		%% 1.1 M*-ASS
	% APEX_INTEGER DIR_ID,index;		%% 1.2 M*-TYDE
	Directory_Name_Set=[Directory_Set{:,1}];		%% 1.3 M*-ETKS
	[~,DIR_ID] = ismember(path_prefix, Directory_Name_Set);		%% 1.4 M*-EISM
	if File_Set{DIR_ID,11} < DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS		%% 1.5 M*-IFS
		index = 1;		%% 1.5.0 M*-ASS
	else		%% 1.6 M*-ELS
		index = 0;		%% 1.6.0 M*-ASS
	end
	return;		%% 1.7 M*-RET

end


