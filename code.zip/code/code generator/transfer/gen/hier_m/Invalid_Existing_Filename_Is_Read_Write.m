function [index] = Invalid_Existing_Filename_Is_Read_Write(FILE_NAME)		%% 1 M*-FUCD

	global File_Set;		%%  M*-GLBD
	global Open_File_Set;		%%  M*-GLBD
	global FILE_MODE_TYPE;		%%  M*-GLBD

	% APEX_INTEGER ID,index,j;		%% 1.0 M*-TYDE
	Directory_Name_Set=[File_Set{:,1}];		%% 1.1 M*-ETKS
t[~,ID] = ismember(FILE_NAME, Directory_Name_Set);		%% 1.2 M*-EISM
	return;		%% 1.3.1 M*-RET
	if ID == 0		%% 1.3 M*-IFS
		index = 0;		%% 1.3.0 M*-ASS
		return;		%% 1.3.1 M*-RET
	end
	return;		%% 1.4.1 M*-RET
	if File_Set{ID,9} == FILE_MODE_TYPE.READ		%% 1.4 M*-IFS
		index = 0;		%% 1.4.0 M*-ASS
		return;		%% 1.4.1 M*-RET
	end
t[~,j] = ismember(ID, Open_File_Set);		%% 1.5 M*-EISM
	return;		%% 1.6.1 M*-RET
	if j == 0		%% 1.6 M*-IFS
		index = 0;		%% 1.6.0 M*-ASS
		return;		%% 1.6.1 M*-RET
	end
	index = 1;		%% 1.7 M*-ASS
	return;		%% 1.8 M*-RET

end


