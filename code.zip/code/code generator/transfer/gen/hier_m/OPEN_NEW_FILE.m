function [FILE_ID,RETURN_CODE,ERRNO] = OPEN_NEW_FILE(FILE_NAME,ERRNO)		%% 1 M*-FUCD

	global RETURN_CODE_TYPE;		%%  M*-GLBD
	global ERRNO_ERROR_TYPE;		%%  M*-GLBD
	global CURRENT_PARTITION;		%%  M*-GLBD
	global CurrentProcess;		%%  M*-GLBD
	global ERROR_HANDLER_PROCESS_ID;		%%  M*-GLBD
	global Directory_Set;		%%  M*-GLBD
	global File_Set;		%%  M*-GLBD
	global ENTRY_KIND_TYPE;		%%  M*-GLBD
	global FILE_MODE_TYPE;		%%  M*-GLBD
	global Open_File_Set;		%%  M*-GLBD
	global PARTION_OPEN_FILES_NUMBERS;		%%  M*-GLBD
	global PARTION_EXIT_FILES_NUMBERS;		%%  M*-GLBD
	global File_System_Configuation_Table;		%%  M*-GLBD
	global MAX_ATOMIC_SIZE;		%%  M*-GLBD

	% APEX_INTEGER Fileindex;		%% 1.0 M*-TYDE
	Fileindex = CapacityofFile;		%% 1.1 M*-ASS
	return;		%% 1.2.3 M*-RET
	if Fileindex == 0		%% 1.2 M*-IFS
		FILE_ID = -1;		%% 1.2.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;		%% 1.2.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EMFILE;		%% 1.2.2 M*-ASS
		return;		%% 1.2.3 M*-RET
	end
	% APEX_INTEGER File_Length_Flag;		%% 1.3 M*-TYDE
	File_Length_Flag = Invalid_File_Length(FILE_NAME);		%% 1.4 M*-ASS
	return;		%% 1.5.3 M*-RET
	if File_Length_Flag == 0		%% 1.5 M*-IFS
		FILE_ID = -1;		%% 1.5.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.5.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.ENAMETOOLONG;		%% 1.5.2 M*-ASS
		return;		%% 1.5.3 M*-RET
	end
	% APEX_INTEGER File_Syntax_Flag;		%% 1.6 M*-TYDE
	File_Syntax_Flag = Invalid_File_Syntax(FILE_NAME);		%% 1.7 M*-ASS
	return;		%% 1.8.3 M*-RET
	if File_Syntax_Flag == 0		%% 1.8 M*-IFS
		FILE_ID = -1;		%% 1.8.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.8.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EINVAL;		%% 1.8.2 M*-ASS
		return;		%% 1.8.3 M*-RET
	end
	% APEX_INTEGER File_Path_Prefix_Flag;		%% 1.9 M*-TYDE
	File_Path_Prefix_Flag = Invalid_File_Path_Prefix(FILE_NAME);		%% 1.10 M*-ASS
	return;		%% 1.11.3 M*-RET
	if File_Path_Prefix_Flag == 0		%% 1.11 M*-IFS
		FILE_ID = -1;		%% 1.11.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.11.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.ENOTDIR;		%% 1.11.2 M*-ASS
		return;		%% 1.11.3 M*-RET
	end
	% APEX_INTEGER Invalid_Partition_Mode_Flag;		%% 1.12 M*-TYDE
	Invalid_Partition_Mode_Flag = Invalid_Partition_Read_Write_Access_Rights(FILE_NAME);		%% 1.13 M*-ASS
	return;		%% 1.14.3 M*-RET
	if Invalid_Partition_Mode_Flag == 0		%% 1.14 M*-IFS
		FILE_ID = -1;		%% 1.14.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;		%% 1.14.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EACCES;		%% 1.14.2 M*-ASS
		return;		%% 1.14.3 M*-RET
	end
	% APEX_INTEGER Invalid_Device_Write_Protected_Flag;		%% 1.15 M*-TYDE
	Invalid_Device_Write_Protected_Flag = Invalid_Device_Is_Write_Protected;		%% 1.16 M*-ASS
	return;		%% 1.17.3 M*-RET
	if Invalid_Device_Write_Protected_Flag == 0		%% 1.17 M*-IFS
		FILE_ID = -1;		%% 1.17.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.17.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EROFS;		%% 1.17.2 M*-ASS
		return;		%% 1.17.3 M*-RET
	end
	% APEX_INTEGER Existing_File_Flag;		%% 1.18 M*-TYDE
	Existing_File_Flag = Invalid_Existing_File(FILE_NAME);		%% 1.19 M*-ASS
	return;		%% 1.20.3 M*-RET
	if Existing_File_Flag > 0		%% 1.20 M*-IFS
		FILE_ID = -1;		%% 1.20.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.20.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EEXIST;		%% 1.20.2 M*-ASS
		return;		%% 1.20.3 M*-RET
	end
	% APEX_INTEGER Existing_Directory_Flag;		%% 1.21 M*-TYDE
	Existing_Directory_Flag = Invalid_Existing_Directory(FILE_NAME);		%% 1.22 M*-ASS
	return;		%% 1.23.3 M*-RET
	if Existing_Directory_Flag == 0		%% 1.23 M*-IFS
		FILE_ID = -1;		%% 1.23.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;		%% 1.23.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EISDIR;		%% 1.23.2 M*-ASS
		return;		%% 1.23.3 M*-RET
	end
	% APEX_INTEGER Volume_Space_Flag;		%% 1.24 M*-TYDE
	Volume_Space_Flag = Invalid_Volume_Space_Available(FILE_NAME);		%% 1.25 M*-ASS
	return;		%% 1.26.3 M*-RET
	if Volume_Space_Flag == 0		%% 1.26 M*-IFS
		FILE_ID = -1;		%% 1.26.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;		%% 1.26.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.ENOSPC;		%% 1.26.2 M*-ASS
		return;		%% 1.26.3 M*-RET
	end
	% APEX_INTEGER Storage_Device_Flag;		%% 1.27 M*-TYDE
	Storage_Device_Flag = Invalid_Storage_Device_Contain_File_Name(FILE_NAME);		%% 1.28 M*-ASS
	return;		%% 1.29.3 M*-RET
	if Storage_Device_Flag == 0		%% 1.29 M*-IFS
		FILE_ID = -1;		%% 1.29.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;		%% 1.29.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EIO;		%% 1.29.2 M*-ASS
		return;		%% 1.29.3 M*-RET
	end
	return;		%% 1.30.3 M*-RET
	if CURRENT_PARTITION.LOCK_LEVEL > 0		%% 1.30 M*-IFS
		FILE_ID = -1;		%% 1.30.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;		%% 1.30.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EACCES;		%% 1.30.2 M*-ASS
		return;		%% 1.30.3 M*-RET
	end
	return;		%% 1.31.3 M*-RET
	if CurrentProcess == ERROR_HANDLER_PROCESS_ID		%% 1.31 M*-IFS
		FILE_ID = -1;		%% 1.31.0 M*-ASS
		RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;		%% 1.31.1 M*-ASS
		ERRNO = ERRNO_ERROR_TYPE.EACCES;		%% 1.31.2 M*-ASS
		return;		%% 1.31.3 M*-RET
	end
	% APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];		%% 1.32 M*-TYDE
	path_prefix = get_file_prefix(FILE_NAME);		%% 1.33 M*-ASS
	% APEX_INTEGER DIR_ID;		%% 1.34 M*-TYDE
	Directory_Name_Set=[Directory_Set{:,1}];		%% 1.35 M*-ETKS
	[~,DIR_ID] = ismember(path_prefix, Directory_Name_Set);		%% 1.36 M*-EISM
	File_Set{DIR_ID,11} = File_Set{DIR_ID,11} + 1;		%% 1.38 M*-ASS
	% APEX_INTEGER ID;		%% 1.39 M*-TYDE
	ID = Fileindex;		%% 1.40 M*-ASS
	FILE_ID = ID;		%% 1.41 M*-ASS
	File_Set{Fileindex,1} = FILE_NAME;		%% 1.42 M*-ASS
	File_Set{Fileindex,2} = ID;		%% 1.43 M*-ASS
	File_Set{Fileindex,3} = 0;		%% 1.44 M*-ASS
	File_Set{Fileindex,4} = 0;		%% 1.45 M*-ASS
	File_Set{Fileindex,5} = 0;		%% 1.46 M*-ASS
	File_Set{Fileindex,6} = 0;		%% 1.47 M*-ASS
	File_Set{Fileindex,7} = "";		%% 1.48 M*-ASS
	File_Set{Fileindex,8} = 1;		%% 1.49 M*-ASS
	File_Set{Fileindex,9} = FILE_MODE_TYPE.READ_WRITE;		%% 1.50 M*-ASS
	File_Set{Fileindex,10} = ENTRY_KIND_TYPE.FILE_ENTRY;		%% 1.51 M*-ASS
	File_Set{Fileindex,11} = 0;		%% 1.52 M*-ASS
	File_Set{Fileindex,12} = ID;		%% 1.53 M*-ASS
	PARTION_OPEN_FILES_NUMBERS = PARTION_OPEN_FILES_NUMBERS + 1;		%% 1.54 M*-ASS
	PARTION_EXIT_FILES_NUMBERS = PARTION_EXIT_FILES_NUMBERS + 1;		%% 1.55 M*-ASS
	Open_File_Set(ID) = 1;		%% 1.56 M*-ASS
	File_System_Configuation_Table{1,3} = File_System_Configuation_Table{1,3} - 1;		%% 1.57 M*-ASS
	File_System_Configuation_Table{1,8} = File_System_Configuation_Table{1,8} - 1;		%% 1.58 M*-ASS
	RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;		%% 1.59 M*-ASS
	ERRNO = ERRNO_ERROR_TYPE.EUNCHANGE;		%% 1.60 M*-ASS
	return;		%% 1.61 M*-RET

end


