function [index] = Invalid_Device_Is_Write_Protected()		%% 1 M*-FUCD


	% APEX_INTEGER index;		%% 1.0 M*-TYDE
	index = 1;		%% 1.1 M*-ASS
	return;		%% 1.2 M*-RET

end


