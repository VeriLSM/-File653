function [index] = Invalid_File_Id_In_Current_Partition(FILE_ID)		%% 1 M*-FUCD

	global Open_File_Set;		%%  M*-GLBD
	global SYSTEM_LIMIT_FILE_SIZE;		%%  M*-GLBD

	% APEX_INTEGER index;		%% 1.0 M*-TYDE
	if FILE_ID <= 0 || FILE_ID > SYSTEM_LIMIT_FILE_SIZE		%% 1.1 M*-IFS
		index = 0;		%% 1.1.0 M*-ASS
	else		%% 1.2 M*-ELS
		index = Open_File_Set(FILE_ID);		%% 1.2.0 M*-ASS
	end
	return;		%% 1.3 M*-RET

end


