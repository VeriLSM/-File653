function [ index ] = CapacityofFile()

    global PARTION_LIMIT_OPEN_FILE_NUMBERS;
    global PARTION_OPEN_FILES_NUMBERS;
    global PARTION_EXIT_FILES_NUMBERS;
    global MAX_DIRECTORY_NUMBER;


    %APEX_INTEGER index;
    if (PARTION_OPEN_FILES_NUMBERS < PARTION_LIMIT_OPEN_FILE_NUMBERS) && (PARTION_EXIT_FILES_NUMBERS < MAX_DIRECTORY_NUMBER)
        index = PARTION_EXIT_FILES_NUMBERS + 1;
    else
        index = 0;
    end
    return;

end

