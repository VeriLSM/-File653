function  [RETURN_CODE,ERRNO] = RESIZE_FILE(FILE_ID,NEW_SIZE,ERRNO)
    global RETURN_CODE_TYPE;
    global ERRNO_ERROR_TYPE;
    global CurrentProcess;
    global ERROR_HANDLER_PROCESS_ID;
    global File_Set;
    global File_System_Configuation_Table;
    global CURRENT_PARTITION;
    
    %APEX_INTEGER File_Id_In_Current_Partition_Flag;
    File_Id_In_Current_Partition_Flag = Invalid_File_Id_In_Current_Partition(FILE_ID);
    if File_Id_In_Current_Partition_Flag == 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EBADF;
        return;
    end
    
    %APEX_INTEGER File_Id_has_Operation_Flag;
    File_Id_has_Operation_Flag = Invalid_File_Id_has_Operation(FILE_ID);
    if File_Id_has_Operation_Flag == 0
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EBUSY;
        return;
    end
    
    %APEX_INTEGER File_Id_is_Read_Only_Flag;
    File_Id_is_Read_Only_Flag = Invalid_File_Id_is_Read_Only(FILE_ID);
    if File_Id_is_Read_Only_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    if NEW_SIZE < 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EINVAL;
        return;
    end
    
    %APEX_INTEGER Volume_Space_Available_to_New_Size_Flag;
    Volume_Space_Available_to_New_Size_Flag = Invalid_Volume_Space_Available_to_New_Size(FILE_ID,NEW_SIZE);
    if Volume_Space_Available_to_New_Size_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        ERRNO = ERRNO_ERROR_TYPE.ENOSPC;
        return;
    end
    
    %APEX_INTEGER Storage_Device_Contain_File_Id_Flag;
    Storage_Device_Contain_File_Id_Flag = Invalid_Storage_Device_Contain_File_Id(FILE_ID);
    if Storage_Device_Contain_File_Id_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EIO;
        return;
    end
    
    if CURRENT_PARTITION.LOCK_LEVEL > 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    if CurrentProcess == ERROR_HANDLER_PROCESS_ID
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    %APEX_INTEGER File_Size,File_Position,ID;
    ID = FILE_ID;
    File_Size = File_Set{ID,4};

    File_System_Configuation_Table{1,5} = File_System_Configuation_Table{1,5} + File_Size - NEW_SIZE;
    File_System_Configuation_Table{1,4} = File_System_Configuation_Table{1,4} - File_Size + NEW_SIZE;

    File_Set{ID,4} = NEW_SIZE;

    File_Position = File_Set{ID,3};
    if NEW_SIZE < File_Position
        File_Set{ID,3} = NEW_SIZE;
    end

    File_Set{ID,5} = File_Set{ID,5} + 1;
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
    ERRNO = ERRNO_ERROR_TYPE.EUNCHANGE;
    return;
end
