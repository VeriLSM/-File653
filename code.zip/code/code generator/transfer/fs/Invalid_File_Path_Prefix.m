function  [index] = Invalid_File_Path_Prefix(FILE_NAME)
    global Directory_Set;
    
    % APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];
    % APEX_INTEGER index,DIR_ID;
    path_prefix = get_file_prefix(FILE_NAME);
    
    Directory_Name_Set = [Directory_Set{:,1}];
    [~,DIR_ID] = ismember(path_prefix,Directory_Name_Set);
    index = DIR_ID;
    return;
end