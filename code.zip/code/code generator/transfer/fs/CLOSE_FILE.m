function  [RETURN_CODE,ERRNO] = CLOSE_FILE(FILE_ID,ERRNO)
    global RETURN_CODE_TYPE;
    global ERRNO_ERROR_TYPE;
    global CURRENT_PARTITION;
    global FILE_MODE_TYPE;
    global File_Set;
    global Open_File_Set;
    global PARTION_OPEN_FILES_NUMBERS;
    global CurrentProcess;
    global ERROR_HANDLER_PROCESS_ID;

    %APEX_INTEGER File_Id_In_Current_Partition_Flag;
    File_Id_In_Current_Partition_Flag = Invalid_File_Id_In_Current_Partition(FILE_ID);
    if  File_Id_In_Current_Partition_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EBADF;
        return;
    end
    
    %APEX_INTEGER File_Id_has_Operation_Flag;
    File_Id_has_Operation_Flag = Invalid_File_Id_has_Operation(FILE_ID);
    if File_Id_has_Operation_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EBUSY;
        return;
    end
    
    %APEX_INTEGER Storage_Device_Contain_File_ID_Flag;
    Storage_Device_Contain_File_ID_Flag = Invalid_Storage_Device_Contain_File_Id(FILE_ID);
    if  Storage_Device_Contain_File_ID_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EIO;
        return;
    end
    
    if CURRENT_PARTITION.LOCK_LEVEL > 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    if CurrentProcess == ERROR_HANDLER_PROCESS_ID
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    
    % FILE_MODE_TYPE access_right;
    % APEX_INTEGER ID;
    ID = FILE_ID;
    access_right = File_Set{FILE_ID,9};
    if access_right == FILE_MODE_TYPE.READ_WRITE
    end
   
    Open_File_Set(FILE_ID) = 0;
    
    PARTION_OPEN_FILES_NUMBERS = PARTION_OPEN_FILES_NUMBERS - 1;
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
    ERRNO = ERRNO_ERROR_TYPE.EUNCHANGE;
    return;
    
end