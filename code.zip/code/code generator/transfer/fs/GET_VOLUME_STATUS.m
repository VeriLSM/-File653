function  [VOLUME_STATUS,RETURN_CODE,ERRNO] = GET_VOLUME_STATUS(FILE_NAME,ERRNO)
    global RETURN_CODE_TYPE;
    global ERRNO_ERROR_TYPE;
    global CURRENT_PARTITION;
    global ERROR_HANDLER_PROCESS_ID;
    global Directory_Set;
    global File_System_Configuation_Table;
    
    %APEX_INTEGER File_length_Flag;
    File_length_Flag = Invalid_File_Length(FILE_NAME);
    if File_length_Flag == 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.ENAMETOOLONG;
        VOLUME_STATUS.TOTAL_BYTES = 0;
        VOLUME_STATUS.USED_BYTES = 0;
        return;
    end
    
    %APEX_INTEGER File_Syntax_Flag;
    File_Syntax_Flag = Invalid_File_Syntax(FILE_NAME);
    if File_Syntax_Flag == 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EINVAL;
        VOLUME_STATUS.TOTAL_BYTES = 0;
        VOLUME_STATUS.USED_BYTES = 0;
        VOLUME_STATUS.FREE_BYTES = 0;
        return;
    end
    
    %APEX_INTEGER File_Path_Prefix_Flag;
    File_Path_Prefix_Flag = Invalid_File_Path_Prefix(FILE_NAME);
    if File_Path_Prefix_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.ENOTDIR;
        VOLUME_STATUS.TOTAL_BYTES = 0;
        VOLUME_STATUS.USED_BYTES = 0;
        VOLUME_STATUS.FREE_BYTES = 0;
        return;
    end
    
    %APEX_INTEGER File_Name_is_Directory_Volume_Flag;
    File_Name_is_Directory_Volume_Flag = Invalid_File_Name_is_Existing_File_Directory_Volume(FILE_NAME);
    if File_Name_is_Directory_Volume_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        ERRNO = ERRNO_ERROR_TYPE.ENOENT;
        VOLUME_STATUS.TOTAL_BYTES = 0;
        VOLUME_STATUS.USED_BYTES = 0;
        VOLUME_STATUS.FREE_BYTES = 0;
        return;
    end
    
    %APEX_INTEGER Partion_Has_Write_Read_Rights_Flag;
    Partion_Has_Write_Read_Rights_Flag = Invalid_Partion_Has_Write_Read_Rights(FILE_NAME);
    if Partion_Has_Write_Read_Rights_Flag == 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        VOLUME_STATUS.TOTAL_BYTES = 0;
        VOLUME_STATUS.USED_BYTES = 0;
        VOLUME_STATUS.FREE_BYTES = 0;
        return;
    end
    
    %APEX_INTEGER Storage_Device_Contain_File_Name_Flag;
    Storage_Device_Contain_File_Name_Flag = Invalid_Storage_Device_Contain_File_Name(FILE_NAME);
    if Storage_Device_Contain_File_Name_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EIO;
        VOLUME_STATUS.TOTAL_BYTES = 0;
        VOLUME_STATUS.USED_BYTES = 0;
        VOLUME_STATUS.FREE_BYTES = 0;
        return;
    end
    
    if CURRENT_PARTITION.LOCK_LEVEL > 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        VOLUME_STATUS.TOTAL_BYTES = 0;
        VOLUME_STATUS.USED_BYTES = 0;
        VOLUME_STATUS.FREE_BYTES = 0;
        return;
    end
    
    if CurrentProcess == ERROR_HANDLER_PROCESS_ID
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        VOLUME_STATUS.TOTAL_BYTES = 0;
        VOLUME_STATUS.USED_BYTES = 0;
        VOLUME_STATUS.FREE_BYTES = 0;
        return;
    end
    
    VOLUME_STATUS.TOTAL_BYTES = File_System_Configuation_Table{1,4};
    VOLUME_STATUS.USED_BYTES = File_System_Configuation_Table{1,4} - File_System_Configuation_Table{1,3};
    VOLUME_STATUS.FREE_BYTES = File_System_Configuation_Table{1,3};
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
    ERRNO = ERRNO_ERROR_TYPE.EUNCHANGE;
    return;
        
end
