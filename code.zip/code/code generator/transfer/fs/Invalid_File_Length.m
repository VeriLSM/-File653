function [ index ] = Invalid_File_Length( FILE_NAME )
    global MAX_FILE_NAME_LENGTH;
    
    %APEX_INTEGER index,len;
    len = strlength(FILE_NAME);
    if len>0 && len<MAX_FILE_NAME_LENGTH
        index = 1;
    else
        index = 0;
    end

    return;

end

