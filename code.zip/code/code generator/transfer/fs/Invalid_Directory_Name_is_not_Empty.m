function [ index ] = Invalid_Directory_Name_is_not_Empty( DIRECTORY_NAME )
    global Directory_Set;
    global File_Set;
    % APEX_INTEGER DIR_ID;
    Directory_Name_Set = [Directory_Set{:,1}];
    [~,DIR_ID] = ismember(DIRECTORY_NAME,Directory_Name_Set);
    % APEX_INTEGER index;
    if File_Set{DIR_ID,11} == 0
        index = 1;
    else
        index = 0;
    end
    return;
    
end