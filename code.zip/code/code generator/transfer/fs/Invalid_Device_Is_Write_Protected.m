function [ index ] = Invalid_Device_Is_Write_Protected()

    % APEX_INTEGER index;
    index = 1;
    return;

end