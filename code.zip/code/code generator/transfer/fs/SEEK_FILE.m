function  [POSITION,RETURN_CODE,ERRNO] = SEEK_FILE(FILE_ID,OFFSET,WHENCE,ERRNO)
    global RETURN_CODE_TYPE;
    global ERRNO_ERROR_TYPE;
    global FILE_SEEK_TYPE;
    global File_Set;
    global CURRENT_PARTITION;
    global CurrentProcess;
    global ERROR_HANDLER_PROCESS_ID;
    
    %APEX_INTEGER File_Id_In_Current_Partition_Flag;
    File_Id_In_Current_Partition_Flag = Invalid_File_Id_In_Current_Partition(FILE_ID);
    if File_Id_In_Current_Partition_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EBADF;
        POSITION = -1;
        return;
    end
    
    %APEX_INTEGER File_Id_has_Operation_Flag;
    File_Id_has_Operation_Flag = Invalid_File_Id_has_Operation(FILE_ID);
    if  File_Id_has_Operation_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EBUSY;
        POSITION = -1;
        return;
    end
    
    %APEX_INTEGER File_Id_Due_to_Owner_Action_Flag;
    File_Id_Due_to_Owner_Action_Flag = Invalid_File_Id_Due_to_Owner_Action(FILE_ID);
    if  File_Id_Due_to_Owner_Action_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.ESTALE;
        POSITION = -1;
        return;
    end
    
    %APEX_INTEGER APEX_INTEGER_Flag;
    APEX_INTEGER_Flag = Invalid_Whence_Type(WHENCE);
    if APEX_INTEGER_Flag == 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EINVAL;
        POSITION = -1;
        return;
    end
    
    % APEX_INTEGER File_Position,File_Size,ID;
    ID = FILE_ID;
    File_Position = File_Set{FILE_ID,3};
    File_Size = File_Set{FILE_ID,4};
    
    % APEX_INTEGER Offset_value_Flag;
    Offset_value_Flag = Invalid_Offset_value(OFFSET,File_Size);
    if WHENCE == FILE_SEEK_TYPE.SEEK_SET_TYPE && Offset_value_Flag < 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EINVAL;
        POSITION = -1;
        return;
    end
    
    Offset_value_Flag = Invalid_Offset_value(File_Position+OFFSET,File_Size);
    if WHENCE == FILE_SEEK_TYPE.SEEK_CUR_TYPE && Offset_value_Flag < 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EINVAL;
        POSITION = -1;
        return;
    end
    
    Offset_value_Flag = Invalid_Offset_value(File_Size+OFFSET,File_Size);
    if WHENCE == FILE_SEEK_TYPE.SEEK_END_TYPE &&  Offset_value_Flag < 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EINVAL;
        POSITION = -1;
        return;
    end
    
    % APEX_INTEGER Storage_Device_Contain_File_Id_Flag;
    Storage_Device_Contain_File_Id_Flag = Invalid_Storage_Device_Contain_File_Id(FILE_ID);
    if  Storage_Device_Contain_File_Id_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EIO;
        POSITION = -1;
        return;
    end
    
    if CURRENT_PARTITION.LOCK_LEVEL > 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        POSITION = -1;
        return;
    end
    
    if CurrentProcess == ERROR_HANDLER_PROCESS_ID
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        POSITION = -1;
        return;
    end

    if WHENCE == FILE_SEEK_TYPE.SEEK_SET_TYPE
        File_Set{FILE_ID,3} = OFFSET;
        POSITION = OFFSET;
    elseif WHENCE == FILE_SEEK_TYPE.SEEK_CUR_TYPE
        File_Set{FILE_ID,3} = File_Position + OFFSET;
        POSITION = File_Position + OFFSET;
    else
        File_Set{FILE_ID,3} = File_Size + OFFSET;
        POSITION = File_Size + OFFSET;
    end

    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
    ERRNO = ERRNO_ERROR_TYPE.EUNCHANGE;
    return;

end
