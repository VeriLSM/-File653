function [ index ] = Invalid_Directory_Length( DIRECTORY_NAME )

    global MAX_DIRECTORY_ENTRY_LENGTH;

    %APEX_INTEGER index,len;
    len = strlength(DIRECTORY_NAME);
    if len>0 && len<MAX_DIRECTORY_ENTRY_LENGTH
        index = 1;
    else
        index = 0;
    end

    return;

end
