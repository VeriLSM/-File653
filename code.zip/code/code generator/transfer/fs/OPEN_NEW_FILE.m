function  [FILE_ID,RETURN_CODE,ERRNO] = OPEN_NEW_FILE(FILE_NAME,ERRNO)
    global RETURN_CODE_TYPE;
    global ERRNO_ERROR_TYPE;
    global CURRENT_PARTITION;
    global CurrentProcess;
    global ERROR_HANDLER_PROCESS_ID;
    global Directory_Set;
    global File_Set;
    global ENTRY_KIND_TYPE;
    global FILE_MODE_TYPE;
    global Open_File_Set;
    global PARTION_OPEN_FILES_NUMBERS;
    global PARTION_EXIT_FILES_NUMBERS;
    global File_System_Configuation_Table;
    global MAX_ATOMIC_SIZE;

    %APEX_INTEGER Fileindex;
    Fileindex = CapacityofFile();
    if Fileindex == 0
        FILE_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        ERRNO = ERRNO_ERROR_TYPE.EMFILE;
        return;
    end
    
    %APEX_INTEGER File_Length_Flag;
    File_Length_Flag = Invalid_File_Length(FILE_NAME);
    if File_Length_Flag == 0
        FILE_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.ENAMETOOLONG;
        return;
    end
    
    %APEX_INTEGER File_Syntax_Flag;
    File_Syntax_Flag = Invalid_File_Syntax(FILE_NAME);
    if  File_Syntax_Flag == 0
        FILE_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EINVAL;
        return;
    end
    
    %APEX_INTEGER File_Path_Prefix_Flag;
    File_Path_Prefix_Flag = Invalid_File_Path_Prefix(FILE_NAME);
    if  File_Path_Prefix_Flag == 0 
        FILE_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.ENOTDIR;
        return;
    end
    
    %APEX_INTEGER Invalid_Partition_Mode_Flag;
    Invalid_Partition_Mode_Flag = Invalid_Partition_Read_Write_Access_Rights(FILE_NAME);
    if  Invalid_Partition_Mode_Flag == 0 
        FILE_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    %APEX_INTEGER Invalid_Device_Write_Protected_Flag;
    Invalid_Device_Write_Protected_Flag = Invalid_Device_Is_Write_Protected();
    if Invalid_Device_Write_Protected_Flag == 0 
        FILE_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EROFS;
        return;
    end
    
    %APEX_INTEGER Existing_File_Flag;
    Existing_File_Flag = Invalid_Existing_File(FILE_NAME);
    if Existing_File_Flag > 0 
        FILE_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EEXIST;
        return;
    end

    %APEX_INTEGER Existing_Directory_Flag;
    Existing_Directory_Flag = Invalid_Existing_Directory(FILE_NAME);
    if  Existing_Directory_Flag == 0 
        FILE_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EISDIR;
        return;
    end
    
    %APEX_INTEGER Volume_Space_Flag;
    Volume_Space_Flag = Invalid_Volume_Space_Available(FILE_NAME);
    if Volume_Space_Flag == 0 
        FILE_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_CONFIG;
        ERRNO = ERRNO_ERROR_TYPE.ENOSPC;
        return;
    end
    
    %APEX_INTEGER Storage_Device_Flag;
    Storage_Device_Flag = Invalid_Storage_Device_Contain_File_Name(FILE_NAME);
    if  Storage_Device_Flag == 0 
        FILE_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EIO;
        return;
    end
    
    
    if CURRENT_PARTITION.LOCK_LEVEL > 0
        FILE_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    if CurrentProcess == ERROR_HANDLER_PROCESS_ID
        FILE_ID = -1;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end

    % APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];
    path_prefix = get_file_prefix(FILE_NAME);

    % APEX_INTEGER DIR_ID;
    Directory_Name_Set = [Directory_Set{:,1}];
    [~,DIR_ID] = ismember(path_prefix,Directory_Name_Set);
    write_directory(DIR_ID,FILE_NAME,Fileindex);

    File_Set{DIR_ID,11} = File_Set{DIR_ID,11} + 1;

    % APEX_INTEGER ID;
    ID = Fileindex;
    FILE_ID = ID;
    File_Set{Fileindex,1} = FILE_NAME;
    File_Set{Fileindex,2} = ID;
    File_Set{Fileindex,3} = 0;
    File_Set{Fileindex,4} = 0;
    File_Set{Fileindex,5} = 0;
    File_Set{Fileindex,6} = 0;
    File_Set{Fileindex,7} = "";
    File_Set{Fileindex,8} = 1;
    File_Set{Fileindex,9} = FILE_MODE_TYPE.READ_WRITE;
    File_Set{Fileindex,10} = ENTRY_KIND_TYPE.FILE_ENTRY;
    File_Set{Fileindex,11} = 0;
    File_Set{Fileindex,12} = ID;

    PARTION_OPEN_FILES_NUMBERS = PARTION_OPEN_FILES_NUMBERS + 1;
    PARTION_EXIT_FILES_NUMBERS = PARTION_EXIT_FILES_NUMBERS + 1;
    Open_File_Set(ID) = 1;
    File_System_Configuation_Table{1,3} = File_System_Configuation_Table{1,3} - MAX_ATOMIC_SIZE;
    File_System_Configuation_Table{1,8} = File_System_Configuation_Table{1,8} - 1;
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
    ERRNO = ERRNO_ERROR_TYPE.EUNCHANGE;

    return;
    
end
