function [ index ] = Invalid_Create_File_in_New_Directory(NEW_FILE_NAME)
    global Directory_Set;
    global DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS;
    global File_Set;
    
    
    % APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];
    path_prefix = get_file_prefix(NEW_FILE_NAME);
    
    % APEX_INTEGER DIR_ID,index;
    Directory_Name_Set = [Directory_Set{:,1}];
    [~,DIR_ID] = ismember(path_prefix,Directory_Name_Set);
    if File_Set{DIR_ID,11}<DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS
        index = 1;
    else
        index = 0;
    end

    return;
end