function [ ] = write_directory(DIR_ID,FILE_NAME,FILE_ID)
    global DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS;
    global Directory_Set;
    column = 3;
    while column <DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS+2
        content = Directory_Set{DIR_ID,column};
        content_length = strlength(content);
        if content_length <= 1
            Directory_Set{DIR_ID,column} = FILE_NAME;
            Directory_Set{DIR_ID,column + DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS} = FILE_ID;
            break;
        end
        column = column+1;
    end
    return;
end