function [ index ] = Invalid_Directory_Name_is_Root_Directory( DIRECTORY_NAME )
    global ROOT_DIRECTORY;
    if DIRECTORY_NAME == ROOT_DIRECTORY
        index = 0;
    else
        index = 1;
    end
    return;
end