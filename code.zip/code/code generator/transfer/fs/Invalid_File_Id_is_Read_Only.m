function [ index ] = Invalid_File_Id_is_Read_Only( FILE_ID)
    global File_Set;
    global FILE_MODE_TYPE;
    
    %APEX_INTEGER index;
    %APEX_INTEGER ID;
    ID = FILE_ID;
    if File_Set{ID,9} == FILE_MODE_TYPE.READ
        index = 0;
    else
        index = 1;
    end
    return;

end
