function [ index ] = Invalid_Directory_is_Open_by_Owning_Partion( DIRECTORY_NAME )
    % APEX_INTEGER index;
    index = 1;
    return;

end
