function [ path_prefix ] = get_file_prefix(FILE_NAME)
    path = split(FILE_NAME,"\");
    path_length = length(path);
    path_prefix = path{1};
    for k = 2:path_length-1
        path_prefix = strcat(path_prefix,"\");
        path_prefix = strcat(path_prefix,path{k});
    end
    return;
end