function  [index] = Invalid_Storage_Device_Contain_Directory_Id(DIRECTORY_ID)
    % APEX_INTEGER index;
    index = 1;
    
    return;
end