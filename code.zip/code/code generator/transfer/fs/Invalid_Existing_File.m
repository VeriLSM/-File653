function [ index ] = Invalid_Existing_File( FILE_NAME )
    global Directory_Set;
    global MAX_DIRECTORY_NUMBER;
    global DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS;
    global File_Set;
    global ENTRY_KIND_TYPE;

    % APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];
    % APEX_INTEGER DIR_ID,index,pos,ID;
    
    path_prefix = get_file_prefix(FILE_NAME);

    Directory_Name_Set = [File_Set{:,1}];
    [~,DIR_ID] = ismember(path_prefix,Directory_Name_Set);
    if DIR_ID == 0
        index = 0;
        return;
    end
    Sub_Directory_Set = [Directory_Set{DIR_ID,:}];
    [~,pos] = ismember(FILE_NAME,Sub_Directory_Set);
    if pos == 0
        index = 0;
        return;
    end
    [~,ID] = ismember(FILE_NAME,Directory_Name_Set);

    if File_Set{ID,10} ~= ENTRY_KIND_TYPE.FILE_ENTRY
        index = 0;
    else
        index = 1;
    end
    
    return;


end