function [index] = Invalid_Partion_Has_Write_Read_Rights(FILE_NAME)
    %APEX_INTEGER index;
    index = 1;

    return;
end