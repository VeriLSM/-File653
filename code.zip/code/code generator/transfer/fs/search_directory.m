function [  ] = transfer_from_message(FILE_ID,MESSAGE_ADDR,LENGTH)
    global File_Set;
    File_Set{FILE_ID,7} = MESSAGE_ADDR;
    return;
end
