function schedule()

    global Process_Set;
    global PROCESS_STATE_TYPE;
    global Ready_Processes_Set;
    global SYSTEM_NUMBER_OF_PROCESSES;
    global CurrentProcess;
    global PreviousProcess;
    
    readyprioritySet = [];
    for i = 1:numel(Ready_Processes_Set)
        pidindex = GetProcessIndex(Ready_Processes_Set(i));
        readyprioritySet = [readyprioritySet,Process_Set{pidindex,9}];
    end
    
    if ismember(0,readyprioritySet) == 1
        maxpriroty = 0;
    else
        maxpriroty = max(readyprioritySet);
    end
    
    index = 0;
    for i = 1:SYSTEM_NUMBER_OF_PROCESSES
        if Process_Set{i,9} == maxpriroty && Process_Set{i,11} == PROCESS_STATE_TYPE.READY
            index = i;
            break;
        end
    end
    pri_pid = Process_Set{index,1};
        
    curindex = GetProcessIndex(CurrentProcess);
    if Process_Set{curindex,9} <= Process_Set{index,9} && Process_Set{curindex,11} == PROCESS_STATE_TYPE.RUNNING
        Process_Set{curindex,11} = PROCESS_STATE_TYPE.READY;
        Ready_Processes_Set = union(Ready_Processes_Set,CurrentProcess);
        PreviousProcess = CurrentProcess;
        CurrentProcess = pri_pid;
        Process_Set{index,11} = PROCESS_STATE_TYPE.RUNNING;
        Ready_Processes_Set = setdiff(Ready_Processes_Set,pri_pid);
    else
        PreviousProcess = CurrentProcess;
        CurrentProcess = pri_pid;
        Process_Set{index,11} = PROCESS_STATE_TYPE.RUNNING;
        Ready_Processes_Set = setdiff(Ready_Processes_Set,pri_pid);        
    end
