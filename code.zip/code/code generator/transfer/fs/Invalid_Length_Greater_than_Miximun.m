function [ index ] = Invalid_Length_Greater_than_Miximun( LENGTH )
    global MAX_ATOMIC_SIZE;
    
    % APEX_INTEGER index;
    if LENGTH <= MAX_ATOMIC_SIZE
        index = 1;
    else
        index = 0;
    end
    
    return;

end