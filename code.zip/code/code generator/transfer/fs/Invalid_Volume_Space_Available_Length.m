function [ index ] = Invalid_Volume_Space_Available_Length( LENGTH )
    global File_System_Configuation_Table;
    global MAX_ATOMIC_SIZE;

    % APEX_INTEGER free_bytes,index;
    free_bytes = File_System_Configuation_Table{1,3};
    if free_bytes > MAX_ATOMIC_SIZE
        index = 1;
    else
        index = 0;
    end
    
    return;

end
