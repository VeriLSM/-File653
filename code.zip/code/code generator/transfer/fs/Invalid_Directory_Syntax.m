function [ index ] = Invalid_Existing_Directory( FILE_NAME )
    global Directory_Set;
    global MAX_DIRECTORY_NUMBER;
    global File_Set;
    global ENTRY_KIND_TYPE;



    % APEX_INTEGER DIR_ID,index;
    Directory_Name_Set = [Directory_Set{:,1}];
    [~,DIR_ID] = ismember(FILE_NAME,Directory_Name_Set);

    if DIR_ID == 0
        index = 1 ;
        return;
    end

    if File_Set{DIR_ID,10} ~= ENTRY_KIND_TYPE.DIRECTORY_ENTRY
        index = 1;
        return;
    end

    index = 0;
    return;
end
