function [ name ] = get_file_name(FILE_NAME)
    path = split(FILE_NAME,"\");
    path_length = length(path);
    name = path{path_length};
    return;
end