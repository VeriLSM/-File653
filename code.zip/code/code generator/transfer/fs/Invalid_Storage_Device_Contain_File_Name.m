function  [index] = Invalid_Storage_Device_Contain_File_Name(File_NAME)
    
    % APEX_INTEGER index;
    index = 1;
    
    return;
end