function [  ] = delete_file(FILE_ID,DIR_ID)
    global File_Set;

    File_Set{FILE_ID,1} = "";
    File_Set{FILE_ID,2} = -1;
    File_Set{FILE_ID,3} = -1;
    File_Set{FILE_ID,4} = -1;
    File_Set{FILE_ID,5} = -1;
    File_Set{FILE_ID,6} = -1;
    File_Set{FILE_ID,7} = "";
    File_Set{FILE_ID,8} = -1;
    File_Set{FILE_ID,9} = -1;
    File_Set{FILE_ID,10} = -1;
    File_Set{FILE_ID,11} = -1;
    
    return;
end