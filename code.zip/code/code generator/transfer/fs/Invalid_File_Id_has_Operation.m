function [ index ] = Invalid_File_Id_has_Operation( FILE_ID )
    %APEX_INTEGER index;
    index = 1;
    return;

end

