function [ index ] = Invalid_File_Name_is_Open(FILE_NAME)
    global File_Set;
    global Open_File_Set;
    % APEX_INTEGER ID,index,FILE_ID;
    Directory_Name_Set = [File_Set{:,1}];
    [~,ID] = ismember(FILE_NAME,Directory_Name_Set);
    FILE_ID = File_Set{ID,2};
    index = Open_File_Set(FILE_ID);
    return;
end
