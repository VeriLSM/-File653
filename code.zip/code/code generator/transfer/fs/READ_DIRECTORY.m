function  [ENTRY_NAME,ENTRY_KIND,RETURN_CODE,ERRNO] = READ_DIRECTORY(DIRECTORY_ID,ERRNO)
    global RETURN_CODE_TYPE;
    global ERRNO_ERROR_TYPE;
    global File_Set;
    global CurrentProcess;
    global Directory_Set;
    global ENTRY_KIND_TYPE;
    global CURRENT_PARTITION;
    global DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS;
    global ERROR_HANDLER_PROCESS_ID;
    
    %APEX_BYTE tmp[MAX_FILE_NAME_LENGTH];
    %APEX_INTEGER Directory_Id_In_Current_Partition_Flag;
    Directory_Id_In_Current_Partition_Flag = Invalid_Directory_Id_In_Current_Partition(DIRECTORY_ID);
    if Directory_Id_In_Current_Partition_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EBADF;
        ENTRY_NAME = "" ;
        ENTRY_KIND = ENTRY_KIND_TYPE.DIRECTORY_ENTRY;
        return;
    end
    
    %APEX_INTEGER Directory_Id_has_Operation_Flag;
    Directory_Id_has_Operation_Flag = Invalid_Directory_Id_has_Operation(DIRECTORY_ID);
    if Directory_Id_has_Operation_Flag == 0
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EBUSY;
        ENTRY_NAME = "" ;
        ENTRY_KIND = ENTRY_KIND_TYPE.DIRECTORY_ENTRY;
        return;
    end
    
    %APEX_INTEGER Directory_Id_Due_to_Owner_Action_Flag;
    Directory_Id_Due_to_Owner_Action_Flag = Invalid_Directory_Id_Due_to_Owner_Action(DIRECTORY_ID);
    if  Directory_Id_Due_to_Owner_Action_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.ESTALE;
        ENTRY_NAME = "" ;
        ENTRY_KIND = ENTRY_KIND_TYPE.DIRECTORY_ENTRY;
        return;
    end
    
    %APEX_INTEGER Storage_Device_Contain_Directory_Id_Flag;
    Storage_Device_Contain_Directory_Id_Flag = Invalid_Storage_Device_Contain_Directory_Id(DIRECTORY_ID);
    if  Storage_Device_Contain_Directory_Id_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EIO;
        ENTRY_NAME = "" ;
        ENTRY_KIND = ENTRY_KIND_TYPE.DIRECTORY_ENTRY;
        return;
    end
    
    if CURRENT_PARTITION.LOCK_LEVEL > 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        ENTRY_NAME = "" ;
        ENTRY_KIND = ENTRY_KIND_TYPE.DIRECTORY_ENTRY;
        return;
    end
    
    if CurrentProcess == ERROR_HANDLER_PROCESS_ID
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        ENTRY_NAME = "" ;
        ENTRY_KIND = ENTRY_KIND_TYPE.DIRECTORY_ENTRY;
        return;
    end
    
    % APEX_INTEGER position,ID;
    % APEX_BYTE DIR_NAME[MAX_FILE_NAME_LENGTH];
    position = File_Set{DIRECTORY_ID,3};
    if position < DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS
        if File_Set{ID,10} == ENTRY_KIND_TYPE.DIRECTORY_ENTRY
            ENTRY_NAME = DIR_NAME;
            ENTRY_KIND = ENTRY_KIND_TYPE.DIRECTORY_ENTRY;

        elseif File_Set{ID,10} == ENTRY_KIND_TYPE.FILE_ENTRY
            ENTRY_NAME = DIR_NAME;
            ENTRY_KIND = ENTRY_KIND_TYPE.FILE_ENTRY;

        end
        File_Set{DIRECTORY_ID,3} = position + 1;
    else
        ENTRY_NAME = "" ;
        ENTRY_KIND = ENTRY_KIND_TYPE.DIRECTORY_ENTRY;
    end

    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
    ERRNO = ERRNO_ERROR_TYPE.EUNCHANGE;
    return;
end
