function [ index ] = Invalid_Directory_Id_has_Operation( DIRECTORY_ID )
    %APEX_INTEGER index;
    index = 1;
    return;

end
