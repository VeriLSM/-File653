function [ index ] = Invalid_File_Id_Due_to_Owner_Action( FILE_ID )
    %APEX_INTEGER index;
    index = 1;

    return;

end
