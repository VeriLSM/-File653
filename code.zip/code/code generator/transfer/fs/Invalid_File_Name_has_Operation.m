function [ index ] = Invalid_File_Name_has_Operation( FILE_NAME )
    % APEX_INTEGER index;
    index = 1;
    return;

end