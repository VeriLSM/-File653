function [ index ] = Invalid_Directory_Id_In_Current_Partition( DIRECTORY_ID )
    global Open_File_Set;
    global SYSTEM_LIMIT_FILE_SIZE;
    
    %APEX_INTEGER index;
    if DIRECTORY_ID <= 0 || DIRECTORY_ID > SYSTEM_LIMIT_FILE_SIZE
        index = 0;
    else
        index = Open_File_Set(DIRECTORY_ID);
    end
    return;

end
