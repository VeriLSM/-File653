function  [index] = Invalid_Partition_Access_Rights(FILE_MODE,FILE_NAME)
    
    %APEX_INTEGER index;
    index = 1;

    return;
end