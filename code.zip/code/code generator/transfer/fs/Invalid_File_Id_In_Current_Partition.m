function [ index ] = Invalid_File_Id_In_Current_Partition( FILE_ID )
    global Open_File_Set;
    global SYSTEM_LIMIT_FILE_SIZE;
    
    %APEX_INTEGER index;
    if FILE_ID <= 0 || FILE_ID > SYSTEM_LIMIT_FILE_SIZE
        index = 0;
    else
        index = Open_File_Set(FILE_ID);
    end
    return;

end

