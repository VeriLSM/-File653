function [ index ] = Invalid_File_Id_has_Read_Write_Access_Mode( FILE_ID )
    global File_Set;
    global FILE_MODE_TYPE;
    %APEX_INTEGER index;
    %APEX_INTEGER ID;
    ID = FILE_ID;
    if File_Set{ID,8} == FILE_MODE_TYPE.READ_WRITE
        index = 1;
    else
        index = 0;
    end
    return;

end