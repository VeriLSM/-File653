function [ index ] = Invalid_Existing_Filename_Is_Read_Write( FILE_NAME )
    global File_Set;
    global Open_File_Set;
    global FILE_MODE_TYPE;
    
    %APEX_INTEGER ID,index,j;
    Directory_Name_Set = [File_Set{:,1}];
    [~,ID] = ismember(FILE_NAME,Directory_Name_Set);
   
    if ID == 0
        index = 0;
        return;
    end
    
    if File_Set{ID,9} == FILE_MODE_TYPE.READ
        index = 0;
        return;
    end
    
    [~,j] = ismember(ID,Open_File_Set);
    if j == 0
        index = 0;
        return;
    end
    
    index = 1;
    return;

end