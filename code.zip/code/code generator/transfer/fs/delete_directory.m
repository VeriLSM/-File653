function [  ] = delete_directory(DIRECTORY_ID,DIR_ID)
    global File_Set;
    global Directory_Set;
    Directory_Set{DIRECTORY_ID,1} = "";
    Directory_Set{DIRECTORY_ID,2} = -1;
    File_Set{DIRECTORY_ID,1} = "";
    File_Set{DIRECTORY_ID,2} = -1;
    File_Set{DIRECTORY_ID,3} = -1;
    File_Set{DIRECTORY_ID,4} = -1;
    File_Set{DIRECTORY_ID,5} = -1;
    File_Set{DIRECTORY_ID,6} = -1;
    File_Set{DIRECTORY_ID,7} = "";
    File_Set{DIRECTORY_ID,8} = -1;
    File_Set{DIRECTORY_ID,9} = -1;
    File_Set{DIRECTORY_ID,10} = -1;
    File_Set{DIRECTORY_ID,11} = -1;
    
    return;
end