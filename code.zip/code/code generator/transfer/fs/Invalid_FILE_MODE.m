function [ index ] = Invalid_FILE_MODE(FILE_MODE)
    global FILE_MODE_TYPE;
    %APEX_INTEGER index;
    if FILE_MODE == FILE_MODE_TYPE.READ || FILE_MODE == FILE_MODE_TYPE.READ_WRITE
        index = 1;
    else
        index = 0;
    end
    
    return;
end

