function  [OUT_LENGTH,RETURN_CODE,ERRNO] = READ_FILE(FILE_ID,MESSAGE_ADDR,IN_LENGTH,ERRNO)
    global RETURN_CODE_TYPE;
    global ERRNO_ERROR_TYPE;
    global MAX_ATOMIC_SIZE;
    global CurrentProcess;
    global ERROR_HANDLER_PROCESS_ID;
    global File_Set;
    global CURRENT_PARTITION;
    
    %APEX_INTEGER File_Id_In_Current_Partition_Flag;
    File_Id_In_Current_Partition_Flag = Invalid_File_Id_In_Current_Partition(FILE_ID);
    if File_Id_In_Current_Partition_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EBADF;
        OUT_LENGTH = -1;
        return;
    end
    
    %APEX_INTEGER File_Id_has_Operation_Flag;
    File_Id_has_Operation_Flag = Invalid_File_Id_has_Operation(FILE_ID);
    if File_Id_has_Operation_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EBUSY;
        OUT_LENGTH = -1;
        return;
    end
    
    %APEX_INTEGER File_Id_Due_to_Owner_Action_Flag;
    File_Id_Due_to_Owner_Action_Flag = Invalid_File_Id_Due_to_Owner_Action(FILE_ID);
    if  File_Id_Due_to_Owner_Action_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.ESTALE;
        OUT_LENGTH = -1;
        return;
    end
    
    if IN_LENGTH <= 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EINVAL;
        OUT_LENGTH = -1;
        return;
    end
    
    if IN_LENGTH > MAX_ATOMIC_SIZE 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EFBIG;
        OUT_LENGTH = -1;
        return;
    end
    
    %APEX_INTEGER Storage_Device_Contain_File_Id_Flag;
    Storage_Device_Contain_File_Id_Flag = Invalid_Storage_Device_Contain_File_Id(FILE_ID);
    if Storage_Device_Contain_File_Id_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EIO;
        OUT_LENGTH = -1;
        return;
    end
    
    %APEX_INTEGER File_Postion_Greater_than_File_Size_Flag;
    File_Postion_Greater_than_File_Size_Flag = Invalid_File_Postion_Greater_than_File_Size(FILE_ID);
    if File_Postion_Greater_than_File_Size_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EIO;
        OUT_LENGTH = -1;
        return;
    end
    
    if CURRENT_PARTITION.LOCK_LEVEL > 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        OUT_LENGTH = -1;
        return;
    end
    
    if CurrentProcess == ERROR_HANDLER_PROCESS_ID
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        OUT_LENGTH = -1;
        return;
    end
    
    %APEX_INTEGER ID,File_Position,File_Size;
    ID = FILE_ID;
    File_Position = File_Set{ID,3};
    File_Size = File_Set{ID,4};
    %APEX_INTEGER Position_Add_Length;
    Position_Add_Length = File_Position + IN_LENGTH;
    if Position_Add_Length > File_Size
        OUT_LENGTH = File_Size - File_Position;
    else
        OUT_LENGTH = IN_LENGTH;
    end
    MESSAGE_ADDR = transfer_to_message(FILE_ID,OUT_LENGTH);
    File_Set{ID,3} = File_Position + OUT_LENGTH;
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
    ERRNO = ERRNO_ERROR_TYPE.EUNCHANGE;
    return;
    
        
end
