function  [index] = Invalid_Storage_Device_Contain_File_Id(FILE_ID)
    % APEX_INTEGER index;
    index = 1;
    
    return;
end