function  [index] = Invalid_Partition_Read_Write_Access_Rights(File_NAME)
    
    %APEX_INTEGER index;
    index = 1;
    
    return;
end