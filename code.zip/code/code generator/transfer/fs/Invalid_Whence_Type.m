function [ index ] = Invalid_Whence_Type( WHENCE )
    global FILE_SEEK_TYPE;
    % APEX_INTEGER index;
    index = 0;
    if WHENCE == FILE_SEEK_TYPE.SEEK_SET_TYPE || WHENCE == FILE_SEEK_TYPE.SEEK_CUR_TYPE || WHENCE == FILE_SEEK_TYPE.SEEK_END_TYPE
        index = 1 ;
    end

    return;

end
