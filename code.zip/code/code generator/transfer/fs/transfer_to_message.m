function [ MESSAGE_ADDR ] = transfer_to_message(FILE_ID,OUT_LENGTH)
    global File_Set;
    MESSAGE_ADDR = File_Set{FILE_ID,7};
    MESSAGE_ADDR = extractBefore(MESSAGE_ADDR,OUT_LENGTH+1);
    return;
end