function  [RETURN_CODE,ERRNO] = REWIND_DIRECTORY(DIRECTORY_ID,ERRNO)
    global RETURN_CODE_TYPE;
    global ERRNO_ERROR_TYPE;
    global CURRENT_PARTITION;
    global File_Set;
    global CurrentProcess;
    global ERROR_HANDLER_PROCESS_ID;
    
    %APEX_INTEGER Directory_Id_In_Current_Partition_Flag;
    Directory_Id_In_Current_Partition_Flag = Invalid_Directory_Id_In_Current_Partition(DIRECTORY_ID);
    if Directory_Id_In_Current_Partition_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EBADF;
        return;
    end
    
    %APEX_INTEGER Directory_Id_has_Operation_Flag;
    Directory_Id_has_Operation_Flag = Invalid_Directory_Id_has_Operation(DIRECTORY_ID);
    if Directory_Id_has_Operation_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EBUSY;
        return;
    end
    
    %APEX_INTEGER Directory_Id_Due_to_Owner_Action_Flag;
    Directory_Id_Due_to_Owner_Action_Flag = Invalid_Directory_Id_Due_to_Owner_Action(DIRECTORY_ID);
    if Directory_Id_Due_to_Owner_Action_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.ESTALE;
        return;
    end
    
    %APEX_INTEGER Storage_Device_Contain_Directory_Id_Flag;
    Storage_Device_Contain_Directory_Id_Flag = Invalid_Storage_Device_Contain_Directory_Id(DIRECTORY_ID);
    if Storage_Device_Contain_Directory_Id_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EIO;
        return;
    end
    
    if CURRENT_PARTITION.LOCK_LEVEL > 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    if CurrentProcess == ERROR_HANDLER_PROCESS_ID
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    % APEX_INTEGER DIR_ID;
    DIR_ID = DIRECTORY_ID;
    File_Set{DIR_ID,3} = 0;
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
    ERRNO = ERRNO_ERROR_TYPE.EUNCHANGE;
    
end
