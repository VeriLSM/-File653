function  [index] = Invalid_File_Postion_Greater_than_File_Size(FILE_ID)
    global File_Set;
    % APEX_INTEGER ID,File_Position;
    % APEX_INTEGER File_Size,index;
    ID = FILE_ID;
    File_Position = File_Set{ID,3};
    File_Size = File_Set{ID,4};
    if File_Position> File_Size
        index = 0;
        return;
    end
    
    index = 1;
    return;
end