function [ index ] = Invalid_Offset_value( OFFSET,File_Size)
    % APEX_INTEGER index;
    if OFFSET >= 0 && OFFSET < File_Size
        index = 1;
        return;
    end

    index = 0;
    return;

end
