function  [index] = Invalid_Storage_Device_Contain_Directory(DIRECTORY_NAME)
    % APEX_INTEGER index;
    index = 1;
    
    return;
end