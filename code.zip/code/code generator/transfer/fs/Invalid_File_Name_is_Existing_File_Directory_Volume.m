function [ index ] = Invalid_File_Name_is_Existing_File_Directory_Volume( FILE_NAME )
    global Directory_Set;
    global File_Set;
    
    % APEX_BYTE volume_name[MAX_FILE_NAME_LENGTH];
    % APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];
    % APEX_INTEGER VOL_ID,DIR_ID,index,ID;
    volume_name = get_volume_name(FILE_NAME);
    path_prefix = get_file_prefix(FILE_NAME);

    Directory_Name_Set = [File_Set{:,1}];

    [~,VOL_ID] = ismember(volume_name,Directory_Name_Set);
    index = VOL_ID;
    if index == 0
        return;
    end
    
    [~,DIR_ID] = ismember(path_prefix,Directory_Name_Set);
    index = DIR_ID;
    if index == 0
        return;
    end
    [~,ID] = ismember(FILE_NAME,Directory_Name_Set);
    index = ID;
    return;

end