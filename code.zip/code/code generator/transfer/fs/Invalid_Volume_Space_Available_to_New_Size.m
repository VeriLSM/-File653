function [ index ] = Invalid_Volume_Space_Available_to_New_Size( FILE_ID,NEW_SIZE )
    global File_System_Configuation_Table;
    %APEX_INTEGER index;
    
    if File_System_Configuation_Table{1,3}>NEW_SIZE
        index = 1;
    else
        index = 0;
    end
    
    return;

end