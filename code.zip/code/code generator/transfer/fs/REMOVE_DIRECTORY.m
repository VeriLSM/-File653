function  [RETURN_CODE,ERRNO] = REMOVE_DIRECTORY(DIRECTORY_NAME,ERRNO)
    global RETURN_CODE_TYPE;
    global ERRNO_ERROR_TYPE;
    global CurrentProcess;
    global ERROR_HANDLER_PROCESS_ID;
    global Directory_Set;
    global File_Set;
    global PARTION_EXIT_FILES_NUMBERS;
    global CURRENT_PARTITION;
    global File_System_Configuation_Table;
    global MAX_ATOMIC_SIZE;

    %APEX_INTEGER Directory_length_Flag;
    Directory_length_Flag = Invalid_Directory_Length(DIRECTORY_NAME);
    if Directory_length_Flag == 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.ENAMETOOLONG;
        return;
    end
    
    %APEX_INTEGER Directory_Synta_Flag;
    Directory_Synta_Flag = Invalid_Directory_Syntax(DIRECTORY_NAME);
    if Directory_Synta_Flag == 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EINVAL;
        return;
    end
    
    %APEX_INTEGER File_Path_Prefix_Flag;
    File_Path_Prefix_Flag = Invalid_File_Path_Prefix(DIRECTORY_NAME);
    if File_Path_Prefix_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.ENOTDIR;
        return;
    end
    
    %APEX_INTEGER Existing_File_Flag;
    Existing_File_Flag = Invalid_Existing_File(DIRECTORY_NAME);
    if  Existing_File_Flag ~= 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EEXIST;
        return;
    end
    
    %APEX_INTEGER Existing_Directory_Flag;
    Existing_Directory_Flag = Invalid_Existing_Directory(DIRECTORY_NAME);
    if Existing_Directory_Flag == 1 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EISDIR;
        return;
    end
    
    %APEX_INTEGER Partition_Read_Write_Access_Rights_Flag;
    Partition_Read_Write_Access_Rights_Flag = Invalid_Partition_Read_Write_Access_Rights(DIRECTORY_NAME);
    if Partition_Read_Write_Access_Rights_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    %APEX_INTEGER Directory_Name_is_Root_Directory_Flag;
    Directory_Name_is_Root_Directory_Flag = Invalid_Directory_Name_is_Root_Directory(DIRECTORY_NAME);
    if  Directory_Name_is_Root_Directory_Flag == 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    %APEX_INTEGER Directory_Name_is_not_Empty_Flag;
    Directory_Name_is_not_Empty_Flag = Invalid_Directory_Name_is_not_Empty(DIRECTORY_NAME);
    if Directory_Name_is_not_Empty_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        ERRNO = ERRNO_ERROR_TYPE.ENOTEMPTY;
        return;
    end
    
    %APEX_INTEGER Directory_is_Open_by_Owning_Partion_Flag;
    Directory_is_Open_by_Owning_Partion_Flag = Invalid_Directory_is_Open_by_Owning_Partion(DIRECTORY_NAME);
    if Directory_is_Open_by_Owning_Partion_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EBUSY;
        return;
    end
    
    %APEX_INTEGER Storage_Device_Contain_Directory_Name_Flag;
    Storage_Device_Contain_Directory_Name_Flag = Invalid_Storage_Device_Contain_Directory_Name(DIRECTORY_NAME);
    if Storage_Device_Contain_Directory_Name_Flag == 0 
        RETURN_CODE = RETURN_CODE_TYPE.NOT_AVAILABLE;
        ERRNO = ERRNO_ERROR_TYPE.EIO;
        return;
    end
  
    if CURRENT_PARTITION.LOCK_LEVEL > 0
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    if CurrentProcess == ERROR_HANDLER_PROCESS_ID
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_MODE;
        ERRNO = ERRNO_ERROR_TYPE.EACCES;
        return;
    end
    
    % APEX_BYTE path_prefix[MAX_FILE_NAME_LENGTH];
    path_prefix = get_file_prefix(DIRECTORY_NAME);

    % APEX_INTEGER DIR_ID,DIRECTORY_ID;
    Directory_Name_Set = [Directory_Set{:,1}];
    [~,DIR_ID] = ismember(path_prefix,Directory_Name_Set);
    DIRECTORY_ID = search_directory(DIR_ID,DIRECTORY_NAME);
    delete_directory(DIRECTORY_ID,DIR_ID);

    File_Set{DIR_ID,11} = File_Set{DIR_ID,11} - 1;

    PARTION_EXIT_FILES_NUMBERS = PARTION_EXIT_FILES_NUMBERS - 1;
    File_System_Configuation_Table{1,4} = File_System_Configuation_Table{1,4} - MAX_ATOMIC_SIZE;
    File_System_Configuation_Table{1,8} = File_System_Configuation_Table{1,8} - 1;
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
    ERRNO = ERRNO_ERROR_TYPE.EUNCHANGE;
    return;
        
end
