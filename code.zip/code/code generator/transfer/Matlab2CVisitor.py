#!/usr/bin/env python
# -*- coding: utf-8 -*-

# @Time    : 2018/6/2 21:41
# @Author  : ethanw
# @Mail    ：ethan_w@aliyun.com
# @Describe: 使用antlr4的Visitor方式访问文法结点，根据具体的文法结点，将M*代码转换为对应的MISRA-C序列,同时生成层级编码

from antlr4 import *
if __name__ is not None and "." in __name__:
    from .MatlabParser import MatlabParser
    from .MachineC import MachineC
    from .MatlabVisitor import MatlabVisitor
    from .Hierarchy import Hierarchy
else:
    from MatlabParser import MatlabParser
    from MatlabVisitor import MatlabVisitor
    from MachineC import MachineC
    from Hierarchy import Hierarchy


class Matlab2CVisitor(MatlabVisitor):
    def __init__(self):
        '''
        初始化
        '''
        self.name = set()  # key:返回值,value:类型
        self.functionFlag = False  # 函数标识，用于判断是否为静态static函数,false为静态函数
        # self.return_name = '' # 如果是静态函数,保存要返回的变量名,通常是index
        self.function_name = '' # 用于记录当前转换的M*函数name
        self.static_return = ''  # 用于记录static函数的返回值，在returnS文法中
        self.ChierMark = '\t\t// '  # C层级编码的记号//
        self.MhierMark = '\t\t%% '  # M*层级编码的记号%%
        self.level = []  # 用于记录当前的层级编码
        self.flag = 'c'  # 转换标识,[hier_m,hier_c,c]
        self.hierCode = Hierarchy()
        self.machineC = MachineC()
        self.file_system_services = ['OPEN_NEW_FILE', 'OPEN_FILE', 'CLOSE_FILE', 'READ_FILE', 'WRITE_FILE', 'SEEK_FILE',
                              'REMOVE_FILE','RENAME_FILE','GET_FILE_STATUS','GET_VOLUME_STATUS','RESIZE_FILE',
                              'SYNC_FILE','OPEN_DIRECTORY','CLOSE_DIRECTORY','READ_DIRECTORY','REWIND_DIRECTORY',
                              'MAKE_DIRECTORY','REMOVE_DIRECTORY']
        self.log_system_services = ['CREATE_LOGBOOK','WRITE_LOGBOOK','OVERWRITE_LOGBOOK','READ_LOGBOOK','CLEAR_LOGBOOK',
                                    'GET_LOGBOOK_ID','GET_LOGBOOK_STATUS']
        # self.ignore_function = ['get_file_name','get_file_prefix','FileSystemInit','schedule']
        self.ignore_function = ['Invalid_File_Syntax','Invalid_Directory_Syntax','get_volume_name','write_directory',
                                 'search_directory','delete_file','delete_directory','Invalid_OLD_New_File_Name_Volume_Identical',
                                 'Invalid_Directory_Name_is_Root_Directory','Invalid_Existing_File','Invalid_Volume_Space_Available',
                                 'Invalid_Volume_Space_Available_Length','transfer_from_message','transfer_to_message',
                                 'search_directory','init_set','write_in_progress','overwrite_in_progress']
        self.path = []
        self.map_path = './map.txt' # 对应关系
        self.map = dict()
        self.print_flag = True # 是否打印中间状态,生成单个文件的时候选择True，多个文件生成的时候False
        self.pointers = set()

    def get_level(self):
        '''
        获取当前层级编码
        :return:
        '''
        level = [str(i) for i in self.level]
        res = '.'.join(level)
        if self.print_flag:
            print(res)
        return res

    def add_level(self):
        '''
        当前栈顶层级值+1
        :return:
        '''
        if len(self.level)>1:
            self.level[-1] += 1

    def clear_level(self):
        '''
        层级编码清空
        :return:
        '''
        self.level = []

    def clear_pointers(self):
        self.pointers = set()

    def get_func(self,name):
        path = './unuse/func/' + name + '.c'
        with open(path,'r') as f:
            res = str(f.read())
        return res


    def visitFunction(self, ctx:MatlabParser.FunctionContext):
        '''
        Function语法单元访问
        :param ctx: 上下文
        :return:
        '''
        # 这些函数无法对应生成
        if self.function_name in self.ignore_function and self.flag == 'c':
            res = self.get_func(self.function_name)
            self.machineC.add_static_function_string(res + '\n')
        else:
            self.path.append('Function')
            if self.print_flag:
                print('->'.join(self.path))
                print('visitFunction')
            self.level.append(1)
            if ctx.function_declare():
                self.visitFunction_declare(ctx.function_declare())

            if ctx.statement():
                self.level.append(0);
                self.visitStatement(ctx.statement())

            if self.flag == 'hier_c':
                abbreviation = '\tC-RET'
                end = '}\n'
                if self.functionFlag:
                    self.hierCode.add_function_string(end)
                else:
                    # return_paras = '\t' + 'return ' + self.return_name + ';' + self.ChierMark + self.get_level() + abbreviation
                    # self.hierCode.add_static_function_string(return_paras)
                    self.hierCode.add_static_function_string(end)

            elif self.flag == 'hier_m':
                end = ctx.END().getText()
                self.hierCode.add_m_hier_code('\n' + end + '\n')

            else:
                abbreviation = '\tC-RET'
                end = '}\n'
                if self.functionFlag:
                    self.machineC.add_function_string(end)
                else:
                    # return_paras = '\t' + 'return ' + self.return_name + ';'
                    # self.machineC.add_static_function_string(return_paras)
                    self.machineC.add_static_function_string(end)
            self.path.pop()
            self.level.pop()


    def visitFunction_declare(self, ctx:MatlabParser.Function_declareContext):
        '''
        Function_declare语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Function_declare')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitFunction_declare')
        abbreviation = ''
        function_name = ''
        retpara = ''
        paralist = ''
        function_declare = ''
        if ctx.name():
            function_name = self.visitName(ctx.name())

        if ctx.paralist():
            paralist = self.visitParalist(ctx.paralist())
            
        if ctx.returnparas():
            retpara = self.visitReturnparas(ctx.returnparas())
            
        # 根据所转换的M*函数判断名为系统服务函数或者static函数
        if function_name in self.file_system_services or function_name in self.log_system_services:
            self.functionFlag = True
            function_declare = 'void ' + function_name + '(' + paralist + ', '  + retpara + ') {'
            if paralist == '':
                function_declare = 'void ' + function_name + '('  + retpara + ') {'
            elif retpara == '':
                function_declare = 'void ' + function_name + '('  + paralist + ') {'

        else:
            self.functionFlag = False
            self.static_return = retpara

            # 返回类型的特殊定制
            if function_name == 'GetTick':
                rettype = 'static SYSTEM_TIME_TYPE '
            else:
                rettype = 'static APEX_INTEGER '
            if paralist == '':
                function_declare = rettype + function_name + '(void) {'
            else:
                if retpara != '':
                    function_declare = rettype + function_name + '(' + paralist + ') {'
                else:
                    function_declare = 'void ' + function_name + '(' + paralist + ') {'

        # 根据codFlag标识判断进行何种转换，MISRA-C、C层级编码或是M*层级编码
        if self.flag == 'hier_c':
            abbreviation = ' C-FUCD'
            function_declare = function_declare + self.ChierMark + self.get_level() + abbreviation
            if self.functionFlag:
                self.hierCode.add_function_string(function_declare)
            else:
                self.hierCode.add_static_function_string(function_declare)

        elif self.flag == 'c':
            if self.functionFlag:
                self.machineC.add_function_string(function_declare)
            else:
                self.machineC.add_static_function_string(function_declare)

        else:
            abbreviation = ' M*-FUCD'
            function_declare = 'function ' + ctx.getText().replace('=',' = ') + self.MhierMark + self.get_level() + abbreviation
            self.hierCode.add_m_hier_code(function_declare + '\n')

        self.path.pop()
        return function_declare


    def visitReturnparas(self, ctx:MatlabParser.ReturnparasContext):
        '''
        Returnparas语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Returnparas')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitReturnparas')
        retpara = ''
        if self.flag == 'hier_m':
            if len(ctx.return_name()) > 0:
                retpara = ctx.getText()
        else:
            if len(ctx.return_name()) == 0:
                pass
            elif len(ctx.return_name()) == 1:
                retpara = self.visitReturn_name(ctx.return_name()[0])
                # if not self.functionFlag:
                #     self.return_name = retpara
            else: # 返回参数在两个以上
                if self.visitReturn_name(ctx.return_name()[0]) == '':
                    retpara = self.visitReturn_name(ctx.return_name()[1])
                else:
                    retpara = self.visitReturn_name(ctx.return_name()[0])
                    for name in ctx.return_name()[1:]:
                        if self.visitReturn_name(name) != '':
                            retpara = retpara + ', ' + self.visitReturn_name(name)

        self.path.pop()
        return retpara


    def visitParalist(self, ctx:MatlabParser.ParalistContext):
        '''
        Paralist语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Paralist')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitParalist')
        if self.flag == 'hier_m':
            if len(ctx.expr()) > 0:
                paralistSum = ctx.getText()
            else:
                paralistSum = ''
        else:
            if len(ctx.expr()) >= 1:
                paralistSum = ''
                if len(self.path) >= 3 and self.path[len(self.path)-3] == 'Function':
                    for i in range(len(ctx.expr())):
                        paralist = self.visit(ctx.expr()[i])
                        if paralist == 'ERRNO': # 因为一般输入参数有个ERRNO输出也有一个
                            paralist = ''
                        elif paralist == 'FILE_NAME':
                            paralist = 'FILE_NAME_TYPE FILE_NAME'

                        elif paralist == 'FILE_MODE':
                            paralist = 'FILE_MODE_TYPE FILE_MODE'

                        elif paralist == 'FILE_ID':
                            paralist = 'FILE_ID_TYPE FILE_ID'

                        elif paralist == 'MESSAGE_ADDR':
                            paralist = 'MESSAGE_ADDR_TYPE MESSAGE_ADDR'

                        elif paralist == 'IN_LENGTH':
                            paralist = 'MESSAGE_SIZE_TYPE IN_LENGTH'

                        elif paralist == 'LENGTH':
                            paralist = 'MESSAGE_SIZE_TYPE LENGTH'

                        elif paralist == 'MESSAGE_ADDRE':
                            paralist = 'MESSAGE_ADDR_TYPE MESSAGE_ADDRE'

                        elif paralist == 'OFFSET':
                            paralist = 'FILE_SIZE_TYPE OFFSET'

                        elif paralist == 'WHENCE':
                            paralist = 'FILE_SEEK_TYPE WHENCE'

                        elif paralist == 'NEW_SIZE':
                            paralist = 'FILE_SIZE_TYPE NEW_SIZE'

                        elif paralist == 'OLD_FILE_NAME':
                            paralist = 'FILE_NAME_TYPE OLD_FILE_NAME'

                        elif paralist == 'NEW_FILE_NAME':
                            paralist = 'FILE_NAME_TYPE NEW_FILE_NAME'

                        elif paralist == 'DIRECTORY_NAME':
                            paralist = 'FILE_NAME_TYPE DIRECTORY_NAME'

                        elif paralist == 'DIRECTORY_ID':
                            paralist = 'DIRECTORY_ID_TYPE DIRECTORY_ID'

                        elif paralist == 'DIRECTORY_NAME':
                            paralist = 'FILE_NAME_TYPE DIRECTORY_NAME'

                        elif paralist == 'File_Size':
                            paralist = 'FILE_SIZE_TYPE File_Size'

                        elif paralist == 'File_NAME':
                            paralist = 'FILE_NAME_TYPE File_NAME'

                        elif paralist == 'POSITION':
                            if self.function_name == 'SEEK_FILE':
                                paralist = ''
                            else:
                                paralist = 'FILE_SIZE_TYPE *POSITION'
                                self.pointers.add('POSITION')
                        elif paralist == 'LOGBOOK_NAME':
                            paralist = 'LOGBOOK_NAME_TYPE LOGBOOK_NAME'

                        elif paralist == 'MAX_MESSAGE_SIZE':
                            paralist = 'MESSAGE_SIZE_TYPE MAX_MESSAGE_SIZE'

                        elif paralist == 'MAX_NB_LOGGED_MESSAGES':
                            paralist = 'MESSAGE_RANGE_TYPE MAX_NB_LOGGED_MESSAGES'

                        elif paralist == 'MAX_NB_IN_PROGRESS_MESSAGES':
                            paralist = 'MESSAGE_RANGE_TYPE MAX_NB_IN_PROGRESS_MESSAGES'

                        elif paralist == 'LOGBOOK_ENTRY':
                            paralist = 'MESSAGE_RANGE_TYPE LOGBOOK_ENTRY'

                        elif paralist == 'LOGBOOK_ID':
                            paralist = 'LOGBOOK_ID_TYPE LOGBOOK_ID'

                        if paralist != '':
                            if i != 0:
                                paralistSum = paralistSum + ', ' + paralist
                            else:
                                paralistSum =  paralist
                else:
                    for i in range(len(ctx.expr())):
                        paralist = self.visit(ctx.expr()[i])
                        if paralist != '':
                            if paralist == 'OUT_LENGTH' and len(self.path)>=4 and self.path[-4] == 'Assign_state':
                                paralist = '*OUT_LENGTH'
                            if i != 0:
                                paralistSum = paralistSum + ', ' + paralist
                            else:
                                paralistSum =  paralist

            else:
                paralistSum = ''

        self.path.pop()
        return paralistSum


    def visitReturn_name(self, ctx:MatlabParser.Return_nameContext):
        '''
        Return_name语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Return_name')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitReturn_name')
        return_name = ''
        if not ctx.NOT():
            name = ctx.NAME().getText()

            if len(self.path) >=4 and self.path[len(self.path)-4] == 'Function':
                if name == 'RETURN_CODE':
                    return_name = 'RETURN_CODE_TYPE *RETURN_CODE'
                    self.pointers.add('RETURN_CODE')

                elif name == 'ERRNO':
                    return_name = 'FILE_ERRNO_TYPE *ERRNO'
                    self.pointers.add('ERRNO')

                elif name == 'FILE_ID':
                    return_name = 'FILE_ID_TYPE *FILE_ID'
                    self.pointers.add('FILE_ID')

                elif name == 'OUT_LENGTH':
                    return_name = 'MESSAGE_SIZE_TYPE *OUT_LENGTH'
                    self.pointers.add('OUT_LENGTH')

                elif name == 'FILE_STATUS':
                    return_name = 'FILE_STATUS_TYPE *FILE_STATUS'
                    self.pointers.add('FILE_STATUS')

                elif name == 'VOLUME_STATUS':
                    return_name = 'VOLUME_STATUS_TYPE *VOLUME_STATUS'
                    self.pointers.add('VOLUME_STATUS')

                elif name == 'DIRECTORY_ID':
                    return_name = 'DIRECTORY_ID_TYPE *DIRECTORY_ID'
                    self.pointers.add('DIRECTORY_ID')

                elif name == 'ENTRY_KIND':
                    return_name = 'ENTRY_KIND_TYPE *ENTRY_KIND'
                    self.pointers.add('ENTRY_KIND')

                elif name == 'ENTRY_NAME':
                    return_name = 'DIRECTORY_ENTRY_TYPE *ENTRY_NAME'
                    self.pointers.add('ENTRY_NAME')

                elif name == 'POSITION':
                    return_name = 'FILE_SIZE_TYPE *POSITION'
                    self.pointers.add('POSITION')

                elif name == 'LOGBOOK_ID':
                    return_name = 'LOGBOOK_ID_TYPE *LOGBOOK_ID'
                    self.pointers.add('LOGBOOK_ID')

                # 有一些特殊
                elif name == 'LOGBOOK_STATUS':
                    return_name = 'LOGBOOK_STATUS_TYPE *LOGBOOK_STATUS'

                elif name == 'LENGTH':
                    return_name = 'MESSAGE_SIZE_TYPE *LENGTH'
                    self.pointers.add('LENGTH')

                elif name == 'WRITE_STATUS':
                    return_name = 'WRITE_STATUS_TYPE *WRITE_STATUS'
                    self.pointers.add('WRITE_STATUS')

                else:
                    return_name = name
            else:
                return_name = name

        self.path.pop()
        return return_name


    def visitName(self, ctx:MatlabParser.NameContext):
        '''
        Name语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Name')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitName')
        if self.flag == 'hier_m':
            name = ctx.NAME().getText()
        else:
            name = ctx.NAME().getText()
            if name == 'memcpy1' or name == 'memcpy2':
                name = 'memcpy'
        self.path.pop()
        return name

    def visitDigit(self, ctx:MatlabParser.DigitContext):
        '''
        Digit语法单元访问
        :param ctx: 上下文
        :return:
        '''
        if self.print_flag:
            print('visitDigit')
        digit = ctx.DIGIT().getText()
        return digit


    def visitMultiExpr(self, ctx:MatlabParser.MultiExprContext):
        '''
        MultiExpr语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('MultiExpr')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitMultiExpr')
        multiExpr = self.visit(ctx.expr()[0]) + self.visitMultiExpr(ctx.multiplicative_operation()) \
                    + self.visit(ctx.expr()[1])
        self.path.pop()
        return multiExpr


    def visitParensExpr(self, ctx:MatlabParser.ParensExprContext):
        '''
        ParensExpr语法单元访问
        :param ctx: 上下文
        :return:
        '''
        if self.print_flag:
            print('visitParensExpr')
        return '(' + self.visit(ctx.expr()) + ')'


    def visitDigitExpr(self, ctx:MatlabParser.DigitExprContext):
        '''
        DigitExpr语法单元访问
        :param ctx: 上下文
        :return:
        '''
        if self.print_flag:
            print('visitDigitExpr')
        return self.visitDigit(ctx.digit())


    def visitUnary_operaExpr(self, ctx:MatlabParser.Unary_operaExprContext):
        '''
        Unary_operaExpr语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Unary_operaExpr')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitUnary_operaExpr')
        unaryExpr = self.visitUnary_operation(ctx.unary_operation()) + self.visit(ctx.expr())
        self.path.pop()
        return unaryExpr


    def visitFuncallExpr(self, ctx:MatlabParser.FuncallExprContext):
        '''
        FuncallExpr语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('FuncallExpr')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitFuncallExpr')
        ret = self.visitFunction_call(ctx.function_call())
        self.path.pop()
        return ret


    def visitAddExpr(self, ctx:MatlabParser.AddExprContext):
        '''
        AddExpr语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('AddExpr')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitAddExpr')
        expr0 = self.visit(ctx.expr()[0])
        expr1 = self.visit(ctx.expr()[1])
        op = self.visitAdditive_operation(ctx.additive_operation())
        addExpr = expr0 + op + expr1
        if expr1 == 'MAX_ATOMIC_SIZE': # 对应的superblock没用MAX_ATOMIC_SIZE这一项
            addExpr = expr0 + op + '1'
        self.path.pop()
        return addExpr


    def visitElemExpr(self, ctx:MatlabParser.ElemExprContext):
        '''
        ElemExpr语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('ElemExpr')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitElemExpr')
        elemExpr = self.visitElement(ctx.element())
        self.path.pop()
        return elemExpr


    def visitLogicExpr(self, ctx:MatlabParser.LogicExprContext):
        '''
        LogicExpr语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('LogicExpr')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitLogicExpr')
        logicExpr = self.visit(ctx.expr()[0]) + self.visitLogical_operation(ctx.logical_operation()) \
                    + self.visit(ctx.expr()[1])
        self.path.pop()
        return logicExpr


    def visitRelatExpr(self, ctx:MatlabParser.RelatExprContext):
        '''
        RelatExpr语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('RelatExpr')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitRelatExpr')
        relatExpr = self.visit(ctx.expr()[0]) + self.visitRelational_operation(ctx.relational_operation()) \
                    + self.visit(ctx.expr()[1])
        self.path.pop()
        return relatExpr

    # name需根据具体的变量，按照ARINC653规范，在转换时对其变量类型进行转换确定
    # 未完成
    def visitNameExpr(self, ctx:MatlabParser.NameExprContext):
        '''
        NameExpr语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('NameExpr')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitNameExpr')
        if self.flag == 'hier_m':
            nameExpr = ctx.getText()
        else:
            nameExpr = ''
            if len(ctx.name()) > 1:
                # 可能要改
                name0 = ctx.name()[0].getText()
                name1 = ctx.name()[1].getText()
                if name0 in ['ERRNO_ERROR_TYPE','RETURN_CODE_TYPE','ERROR_CODE_TYPE','FILE_MODE_TYPE',
                             'ENTRY_KIND_TYPE','FILE_SEEK_TYPE','WRITE_STATUS_TYPE']:
                    nameExpr = name1 # c中只保留后缀就行
                elif name0 == 'CURRENT_PARTITION' and name1 == 'LOCK_LEVEL':
                    nameExpr = name1
                elif name0 == 'FILE_STATUS':
                    nameExpr = name0 + '->' + name1
                elif name0 == 'VOLUME_STATUS':
                    nameExpr = name0 + '->' + name1
                elif name0 == 'LOGBOOK_STATUS':
                    nameExpr = name0 + '->' + name1
                else:
                    nameExpr = name0 + '.' + name1

            else:
                name0 = ctx.name()[0].getText()
                nameExpr = name0
                if len(self.path) >=3 and self.path[len(self.path)-3] == 'Function_declare':
                    if name0 == 'FILE_NAME':
                        nameExpr = 'FILE_NAME_TYPE FILE_NAME'
                elif len(self.path)>3 and self.path[-3] == 'Assign_state' and self.function_name == 'READ_FILE' and name0 == 'OUT_LENGTH':
                    nameExpr = '*OUT_LENGTH'
                elif (len(self.path) >=4 and (self.path[-4] == 'If_state' or self.path[-4] == 'Else_state' or self.path[-4] == 'Elseif_state')) or (len(self.path)>=5 and self.path[-5] == 'Function'):
                    if name0 == 'FILE_ID' and name0 in self.pointers: # 说明在函数声明中出现过指针
                        nameExpr = '*FILE_ID'
                    elif name0 == 'RETURN_CODE' and name0 in self.pointers:
                        nameExpr = '*RETURN_CODE'
                    elif name0 == 'ERRNO' and name0 in self.pointers:
                        nameExpr = '*ERRNO'
                    elif name0 == 'OUT_LENGTH' and name0 in self.pointers:
                        nameExpr = '*OUT_LENGTH'
                    elif name0 == 'POSITION' and name0 in self.pointers:
                        nameExpr = '*POSITION'
                    elif name0 == 'VOLUME_STATUS' and name0 in self.pointers:
                        nameExpr = '*VOLUME_STATUS'
                    elif name0 == 'DIRECTORY_ID' and name0 in self.pointers:
                        nameExpr = '*DIRECTORY_ID'
                    elif name0 == 'ENTRY_NAME' and name0 in self.pointers:
                        nameExpr = '*ENTRY_NAME'
                    elif name0 == 'ENTRY_KIND' and name0 in self.pointers:
                        nameExpr = '*ENTRY_KIND'
                    elif name0 == 'LOGBOOK_ID' and name0 in self.pointers:
                        nameExpr = '*LOGBOOK_ID'
                    elif name0 == 'LENGTH' and name0 in self.pointers:
                        nameExpr = '*LENGTH'
                    elif name0 == 'WRITE_STATUS' and name0 in self.pointers:
                        nameExpr = '*WRITE_STATUS'
        self.path.pop()
        return nameExpr


    def visitAndorExpr(self, ctx:MatlabParser.AndorExprContext):
        '''
        AndorExpr语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('AndorExpr')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitAndorExpr')
        andorExpr = self.visit(ctx.expr()[0]) + self.visitAndor_operation(ctx.andor_operation())+self.visit(ctx.expr()[1])
        self.path.pop()
        return andorExpr


    def visitUnary_operation(self, ctx:MatlabParser.Unary_operationContext):
        '''
        Unary_operation语法单元访问
        :param ctx: 上下文
        :return:
        '''
        if self.print_flag:
            print('visitUnary_operation')
        return ctx.getText()


    def visitMultiplicative_operation(self, ctx:MatlabParser.Multiplicative_operationContext):
        '''
        Multiplicative_operation语法单元访问
        :param ctx: 上下文
        :return:
        '''
        if self.print_flag:
            print('visitMultiplicative_operation')
        return ' ' + ctx.getText() + ' '


    def visitAdditive_operation(self, ctx:MatlabParser.Additive_operationContext):
        '''
        Additive_operation语法单元访问
        :param ctx: 上下文
        :return:
        '''
        if self.print_flag:
            print('visitAdditive_operation')
        return ' ' + ctx.getText() + ' '


    def visitRelational_operation(self, ctx:MatlabParser.Relational_operationContext):
        '''
        Relational_operation语法单元访问
        :param ctx: 上下文
        :return:
        '''
        if self.print_flag:
            print('visitRelational_operation')
        if self.flag == 'hier_m':
            return ' ' + ctx.getText() + ' '
        else:
            return ' ' + ctx.getText().replace('~','!') + ' '

    def visitAndor_operation(self, ctx:MatlabParser.Andor_operationContext):
        '''
        Andor_operation语法单元访问
        :param ctx: 上下文
        :return:
        '''
        if self.print_flag:
            print('visitAndor_operation')
        return ' ' + ctx.getText() + ' '

    def visitLogical_operation(self, ctx:MatlabParser.Logical_operationContext):
        '''
        Logical_operation语法单元访问
        :param ctx: 上下文
        :return:
        '''
        if self.print_flag:
            print('visitLogical_operation')
        return ' ' + ctx.getText() + ' '

    def visitElement(self, ctx:MatlabParser.ElementContext):
        '''
        Element语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Element')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitElement')
        element = ''
        if self.flag == 'hier_m':
            element = ctx.getText()
        else:
            element_name = self.visitName(ctx.name())
            elemloc_idx1 = self.visitLocation_name(ctx.location().location_name(0)) #可能有问题
            elemloc_idx2 = self.visitLocation_name(ctx.location().location_name(1))
            elemloc = ''
            if element_name == 'Process_Set':
                if elemloc_idx2 == '1':
                    elemloc = 'ID'
                elif elemloc_idx2 == '2':
                    elemloc = 'NAME'
                elif elemloc_idx2 == '3':
                    elemloc = 'ENTRY_POINT'
                elif elemloc_idx2 == '4':
                    elemloc = 'STACK_SIZE'
                elif elemloc_idx2 == '5':
                    elemloc = 'BASE_PRIORITY'
                elif elemloc_idx2 == '6':
                    elemloc = 'PERIOD'
                elif elemloc_idx2 == '7':
                    elemloc = 'TIME_CAPACITY'
                elif elemloc_idx2 == '8':
                    elemloc = 'DEADLINE'
                elif elemloc_idx2 == '9':
                    elemloc = 'CURRENT_PRIORITY'
                elif elemloc_idx2 == '10':
                    elemloc = 'DEADLINE_TIME'
                elif elemloc_idx2 == '11':
                    elemloc = 'PROCESS_STATE'
                elif elemloc_idx2 == '12':
                    elemloc = 'PAR_ID'
                elif elemloc_idx2 == '13':
                    elemloc = 'WAITING_RESOURCE'
                elif elemloc_idx2 == '14':
                    elemloc = 'WAKEUP_TIME'
                elif elemloc_idx2 == '15':
                    elemloc = 'NEXT_ACTIVATION'
                elif elemloc_idx2 == '16':
                    elemloc = 'TIME_OUT'
                elif elemloc_idx2 == '17':
                    elemloc = 'REMAINING_TIMECAPACITY'
                element = element_name + '[' + elemloc_idx1 + ' - 1' + '].' + elemloc
            elif element_name == 'File_System_Configuation_Table':
                if elemloc_idx2 == '3':
                    if self.function_name in ['Invalid_Volume_Space_Available','Invalid_Volume_Space_Available_Length']:
                        elemloc = 'free_block_num * BLOCK_SIZE'
                    else:
                        elemloc = 'free_block_num'
                elif elemloc_idx2 == '4':
                    elemloc = 'block_num'
                elif elemloc_idx2 == '7':
                    elemloc = 'inode_num'
                elif elemloc_idx2 == '8':
                    elemloc = 'free_inode_num'
                elif elemloc_idx2 == '5':
                    elemloc = 'block_size'
                element = 'super_block->' + elemloc
            elif element_name == 'File_Set':
                if elemloc_idx2 == '2':
                    elemloc = 'id'
                elif elemloc_idx2 == '3':
                    elemloc = 'position'
                elif elemloc_idx2 == '4':
                    elemloc = 'size'
                elif elemloc_idx2 == '5':
                    elemloc = 'nb_of_changes'
                elif elemloc_idx2 == '6':
                    elemloc = 'nb_of_write_errors'
                elif elemloc_idx2 == '8':
                    elemloc = 'is_open'
                elif elemloc_idx2 == '9':
                    elemloc = 'mode'
                elif elemloc_idx2 == '10':
                    elemloc = 'entry'
                elif elemloc_idx2 == '11':
                    elemloc = 'cnt'
                elif elemloc_idx2 == '12':
                    elemloc = 'dirBlock[0]'
                if elemloc_idx1 == 'DIR_ID':
                    element = 'inodes[DIR_ID].' + elemloc
                else:
                    element = 'inodes[ID].' + elemloc
                # if elemloc_idx2 == '1':
                #     elemloc = 'name'
                #     if elemloc_idx1 == 'DIR_ID':
                #         element = '//dir_inode.' + elemloc
                #     else:
                #         element = '//inode.' + elemloc
                if elemloc_idx2 == '1':
                    element = 'pass'
                elif elemloc_idx2 == '7':
                    elemloc = 'content'
                    if elemloc_idx1 == 'DIR_ID':
                        element = '//dir_inode.' + elemloc
                    else:
                        element = '//inode.' + elemloc
            elif element_name == 'Directory_Set':
                if 'pos' in elemloc_idx2 and 'NUMBERS' in elemloc_idx2:
                    element = 'dir_item.inodeAddr'
                elif 'pos' in elemloc_idx2 and 'NUMBERS' not in elemloc_idx2:
                    element = 'dir_item.itemName'
                elif elemloc_idx2 == '1':
                    element = 'pass'
                elif elemloc_idx2 == '2':
                    element = 'pass'
            elif element_name == 'In_Progress_Log_Set':
                element = 'In_Progress_Log_Set[{}]'.format(elemloc_idx1)
            elif element_name == 'Logbook_Set':
                element = 'Logbook_Set[{}]'.format(elemloc_idx1)
        self.path.pop()
        return element


    def visitLocation(self, ctx:MatlabParser.LocationContext):
        '''
        Location语法单元访问
        :param ctx: 上下文
        :return:
        '''
        if self.print_flag:
            print('visitLocation')
        return ctx.getText()


    def visitLocation_name(self, ctx:MatlabParser.Location_nameContext):
        '''
        Location_name语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Location_name')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitLocation_name')
        if ctx.COLON():
            locaid = ctx.COLON().getText() # 可能有问题
        elif ctx.expr():
            locaid = self.visit(ctx.expr())
        self.path.pop()
        return locaid


    def visitStatement(self, ctx:MatlabParser.StatementContext):
        '''
        Statement语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Statement')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitStatement')
        if ctx.global_define_list():
            self.visitGlobal_define_list(ctx.global_define_list())
        if ctx.com_statement():
            for item in ctx.com_statement():
                self.visitCom_statement(item)
        self.path.pop()


    def visitGlobal_define_list(self, ctx:MatlabParser.Global_define_listContext):
        '''
        Global_define_list语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Global_define_list')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitGlobal_define_list')
        abbreviation = ''
        if self.flag == 'hier_m':
            abbreviation = ' M*-GLBD'
            globalstat = ''
            for item in ctx.name():
                globalstat = '\t' + 'global ' + item.getText() + ';' + self.MhierMark + abbreviation
                self.hierCode.add_m_hier_code(globalstat)
            self.hierCode.add_m_hier_code('')
        else:
            abbreviation = ' C-GLBD'
            globalstat = ''
            flag = False
            for i in range(len(ctx.GLOBAL())):
                global_name = ctx.name()[i].NAME().getText()
                if global_name in ['PARTION_OPEN_FILES_NUMBERS','PARTION_EXIT_FILES_NUMBERS','CURRENT_DIRECTORY_ID',
                                   'ROOT_DIRECTORY_ID','LOGBOOK_NUMBER','IN_PROGRESS_MESSAGES','CURRENT_LOGBOOK_ID',
                                   'CURRENT_MAX_MESSAGE_SIZE','CURRENT_MAX_NB_LOGGED_MESSAGE','CURRENT_MAX_NB_IN_PROGRESS_MESSAGES',
                                   'CURRENT_LOGGED_MESSAGE_NUMBER','CURRENT_IN_PROGRESS_MESSAGE_NUMBER','CURRENT_ABORTED_MESSAGE_NUMBER']:
                    if self.flag == 'c':
                        globalstat = 'extern APEX_INTEGER ' + global_name + ';'
                        if self.machineC.add_global_statement(global_name):
                            self.machineC.add_global_var_ex(globalstat)
                    elif self.flag == 'hier_c':
                        globalstat = 'extern APEX_INTEGER ' + global_name + ';' + self.ChierMark + abbreviation
                        if self.hierCode.add_global_statement(global_name):
                            self.hierCode.add_global_var_ex(globalstat)
                elif global_name in ['CURRENT_DIRECTORY','ROOT_DIRECTORY']:
                    if self.flag == 'c':
                        globalstat = 'extern int8_t ' + global_name + '[MAX_DIRECTORY_ENTRY_LENGTH];'
                        if self.machineC.add_global_statement(global_name):
                            self.machineC.add_global_var_ex(globalstat)
                    elif self.flag == 'hier_c':
                        globalstat = 'extern int8_t ' + global_name + '[MAX_DIRECTORY_ENTRY_LENGTH];' + self.ChierMark + abbreviation
                        if self.hierCode.add_global_statement(global_name):
                            self.hierCode.add_global_var_ex(globalstat)

                elif global_name in ['CurrentProcess','ERROR_HANDLER_PROCESS_ID']:
                    if self.flag == 'c':
                        globalstat = 'extern APEX_INTEGER ' + global_name + ';'
                        if self.machineC.add_global_statement(global_name):
                            self.machineC.add_global_var_ex(globalstat)
                    elif self.flag == 'hier_c':
                        globalstat = 'extern APEX_INTEGER ' + global_name + ';' + self.ChierMark + abbreviation
                        if self.hierCode.add_global_statement(global_name):
                            self.hierCode.add_global_var_ex(globalstat)
                elif global_name == 'CURRENT_PARTITION':
                    if self.flag == 'c':
                        globalstat = 'extern APEX_INTEGER LOCK_LEVEL;'
                        if self.machineC.add_global_statement(global_name):
                            self.machineC.add_global_var_ex(globalstat)
                    elif self.flag == 'hier_c':
                        globalstat = 'extern APEX_INTEGER LOCK_LEVEL;' + self.ChierMark + abbreviation
                        if self.hierCode.add_global_statement(global_name):
                            self.hierCode.add_global_var_ex(globalstat)

                elif global_name == 'CURRENT_LOGBOOK_NAME':
                    if self.flag == 'c':
                        globalstat = 'extern int8_t CURRENT_LOGBOOK_NAME[MAX_DIRECTORY_ENTRY_LENGTH];'
                        if self.machineC.add_global_statement(global_name):
                            self.machineC.add_global_var_ex(globalstat)
                    elif self.flag == 'hier_c':
                        globalstat = 'extern int8_t CURRENT_LOGBOOK_NAME[MAX_DIRECTORY_ENTRY_LENGTH];' + self.ChierMark + abbreviation
                        if self.hierCode.add_global_statement(global_name):
                            self.hierCode.add_global_var_ex(globalstat)

                elif global_name == 'Logbook_Set':
                    if self.flag == 'c':
                        globalstat = 'extern int8_t Logbook_Set[MAX_NB_LOGGED_MESSAGES_LIMITED][MAX_MESSAGE_SIZE_LIMITED];'
                        if self.machineC.add_global_statement(global_name):
                            self.machineC.add_global_var_ex(globalstat)
                    elif self.flag == 'hier_c':
                        globalstat = 'extern int8_t Logbook_Set[MAX_NB_LOGGED_MESSAGES_LIMITED][MAX_MESSAGE_SIZE_LIMITED];' + self.ChierMark + abbreviation
                        if self.hierCode.add_global_statement(global_name):
                            self.hierCode.add_global_var_ex(globalstat)

                elif global_name == 'In_Progress_Log_Set':
                    if self.flag == 'c':
                        globalstat = 'extern int8_t In_Progress_Log_Set[MAX_NB_IN_PROGRESS_MESSAGES_LIMITED][MAX_MESSAGE_SIZE_LIMITED];'
                        if self.machineC.add_global_statement(global_name):
                            self.machineC.add_global_var_ex(globalstat)
                    elif self.flag == 'hier_c':
                        globalstat = 'extern int8_t In_Progress_Log_Set[MAX_NB_IN_PROGRESS_MESSAGES_LIMITED][MAX_MESSAGE_SIZE_LIMITED];' + self.ChierMark + abbreviation
                        if self.hierCode.add_global_statement(global_name):
                            self.hierCode.add_global_var_ex(globalstat)

                elif global_name == 'Aborted_Log_Set':
                    if self.flag == 'c':
                        globalstat = 'extern int8_t Aborted_Log_Set[MAX_NB_ABORTED_MESSAGES_LIMITED][MAX_MESSAGE_SIZE_LIMITED];'
                        if self.machineC.add_global_statement(global_name):
                            self.machineC.add_global_var_ex(globalstat)
                    elif self.flag == 'hier_c':
                        globalstat = 'extern int8_t Aborted_Log_Set[MAX_NB_ABORTED_MESSAGES_LIMITED][MAX_MESSAGE_SIZE_LIMITED];' + self.ChierMark + abbreviation
                        if self.hierCode.add_global_statement(global_name):
                            self.hierCode.add_global_var_ex(globalstat)

                elif global_name in ['Directory_Set','File_Set','Open_File_Set','File_System_Configuation_Table']:
                    flag = True

            # 只要一个出现,就加入所有的
            if flag:
                if self.flag == 'c':
                    self.machineC.add_global_var_ex('extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];')
                    self.machineC.add_global_var_ex('extern bool inode_bitmap[INODE_NUM];')
                    self.machineC.add_global_var_ex('extern bool block_bitmap[BLOCK_NUM];')
                    self.machineC.add_global_var_ex('extern char Directory_Name_Set[INODE_NUM][MAX_FILE_NAME_LENGTH];')
                    self.machineC.add_global_var_ex('extern SuperBlock *super_block;')
                    self.machineC.add_global_var_ex('extern int8_t blocks[2621440];')
                    self.machineC.add_global_var_ex('extern Inode inodes[512];')
                    self.machineC.add_global_var_ex('extern int32_t ROOT_DIRECTORY_ID;')
                    self.machineC.add_global_var_ex('extern int32_t CURRENT_DIRECTORY_ID;')
                    self.machineC.add_global_var_ex('extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];')
                elif self.flag == 'hier_c':
                    self.hierCode.add_global_var_ex('extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];')
                    self.hierCode.add_global_var_ex('extern bool inode_bitmap[INODE_NUM];')
                    self.hierCode.add_global_var_ex('extern bool block_bitmap[BLOCK_NUM];')
                    self.hierCode.add_global_var_ex('extern char Directory_Name_Set[INODE_NUM][MAX_FILE_NAME_LENGTH];')
                    self.hierCode.add_global_var_ex('extern SuperBlock *super_block;')
                    self.hierCode.add_global_var_ex('extern int8_t blocks[2621440];')
                    self.hierCode.add_global_var_ex('extern int8_t blocks[2621440];')
                    self.hierCode.add_global_var_ex('extern Inode inodes[512];')
                    self.hierCode.add_global_var_ex('extern int32_t ROOT_DIRECTORY_ID;')
                    self.hierCode.add_global_var_ex('extern int32_t CURRENT_DIRECTORY_ID;')
                    self.hierCode.add_global_var_ex('extern int8_t Cur_Dir_Name[MAX_DIRECTORY_ENTRY_LENGTH];')
        self.path.pop()
        return globalstat


    def visitCom_statement(self, ctx:MatlabParser.Com_statementContext):
        '''
        Com_statement语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Com_statement')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitCom_statement')
        comstat = ''
        if ctx.assign_state():
            comstat = '\t' + self.visitAssign_state(ctx.assign_state())
        if ctx.function_call():
            comstat = '\t' + self.visitFunction_call(ctx.function_call())
        if ctx.return_state():
            comstat = '\t' + self.visitReturn_state(ctx.return_state())
        if ctx.while_state():
            comstat = '\t' + self.visitWhile_state(ctx.while_state())
        if ctx.if_state():
            comstat = '\t' + self.visitIf_state(ctx.if_state())
        if ctx.break_state():
            comstat = '\t' + self.visitBreak_state(ctx.break_state())
        if ctx.continue_state():
            comstat = '\t' + self.visitContinue_state(ctx.continue_state())
        if ctx.element_insert_state():
            comstat = '\t' + self.visitElement_insert_state(ctx.element_insert_state())
        if ctx.element_delete_state():
            comstat = '\t' + self.visitElement_delete_state(ctx.element_delete_state())
        if ctx.typedef():
            comstat = '\t' + self.visitTypedef(ctx.typedef())
        if ctx.element_ismember_set():
            comstat = '\t' + self.visitElement_ismember_set(ctx.element_ismember_set())
        if ctx.element_take():
            comstat = '\t' + self.visitElement_take(ctx.element_take())
        if ctx.ruledef():
            comstat = '\t' + self.visitRuledef(ctx.ruledef())
        self.path.pop()
        return comstat


    def visitAssign_state(self, ctx:MatlabParser.Assign_stateContext):
        '''
        Assign_state语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Assign_state')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitAssign_state')
        abbreviation = ''
        if self.flag == 'hier_c':
            abbreviation = ' C-ASS'
            expr0 = self.visit(ctx.expr()[0])
            expr1 = self.visit(ctx.expr()[1])
            if expr0  == 'pass' or expr1 == 'pass':
                assign = ''
            else:
                if expr0[-4:] == 'NAME' or expr1[-4:] == 'NAME':
                    assign = 'strcpy(' + expr0 + ', ' + expr1 + ');'+ self.ChierMark + self.get_level() \
                             + abbreviation
                elif 'get_file_prefix' in expr1:
                    assign = expr1 + expr0 + ');' + self.ChierMark + self.get_level() + abbreviation
                elif 'get_volume_name' in expr1:
                    assign = expr1 + expr0 + ');' + self.ChierMark + self.get_level() + abbreviation
                elif 'transfer_to_message' in expr1:
                    assign = expr1 + expr0 + ');' + self.ChierMark + self.get_level() + abbreviation
                elif 'dirBlock' in expr0: # dirblo
                    assign = expr0 + ' ' + ctx.ASSIGN().getText() + ' block_alloc();' + self.ChierMark + self.get_level() \
                             + abbreviation
                elif expr0 == 'index' and expr1 in ['DIR_ID','VOL_ID','ID','OLD_DIR_ID','NEW_DIR_ID','pos']:
                    assign = expr0 + ' ' + ctx.ASSIGN().getText() + ' ' + expr1 + ' +1;' + self.ChierMark + self.get_level() \
                             + abbreviation
                else:
                    assign = expr0 + ' ' + ctx.ASSIGN().getText() + ' ' + expr1 + ';' + self.ChierMark + self.get_level() \
                             + abbreviation
                self.add_level()
                if len(self.path)>=3 and self.path[len(self.path)-3] == 'Statement':
                    if self.functionFlag:
                        self.hierCode.add_function_string("\t" + assign)
                    else:
                        self.hierCode.add_static_function_string("\t" + assign)
        elif self.flag == 'c':
            expr0 = self.visit(ctx.expr()[0])
            expr1 = self.visit(ctx.expr()[1])
            if expr0  == 'pass' or expr1 == 'pass':
                assign = ''
            else:
                if expr0[-4:] == 'NAME' or expr1[-4:] == 'NAME':
                    assign = 'strcpy(' + expr0 + ', ' + expr1 + ');'
                elif 'get_file_prefix' in expr1:
                    assign = expr1 + expr0 + ');'
                elif 'get_volume_name' in expr1:
                    assign = expr1 + expr0 + ');'
                elif 'transfer_to_message' in expr1:
                    assign = expr1 + expr0 + ');'
                elif 'dirBlock' in expr1: # dirblo
                    assign = expr0 + ' ' + ctx.ASSIGN().getText() + ' block_alloc();'
                elif expr0 == 'index' and expr1 in ['DIR_ID','VOL_ID','ID','OLD_DIR_ID','NEW_DIR_ID','pos']:
                    assign = expr0 + ' ' + ctx.ASSIGN().getText() + ' ' + expr1 + ' +1;'
                else:
                    assign = expr0 + ' ' + ctx.ASSIGN().getText() + ' ' + expr1 +  ';'
                if len(self.path)>=3 and self.path[len(self.path)-3] == 'Statement':
                    if self.functionFlag:
                        self.machineC.add_function_string("\t" + assign)
                    else:
                        self.machineC.add_static_function_string("\t" + assign)
        else:
            abbreviation = ' M*-ASS'
            assign = self.visit(ctx.expr()[0]) + ' ' + ctx.ASSIGN().getText() + ' ' + self.visit(ctx.expr()[1]) + \
                ';' + self.MhierMark + self.get_level() + abbreviation
            self.add_level()
            if len(self.path)>=3 and self.path[len(self.path)-3] == 'Statement':
                self.hierCode.add_m_hier_code("\t" + assign)
        self.path.pop()
        return assign


    def visitFunction_call(self, ctx:MatlabParser.Function_callContext):
        '''
        Function_call语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Function_call')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitFunction_call')
        abbreviation = ''
        name = self.visitName(ctx.name())
        # for i in range(10):
        #     print(name)
        paralist = self.visitParalist(ctx.paralist())
        if name == 'Open_File_Set':
            if self.flag == 'hier_m':
                funcall = ctx.getText()
            else:
                funcall = 'inode_bitmap' + '[' + paralist + ']'
        elif name == 'get_file_prefix':
            if self.flag == 'hier_m':
                funcall = ctx.getText()
            else:
                funcall = 'get_file_prefix({},'.format(paralist)
        elif name == 'get_volume_name':
            if self.flag == 'hier_m':
                funcall = ctx.getText()
            else:
                funcall = 'get_volume_name({},'.format(paralist)
        elif name == 'transfer_to_message':
            if self.flag == 'hier_m':
                funcall = ctx.getText()
            else:
                funcall = 'transfer_to_message({},'.format(paralist)
        else:
            if self.flag == 'hier_c':
                abbreviation = ' C-FUC'
                funcall = name + '(' + paralist + ')'
                if len(self.path) >= 2 and self.path[len(self.path)-2] == 'Com_statement':
                    funcall = funcall + ';' + self.ChierMark + self.get_level() + abbreviation
                    if len(self.path)>2 and self.path[-3] == 'If_state':
                        pass
                    else:
                        if self.functionFlag:
                            self.hierCode.add_function_string('\t' + funcall)
                        else:
                            self.hierCode.add_static_function_string('\t' + funcall)
                    self.add_level()
            elif self.flag == 'c':
                funcall = name + '(' + paralist + ')'
                if len(self.path) >= 2 and self.path[len(self.path)-2] == 'Com_statement':
                    funcall = funcall + ';'
                    if len(self.path)>2 and self.path[-3] == 'If_state':
                        pass
                    else:
                        if self.functionFlag:
                            self.machineC.add_function_string('\t' + funcall)
                        else:
                            self.machineC.add_static_function_string('\t' + funcall)
            else:
                abbreviation = ' M*-FUC'
                funcall = name + paralist
                if len(self.path) >= 2 and self.path[len(self.path)-2] == 'Com_statement':
                    funcall = funcall + ';' + self.MhierMark + self.get_level() + abbreviation
                    self.add_level()
        self.path.pop()
        return funcall


    def visitReturn_state(self, ctx:MatlabParser.Return_stateContext):
        '''
        Return_state语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Return_state')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitReturn_state')
        abbreviation = ''
        if self.flag == 'hier_c':
            abbreviation = ' C-RET'
            if self.functionFlag:
                returnstat = ctx.RETURN().getText() + ';' + self.ChierMark + self.get_level() + abbreviation
                if len(self.path) >=3 and self.path[len(self.path)-3] == 'Statement':
                    self.hierCode.add_function_string('\t' + returnstat)
            else:
                returnstat = 'return ' + self.static_return + ';' + self.ChierMark + self.get_level() + abbreviation
                if len(self.path) >=3 and self.path[len(self.path)-3] == 'Statement':
                    self.hierCode.add_static_function_string('\t' + returnstat)
            self.add_level()
        elif self.flag == 'c':
            if self.functionFlag:
                returnstat = ctx.RETURN().getText() + ';'
                if len(self.path) >=3 and self.path[len(self.path)-3] == 'Statement':
                    self.machineC.add_function_string('\t' + returnstat)
            else:
                returnstat = 'return ' + self.static_return + ';'
                if len(self.path) >=3 and self.path[len(self.path)-3] == 'Statement':
                    self.machineC.add_static_function_string('\t' + returnstat)
        else:
            abbreviation = ' M*-RET'
            returnstat = ctx.RETURN().getText() + ';' + self.MhierMark + self.get_level() + abbreviation
            self.hierCode.add_m_hier_code("\t" + returnstat)
            self.add_level()
        self.path.pop()
        return returnstat


    def visitWhile_state(self, ctx:MatlabParser.While_stateContext):
        '''
        While_state语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('While_state')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitWhile_state')
        abbreviation = ''
        whiles = ctx.WHILE().getText()
        while_expr = self.visit(ctx.expr())
        comstat = ''
        whiletab = '\t'
        if len(self.path) >=3 and self.path[len(self.path)-3] == 'If_state':
            whiletab = '\t\t'
        if len(ctx.com_statement())>0:
            self.level.append(0)
            for i in range(len(ctx.com_statement())):
                comstat = comstat + whiletab + self.visitCom_statement(ctx.com_statement()[i]) + '\n'
            self.level.pop()
        if self.flag == 'hier_c':
            abbreviation = ' C-WHIS'
            whilestat = whiles + ' (' + while_expr + ') {' + self.ChierMark + self.get_level() + abbreviation + '\n' + \
                comstat + whiletab + '}'
            self.add_level()
            if len(self.path)>=3 and self.path[len(self.path)-3] == 'Statement':
                if self.functionFlag:
                   self.hierCode.add_function_string('\t' + whilestat)
                else:
                    self.hierCode.add_static_function_string('\t' + whilestat)
        elif self.flag == 'c':
            whilestat = whiles + ' (' + while_expr + ') {\n' + comstat + whiletab + '}'
            if self.functionFlag:
               self.hierCode.add_function_string('\t' + whilestat)
            else:
                self.hierCode.add_static_function_string('\t' + whilestat)
        else:
            abbreviation = ' M*-WHIS'
            whilestat = whiles + ' ' + while_expr + self.MhierMark + self.get_level() + abbreviation + '\n' \
                        + comstat + whiletab + ctx.END().getText()
            self.add_level()
            if len(self.path)>=3 and self.path[len(self.path)-3] == 'Statement':
                self.hierCode.add_m_hier_code("\t" + whilestat)
        self.path.pop()
        return whilestat


    def visitIf_state(self, ctx:MatlabParser.If_stateContext):
        '''
        If_state语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('If_state')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitIf_state')
        abbreviation = ''
        ifexpr = self.visit(ctx.expr())
        comstat = ''
        iftab = '\t'
        if len(self.path)>=3 and self.path[len(self.path)-3] == 'If_state':
            iftab = '\t\t'
        if len(ctx.com_statement())>0:
            self.level.append(0)
            for i in range(len(ctx.com_statement())):
                # self.add_level()
                comstat = comstat + iftab + self.visitCom_statement(ctx.com_statement()[i]) + '\n'
            self.level.pop()
        ifstat = ''
        if self.flag == 'hier_c':
            abbreviation = ' C-IFS'
            ifstat = ctx.IF().getText() + ' (' + ifexpr + ') {' + self.ChierMark + self.get_level() + abbreviation \
                     + '\n' + comstat + iftab + '}'
            self.add_level()

        elif self.flag == 'c':
            ifstat = ctx.IF().getText() + ' (' + ifexpr + ') {\n' + comstat + iftab + '}'

        else:
            abbreviation = ' M*-IFS'
            ifstat = ctx.IF().getText() + ' ' + ifexpr + self.MhierMark +self.get_level() + abbreviation + '\n' + comstat + iftab
            self.add_level()

        if len(ctx.elseif_state())>0:
            for i in range(len(ctx.elseif_state())):
                elseifstat = self.visitElseif_state(ctx.elseif_state()[i])
                ifstat = ifstat + elseifstat
        if ctx.else_state():
            elsestat = self.visitElse_state(ctx.else_state())
            ifstat = ifstat + elsestat
        if self.flag == 'hier_c':
            if len(self.path) >=3 and self.path[len(self.path)-3] == 'Statement':
                if self.functionFlag:
                    self.hierCode.add_function_string('\t' + ifstat)
                else:
                    self.hierCode.add_static_function_string('\t' + ifstat)
        elif self.flag == 'c':
            if len(self.path) >=3 and self.path[len(self.path)-3] == 'Statement':
                if self.functionFlag:
                    self.machineC.add_function_string('\t' + ifstat)
                else:
                    self.machineC.add_static_function_string('\t' + ifstat)
        else:
            ifstat = ifstat + ctx.END().getText()
            if len(self.path) >=3 and self.path[len(self.path)-3] == 'Statement':
                self.hierCode.add_m_hier_code('\t' + ifstat)
        self.path.pop()
        return ifstat


    def visitElseif_state(self, ctx:MatlabParser.Elseif_stateContext):
        '''
        Elseif_state语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Elseif_state')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitElseif_state')
        abbreviation = ' C-ELIF'
        elseifexpr = self.visit(ctx.expr())
        comstat = ''
        iftab = '\t'
        if len(self.path) >=4 and self.path[len(self.path)-4] == 'If_state':
            iftab = '\t\t'
        '''
        if (ctx.getParent().getParent().getParent().getClass() == MatlabParser.If_stateContext.class || ctx.getParent().getParent().getParent().getParent().getClass() == MatlabParser.If_stateContext.class) {
			iftab = "\t\t";
		}
		if (ctx.getParent().getParent().getParent().getParent().getClass() != MatlabParser.FunctionContext.class) {
			if (ctx.getParent().getParent().getParent().getParent().getParent().getClass() == MatlabParser.If_stateContext.class) {
				iftab = "\t\t\t";
			}
		}
        '''
        if len(ctx.com_statement())>0:
            self.level.append(0)
            for i in range(len(ctx.com_statement())):
                comstat = comstat + iftab + self.visitCom_statement(ctx.com_statement()[i]) + '\n'
            self.level.pop()
        if self.flag == 'hier_c':
            abbreviation = ' C-ELIF'
            elseifstat = ' ' + ctx.ELSEIF().getText() + ' (' + elseifexpr + ') {' + self.ChierMark + self.get_level() \
                         + abbreviation + '\n' + comstat + iftab + '}'
            self.add_level()
            elseifstat = elseifstat.replace('elseif','else if')
        elif self.flag == 'c':
            elseifstat = ' ' + ctx.ELSEIF().getText() + ' (' + elseifexpr + ') {\n' + comstat + iftab + '}'
            elseifstat = elseifstat.replace('elseif','else if')
        else:
            abbreviation = ' C-ELIF'
            elseifstat = ctx.ELSEIF().getText() + ' ' + elseifexpr + self.MhierMark + self.get_level() + abbreviation \
                         + '\n' +  comstat + iftab
            self.add_level()
        self.path.pop()
        return elseifstat


    def visitElse_state(self, ctx:MatlabParser.Else_stateContext):
        '''
        Else_state语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Else_state')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitElse_state')
        abbreviation = ''
        comstat = ''
        iftab = '\t'
        if len(self.path) >=4 and self.path[len(self.path)-4] == 'If_state':
            iftab = '\t\t'
        '''
        if (ctx.getParent().getParent().getParent().getClass() == MatlabParser.If_stateContext.class || ctx.getParent().getParent().getParent().getParent().getClass() == MatlabParser.If_stateContext.class) {
			iftab = "\t\t";
		}
		if (ctx.getParent().getParent().getParent().getParent().getClass() != MatlabParser.FunctionContext.class) {
			if (ctx.getParent().getParent().getParent().getParent().getParent().getClass() == MatlabParser.If_stateContext.class) {
				iftab = "\t\t\t";
			}
		}
        '''
        if len(ctx.com_statement())>0:
            self.level.append(0)
            for i in range(len(ctx.com_statement())):
                comstat = comstat + iftab + self.visitCom_statement(ctx.com_statement()[i]) + '\n'
            self.level.pop()
        if self.flag == 'hier_c':
            abbreviation = ' C-ELS'
            elsestat = ' ' + ctx.ELSE().getText() + ' {' + self.ChierMark + self.get_level() \
                         + abbreviation + '\n' + comstat + iftab + '}'
            self.add_level()
        elif self.flag == 'c':
            elsestat = ' ' + ctx.ELSE().getText() + ' {\n' + comstat + iftab + '}'
            elsestat = elsestat.replace('elseif','else if')
        else:
            abbreviation = ' M*-ELS'
            elsestat = ctx.ELSE().getText() + self.MhierMark + self.get_level() + abbreviation \
                         + '\n' +  comstat + iftab
            self.add_level()
        self.path.pop()
        return elsestat


    def visitBreak_state(self, ctx:MatlabParser.Break_stateContext):
        '''
        Break_state语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Break_state')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitBreak_state')
        abbreviation = ''
        if self.flag == 'hier_c':
            abbreviation = ' C-BRK'
            breakstat = ' ' + ctx.BREAK().getText() + ';' + self.ChierMark + self.get_level() + abbreviation
            self.add_level()
        elif self.flag == 'c':
            breakstat = ctx.BREAK().getText() + ';'
        else:
            abbreviation = ' M*-BRK'
            breakstat = ' ' + ctx.BREAK().getText() + ';' + self.MhierMark + self.get_level() + abbreviation
            self.add_level()
        self.path.pop()
        return breakstat


    def visitContinue_state(self, ctx:MatlabParser.Continue_stateContext):
        '''
        Continue_state语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Continue_state')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitContinue_state')
        abbreviation = ''
        if self.flag == 'hier_c':
            abbreviation = ' C-CNT'
            continuestat = ctx.CONTINUE().getText() + ';' + self.ChierMark + self.get_level() + abbreviation
            self.add_level()
        elif self.flag == 'c':
            continuestat = ctx.CONTINUE().getText() + ';'
        else:
            abbreviation = ' M*-BRK'
            continuestat = ctx.CONTINUE().getText() + ';' + self.MhierMark + self.get_level() + abbreviation
            self.add_level()
        self.path.pop()
        return continuestat


    def visitElement_insert_state(self, ctx:MatlabParser.Element_insert_stateContext):
        '''
        Element_insert_state语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Element_insert_state')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitElement_insert_state')
        abbreviation = ''
        if self.flag == 'hier_c':
            abbreviation = ' C-UNO'
            eleminsert = ctx.UNION().getText().replace('u','U') + '(' + self.visit(ctx.expr()[1]) + ', ' + \
                self.visitName(ctx.name()) + ');' + self.ChierMark + self.get_level() + abbreviation
            self.add_level()
            if len(self.path) >=3 and self.path[len(self.path)-3] == 'Statement':
                if self.functionFlag:
                    self.hierCode.add_function_string('\t' + eleminsert)
                else:
                    self.hierCode.add_static_function_string('\t' + eleminsert)
        elif self.flag == 'c':
            eleminsert = ctx.UNION().getText().replace('u','U') + '(' + self.visit(ctx.expr()[1]) + ', ' + \
                self.visitName(ctx.name()) + ');'
            if len(self.path) >=3 and self.path[len(self.path)-3] == 'Statement':
                if self.functionFlag:
                    self.machineC.add_function_string('\t' + eleminsert)
                else:
                    self.machineC.add_static_function_string('\t' + eleminsert)
        else:
            abbreviation = ' M-UNO'
            eleminsert = ctx.UNION().getText() + '(' + self.visit(ctx.expr()[1]) + ', ' + \
                self.visitName(ctx.name()) + ');' + self.MhierMark + self.get_level() + abbreviation
            self.add_level()
            if len(self.path) >=3 and self.path[len(self.path)-3] == 'Statement':
                self.hierCode.add_m_hier_code('\t' + eleminsert)
        self.path.pop()
        return eleminsert


    def visitElement_delete_state(self, ctx:MatlabParser.Element_delete_stateContext):
        '''
        Element_delete_state语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Element_delete_state')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitElement_delete_state')
        abbreviation = ''
        if self.flag == 'hier_c':
            abbreviation = ' C-SETD'
            elemdelete = ctx.SETDIFF().getText().replace('s','S') + '(' + self.visit(ctx.expr()[1]) + ', ' + \
                self.visitName(ctx.name()) + ');' + self.ChierMark + self.get_level() + abbreviation
            self.add_level()
            if len(self.path) >=3 and self.path[len(self.path)-3] == 'Statement':
                if self.functionFlag:
                    self.hierCode.add_function_string('\t' + elemdelete)
                else:
                    self.hierCode.add_static_function_string('\t' + elemdelete)
        elif self.flag == 'c':
            elemdelete = ctx.SETDIFF().getText().replace('s','S') + '(' + self.visit(ctx.expr()[1]) + ', ' + \
                self.visitName(ctx.name()) + ');'
            if len(self.path) >=3 and self.path[len(self.path)-3] == 'Statement':
                if self.functionFlag:
                    self.machineC.add_function_string('\t' + elemdelete)
                else:
                    self.machineC.add_static_function_string('\t' + elemdelete)
        else:
            abbreviation = ' M*-SETD'
            elemdelete = ctx.SETDIFF().getText() + '(' + self.visit(ctx.expr()[1]) + ', ' + \
                self.visitName(ctx.name()) + ');' + self.MhierMark + self.get_level() + abbreviation
            self.add_level()
            if len(self.path) >=3 and self.path[len(self.path)-3] == 'Statement':
                self.hierCode.add_m_hier_code('\t' + elemdelete)
        self.path.pop()
        return elemdelete


    def visitElement_take(self, ctx:MatlabParser.Element_takeContext):
        '''
        Element_take语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Element_take')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitElement_take')
        abbreviation = ''
        element_take = ''
        set_name = self.visitName(ctx.name())
        element_type = ''
        element_name = ctx.element().name().NAME().getText()
        if self.flag == 'hier_c':
            abbreviation = ' C-ETKS'
            if element_name == 'Directory_Set':
                number0 = ctx.element().location().location_name()[0].getText()
                number1 = ctx.element().location().location_name()[1].getText()
                if number0 == ':' and number1 != ':':
                    if number1 == '1':
                        if 'Directory_Name_Set' not in self.hierCode.globalVarEx:
                            self.hierCode.add_global_var_ex('extern char Directory_Name_Set[INODE_NUM][MAX_FILE_NAME_LENGTH];')
                if number0 != ':' and number1 == ':':
                    element_take = 'for (int i = 0; i < DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS; i++) {\n\t\t' + \
                                   'int32_t diritem_dir = Inode_StartAddr + ({}-1)*BLOCK_SIZE + i*64\n\t\t'.format(number0) + \
                                   'struct DirItem dir;\n\t\t' + 'fseek(fr,diritem_dir,SEEK_SET);\n\t\t' + \
                                   'fread(&dir,sizeof(struct Inode),1,fr);\n\t\t' + \
                                   'strcpy(Sub_Directory_Set[i],dir.itemName)' + self.ChierMark +  self.get_level() + abbreviation
            else:
                element_take = element_take + self.ChierMark +  self.get_level() + abbreviation
            self.add_level()
            if len(self.path) >=3 and self.path[len(self.path)-3] == 'Statement':
                if self.functionFlag:
                    self.hierCode.add_function_string('\t' + element_take)
                else:
                    self.hierCode.add_static_function_string('\t' + element_take)
        elif self.flag == 'c':
            if element_name == 'Directory_Set':
                number0 = ctx.element().location().location_name()[0].getText()
                number1 = ctx.element().location().location_name()[1].getText()
                if number0 == ':' and number1 != ':':
                    if number1 == '1':
                        if 'Directory_Name_Set' not in self.hierCode.globalVarEx:
                            self.machineC.add_global_var_ex('extern char Directory_Name_Set[INODE_NUM][MAX_FILE_NAME_LENGTH];')
                if number0 != ':' and number1 == ':':
                    element_take = 'for (int i = 0; i < DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS; i++) {\n\t\t' + \
                                   'int32_t diritem_dir = Inode_StartAddr + ({}-1)*BLOCK_SIZE + i*64;\n\t\t'.format(number0) + \
                                   'struct DirItem dir;\n\t\t' + 'fseek(fr,diritem_dir,SEEK_SET);\n\t\t' + \
                                   'fread(&dir,sizeof(struct Inode),1,fr);\n\t\t' + \
                                   'strcpy(Sub_Directory_Set[i],dir.itemName)'
                    self.add_level()
            else:
                pass

            if len(self.path) >=3 and self.path[len(self.path)-3] == 'Statement':
                if self.functionFlag:
                    self.machineC.add_function_string('\t' + element_take)
                else:
                    self.machineC.add_static_function_string('\t' + element_take)
        else:
            if element_name == 'Process_Set':
                number1 = ctx.element().location().location_name()[1].getText()
                if number1 == '1':
                    set_name = 'PROCESS_ID_TYPE' + set_name
                    element_type = 'ID'
                    set_name = set_name + '[SYSTEM_NUMBER_OF_PROCESSES];\n\t'
                    element_take = set_name + 'for (int i = 0; i < SYSTEM_NUMBER_OF_PROCESSES; i++) {\n\t\t' +  self.visitName(ctx.name())
            abbreviation = ' M*-ETKS'
            element_take = ctx.getText() + ';' + self.MhierMark + self.get_level() + abbreviation
            self.add_level()
            if len(self.path) >=3 and self.path[len(self.path)-3] == 'Statement':
                self.hierCode.add_m_hier_code('\t' + element_take)
        self.path.pop()
        return element_take


    def visitElement_ismember_set(self, ctx:MatlabParser.Element_ismember_setContext):
        '''
        Element_ismember_set语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Element_ismember_set')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitElement_ismember_set')
        abbreviation = ''
        returnparas = self.visitReturnparas(ctx.returnparas())
        ismem = ctx.ISMEMBER().getText()
        name0 = self.visitName(ctx.name()[0])
        name1 = self.visitName(ctx.name()[1])
        num = ''
        if self.visitReturn_name(ctx.returnparas().return_name()[0]) != '':
            if name1 in []:
                ismem = ismem + '1'
            elif name1 in []:
                ismem = ismem + '3'
        elif self.visitReturn_name(ctx.returnparas().return_name()[1]) != '': # 根据返回的是index还是flag
            if name1 in []:
                ismem = ismem + '2'
            elif name1 == 'Directory_Name_Set':
                ismem = ismem + '4'
                num = 'MAX_DIRECTORY_NUMBER'
            elif name1 == 'Sub_Directory_Set':
                ismem = ismem + '4'
                num = 'DIRECTORY_LIMIT_FILE_OR_SUBDIRECTOR_NUMBERS'
            elif name1 == 'In_Progress_Log_Set2':
                name1 = 'In_Progress_Log_Set'
                ismem = ismem + '4'
                num = 'MAX_NB_IN_PROGRESS_MESSAGES_LIMITED'
            elif name1 == 'Logbook_Set2':
                name1 = 'Logbook_Set'
                ismem = ismem + '4'
                num = 'MAX_NB_LOGGED_MESSAGES_LIMITED'

        if self.flag == 'hier_c':
            abbreviation = ' C-EISM'
            if name1 == 'Open_File_Set' and self.visitReturn_name(ctx.returnparas().return_name()[0]) == '':
                element_ismem = returnparas + ' = ' + 'inode_bitmap[{}];'.format(name0) +  self.ChierMark + \
                                self.get_level() + abbreviation
            else:
                element_ismem = returnparas + ' ' + ctx.ASSIGN().getText() + ' ' + ismem + '(' + name0 + \
                            ', ' + name1 + ',' + num + ');' + self.ChierMark + self.get_level() + abbreviation
            self.add_level()
            if len(self.path) >=3 and self.path[len(self.path)-3] == 'Statement':
                if self.functionFlag:
                    self.hierCode.add_function_string('\t' + element_ismem)
                else:
                    self.hierCode.add_static_function_string('\t' + element_ismem)
        elif self.flag == 'c':
            if name1 == 'Open_File_Set' and self.visitReturn_name(ctx.returnparas().return_name()[0]) == '':
                element_ismem = returnparas + ' = ' + 'inode_bitmap[{}];'.format(name0)
            else:
                element_ismem = returnparas + ' ' + ctx.ASSIGN().getText() + ' ' + ismem + '(' + name0 + \
                            ', ' + name1 + ',' + num + ');'
            self.add_level()
            if len(self.path) >=3 and self.path[len(self.path)-3] == 'Statement':
                if self.functionFlag:
                    self.machineC.add_function_string('\t' + element_ismem)
                else:
                    self.machineC.add_static_function_string('\t' + element_ismem)
        else:
            abbreviation = ' M*-EISM'
            element_ismem = self.visitReturnparas(ctx.returnparas()) + ' ' + ctx.ASSIGN().getText() + ' ' + \
                            ctx.ISMEMBER().getText() + '(' + self.visitName(ctx.name()[0]) + ', ' + self.visitName(ctx.name()[1]) + \
                            ');' + self.MhierMark + self.get_level() + abbreviation
            self.add_level()
            if len(self.path) >=3 and self.path[len(self.path)-3] == 'Statement':
                self.hierCode.add_m_hier_code('\t' + element_ismem)
        self.path.pop()
        return element_ismem


    def visitNameplus(self, ctx:MatlabParser.NameplusContext):
        '''
        Nameplus语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Nameplus')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitNameplus')
        if self.flag == 'hier_m':
            name = ctx.NAMEPLUS().getText()
        else:
            name = ctx.NAMEPLUS().getText()
        self.path.pop()
        return name

    # todo：正则表达式转换
    def visitRegExpr(self, ctx:MatlabParser.RegExprContext):
        '''
        RegExpr语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('RegExpr')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitRegExpr')
        if self.flag == 'hier_m':
            name0 = ctx.name()[0].NAME.getText()
            name1 = ctx.name()[0].NAME.getText()
        pass


    def visitTypedef(self, ctx:MatlabParser.TypedefContext):
        '''
        Typedef语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Typedef')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitTypedef')
        abbreviation = ''
        if len(ctx.cate().NAME()) == 1:
            type = ctx.cate().getText()
        else:
            type = ctx.cate().NAME()[0].getText() + ' ' + ctx.cate().NAME()[1].getText()

        if ctx.name():
            name_list = []
            for item in ctx.name():
                name = self.visitName(item)
                name_list.append(name)
            names = ','.join(name_list)
            if self.flag == 'hier_c':
                abbreviation = ' C-TYDE'
                typedef = type + ' ' + names + ';' + self.ChierMark + self.get_level() + abbreviation
                self.add_level()
                # if (ctx.getParent().getParent().getClass() == MatlabParser.StatementContext.class) {
                if len(self.path)>2 and self.path[-3] == 'If_state':
                    pass
                else:
                    if self.functionFlag:
                        self.hierCode.add_function_string('\t' + typedef)
                    else:
                        self.hierCode.add_static_function_string('\t' + typedef)
            elif self.flag == 'c':
                typedef = type + ' ' + names + ';'
                # if (ctx.getParent().getParent().getClass() == MatlabParser.StatementContext.class) {
                if len(self.path)>2 and self.path[-3] == 'If_state':
                    pass
                else:
                    if self.functionFlag:
                        self.machineC.add_function_string('\t' + typedef)
                    else:
                        self.machineC.add_static_function_string('\t' + typedef)
            else:
                # definemark 代表注释
                abbreviation = ' M*-TYDE'
                typedef = ctx.definemark().getText() + ' ' + type + ' ' + names + ';' + self.MhierMark + self.get_level() + abbreviation
                self.add_level()
                # if (ctx.getParent().getParent().getClass() == MatlabParser.StatementContext.class) {
                if len(self.path)>2 and self.path[-3] == 'If_state':
                    pass
                else:
                    self.hierCode.add_m_hier_code('\t' + typedef)
        elif ctx.nameplus():
            name_plus = self.visitNameplus(ctx.nameplus())
            if self.flag == 'hier_c':
                abbreviation = ' C-TYDE'
                typedef = type + ' ' + name_plus + ';' + self.ChierMark + self.get_level() + abbreviation
                self.add_level()
                # if (ctx.getParent().getParent().getClass() == MatlabParser.StatementContext.class) {
                if len(self.path)>2 and self.path[-3] == 'If_state':
                    pass
                else:
                    if self.functionFlag:
                        self.hierCode.add_function_string('\t' + typedef)
                    else:
                        self.hierCode.add_static_function_string('\t' + typedef)
            elif self.flag == 'c':
                typedef = type + ' ' + name_plus + ';'
                # if (ctx.getParent().getParent().getClass() == MatlabParser.StatementContext.class) {
                if len(self.path)>2 and self.path[-3] == 'If_state':
                    pass
                else:
                    if self.functionFlag:
                        self.machineC.add_function_string('\t' + typedef)
                    else:
                        self.machineC.add_static_function_string('\t' + typedef)
            else:
                # definemark 代表注释
                abbreviation = ' M*-TYDE'
                typedef = ctx.definemark().getText() + ' ' + type + ' ' + name_plus + ';' + self.MhierMark + self.get_level() + abbreviation
                self.add_level()
                # if (ctx.getParent().getParent().getClass() == MatlabParser.StatementContext.class) {
                if len(self.path)>2 and self.path[-3] == 'If_state':
                    pass
                else:
                    self.hierCode.add_m_hier_code('\t' + typedef)

        self.path.pop()
        return typedef


    def visitStrExpr(self, ctx:MatlabParser.StrExprContext):
        '''
        StrExpr语法单元访问
        :param ctx: 上下文
        :return:
        '''
        return ctx.getText()


    def visitRuledef(self, ctx:MatlabParser.RuledefContext):
        '''
        Ruledef语法单元访问
        :param ctx: 上下文
        :return:
        '''
        self.path.append('Typedef')
        if self.print_flag:
            print('->'.join(self.path))
            print('visitTypedef')
        if self.flag == 'hier_m':
            abbreviation = ' M*-RLDE'
            ruledef = ctx.getText() + self.MhierMark + self.get_level() + abbreviation
            self.add_level()
            # if (ctx.getParent().getParent().getClass() == MatlabParser.StatementContext.class) {
            self.hierCode.add_m_hier_code('\t' + ruledef)
        else:
            name = ctx.name().getText()
            ruledef = ''
            if name == 'inode_load':
                ruledef = 'int32_t addr = Inode_StartAddr + (FILE_ID - 1)*INODE_SIZE;\n\t'+\
                          'struct Inode inode;\n\t' + 'fseek(fr,addr,SEEK_SET);\n\t' + \
                          'fread(&inode,sizeof(struct Inode),1,fr);\t\t'
            elif name == 'inode_write':
                ruledef = 'fseek(fw,addr,SEEK_SET);\n\t' + 'fwrite(&inode,sizeof(struct Inode),1,fw);\t\t'
            elif name == 'dir_inode_load':
                ruledef = 'int32_t dir_addr = Inode_StartAddr + (DIR_ID - 1)*INODE_SIZE;\n\t'+\
                          'struct Inode dir_inode;\n\t' + 'fseek(fr,dir_addr,SEEK_SET);\n\t' + \
                          'fread(&dir_inode,sizeof(struct Inode),1,fr);\t\t'
            elif name == 'dir_inode_write':
                ruledef = 'fseek(fw,dir_addr,SEEK_SET);\n\t' + 'fwrite(&dir_inode,sizeof(struct Inode),1,fw);\t\t'
            elif name == 'superblock_write':
                ruledef = 'fseek(fw, Superblock_StartAddr, SEEK_SET);\n\t' + \
                          'fwrite(superblock, sizeof(struct SuperBlock), 1, fw);\n\t' + 'fflush(fw);\t\t'
            elif name == 'transfer_to_message':
                ruledef = 'int32_t start_inode = File_Position / BLOCK_SIZE;\n\t' + \
                          'int32_t inode_num = start_inode;\n\t'+'int32_t offset = File_Position % BLOCK_SIZE;\n\t' +  \
                          'int32_t mess_offset = 0; \n\t'  +\
                          'while(OUT_LENGTH>0 && inode_num<9){\n\t\t' + 'int32_t count ;\n\t\t' + \
                          'if (inode_num == start_inode){\n\t\t\t' + \
                          'count = ((offset + OUT_LENGTH) <= BLOCK_SIZE)?OUT_LENGTH:(BLOCK_SIZE - offset);\n\t\t\t' +\
                          'memcpy(MESSAGE_ADDR +mess_offset,inode.dirBlock[inode_num] +offset, count); \n\t\t\t' + \
                          'mess_offset += count;\n\t\t\t'+ \
                          'OUT_LENGTH = OUT_LENGTH - count;\n\t\t\t' + 'inode_num +=1;\n\t\t}\n\t\t' + 'else{\n\t\t\t' + \
                          'count = (OUT_LENGTH <= BLOCK_SIZE)?OUT_LENGTH:BLOCK_SIZE;\n\t\t\t' + \
                          'memcpy(MESSAGE_ADDR +mess_offset,inode.dirBlock[inode_num], count) \n\t\t\t' + \
                          'mess_offset += count;\n\t\t\t' + 'OUT_LENGTH = OUT_LENGTH - count;\n\t\t\t' +\
                          'inode_num +=1;\n\t\t' + '}\n\t}'
            elif name == 'transfer_from_message':
                ruledef = 'int32_t start_inode = File_Position / BLOCK_SIZE;\n\t' + \
                          'int32_t inode_num = start_inode;\n\t' + 'int32_t offset = File_Position % BLOCK_SIZE;\n\t' + \
                          'int32_t mess_offset = 0; \n\t' + \
                          'while(LENGTH>0 && inode_num<9){\n\t\t' + 'int32_t count ;\n\t\t' + \
                          'if (inode_num == start_inode){\n\t\t\t' + \
                          'count = ((offset + LENGTH) <= BLOCK_SIZE)?LENGTH:(BLOCK_SIZE - offset);\n\t\t\t' + \
                          'memcpy(inode.dirBlock[inode_num] +offset,MESSAGE_ADDR +mess_offset, count); \n\t\t\t' + \
                          'mess_offset += count;\n\t\t\t'+  \
                          'LENGTH = LENGTH - count;\n\t\t\t' + 'inode_num +=1;\n\t\t}\n\t\t' + 'else{\n\t\t\t' + \
                          'count = (LENGTH <= BLOCK_SIZE)?LENGTH:BLOCK_SIZE;\n\t\t\t' + \
                          'memcpy(inode.dirBlock[inode_num],MESSAGE_ADDR +mess_offset, count) \n\t\t\t' + \
                          'mess_offset += count;\n\t\t\t' + 'LENGTH = LENGTH - count;\n\t\t\t' +\
                          'inode_num +=1;\n\t\t' + '}\n\t}'
            # 由于在if中,所以方式不同
            elif name == 'dir_item_load':
                ruledef = 'int32_t dir_item_addr = Block_StartAddr + (DIRECTORY_ID - 1)*BLOCK_SIZE + (position)*64;\n\t\t'+\
                          'struct DirItem dir_item;\n\t\t' + 'fseek(fr,dir_item_addr,SEEK_SET);\n\t\t' + \
                          'fread(&dir_item,sizeof(struct DirItem),1,fr);\t\t'
                self.path.pop()
                return ruledef
            if self.flag == 'hier_c':
                abbreviation = ' C-RLDE'
                ruledef += self.ChierMark + self.get_level() + abbreviation
                if self.functionFlag:
                    self.hierCode.add_function_string('\t' + ruledef)
                else:
                    self.hierCode.add_static_function_string('\t' + ruledef)
                self.add_level()
            elif self.flag == 'c':
                if self.functionFlag:
                    self.machineC.add_function_string('\t' + ruledef)
                else:
                    self.machineC.add_static_function_string('\t' + ruledef)

        self.path.pop()
        return ruledef
