#!/usr/bin/env python
# -*- coding: utf-8 -*-

# @Time    : 2018/6/4 15:35
# @Author  : ethanw
# @Mail    ：ethan_w@aliyun.com
# @Describe: 提供保存MISRA-C序列的字符串缓冲区以及将字符串存入文件

import os

class MachineC(object):
    def __init__(self):
        '''
        初始化
        '''
        self.fileName = 'test'
        self.cFile = ''  # 保存c头文件的字符串缓冲区
        self.globalVar = ''   # 保存全局变量的字符串缓冲区
        self.globalVarEx = ''  # 保存extern全局变量的字符串缓冲区
        self.functionString = ''  # 保存定义的函数的字符串缓冲区
        self.statfunctionString = ''  # 保存定义的static函数字符串缓冲区
        self.globalStat = set()  # 记录全局变量，防止重复
        self.root = './gen/'
        self._add_cFile()
        # self._add_global_statement()

    def _add_cFile(self):
        '''
        include入合适的库
        :return:
        '''
        self.cFile += '#include \"arinc_fs.h\"\n'
        self.cFile += '#include \"libc.h\"\n'
        self.cFile += '#include \"types.h\"\n'
        self.cFile += '#include \"fs.h\"\n'
        self.cFile += '#include \"ls.h\"\n'
        self.cFile += '#include \"arinc_ls.h\"\n'


    def get_file_name(self):
        return self.fileName

    def set_file_name(self,filename):
        self.fileName = filename

    def add_cFile(self,cFile):
        '''
        缓冲区加入信息
        :param cFile:
        :return:
        '''
        self.cFile += cFile + '\n'

    def add_global_val(self,globalVar):
        '''
        全局变量缓冲区添加
        :param globalVar:
        :return:
        '''
        if globalVar not in self.globalStat:
            self.globalVar += globalVar + '\n'
            self.globalStat.add(globalVar)

    def add_global_var_ex(self,globalVarEx):
        '''
        extern全局变量添加
        :param globalVarEx:
        :return:
        '''
        if globalVarEx not in self.globalStat:
            self.globalVarEx += globalVarEx + '\n'
            self.globalStat.add(globalVarEx)

    def add_function_string(self,functionString):
        '''
        ARINC 653服务函数添加
        :param functionString:
        :return:
        '''
        self.functionString += functionString + '\n'

    def add_static_function_string(self,staticfunctionString):
        '''
        功能函数添加为静态函数
        :param staticfunctionString:
        :return:
        '''
        self.statfunctionString += staticfunctionString + '\n'

    def clear(self):
        '''
        清空
        :return:
        '''
        self.cFile = ''
        self.globalVar = ''
        self.globalVarEx = ''
        self.functionString = ''
        self.statfunctionString = ''

    def to_c_string(self):
        '''
        打印输出
        :return:
        '''
        print(self.cFile)
        print('\n')
        print(self.globalVar)
        print('\n')
        print(self.globalVarEx)
        print('\n')
        print(self.statfunctionString)
        print('\n')
        print(self.functionString)

    def add_global_statement(self,globalstat):
        '''
        添加全局变量，同时返回该点是被正确添加进了全局变量
        :param globalstat:
        :return:
        '''
        if globalstat in self.globalStat:
            return False
        else:
            self.globalStat.add(globalstat)
            return True

    def to_file_uncovered(self):
        '''
        输出为文件,但不覆盖
        :return:
        '''
        path = self.root + 'c/'
        if not os.path.exists(path):
            os.mkdir(path)
        target_path = path + self.fileName + '.c'
        if os.path.exists(target_path):
            print('{} already exist !'.format(target_path))
        else:
            with open(target_path,'w',encoding='utf-8') as f:
                f.write(self.cFile)
                f.write('\n')
                f.write(self.globalVar)
                f.write('\n')
                f.write(self.globalVarEx)
                f.write('\n')
                f.write(self.statfunctionString)
                f.write('\n')
                f.write(self.functionString)
            print('{} : success '.format(target_path))

    def to_file(self):
        '''
        输出为文件,若有相同名时覆盖
        :return:
        '''
        path = self.root + 'c/'
        if not os.path.exists(path):
            os.mkdir(path)
        target_path = path + self.fileName + '.c'
        with open(target_path,'w',encoding='utf-8') as f:
            f.write(self.cFile)
            f.write('\n')
            f.write(self.globalVar)
            f.write('\n')
            f.write(self.globalVarEx)
            f.write('\n')
            f.write(self.statfunctionString)
            f.write('\n')
            f.write(self.functionString)
        print('{} : success '.format(target_path))
