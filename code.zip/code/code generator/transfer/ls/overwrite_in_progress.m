function [ ] = overwrite_in_progress(MESSAGE_ADDR,LENGTH)
    global In_Progress_Log_Set;
    global CURRENT_MAX_NB_IN_PROGRESS_MESSAGES;
    
    tmp = In_Progress_Log_Set;
    In_Progress_Log_Set = cell(CURRENT_MAX_NB_IN_PROGRESS_MESSAGES,1);
    i = 1;
    while i < CURRENT_MAX_NB_IN_PROGRESS_MESSAGES
        In_Progress_Log_Set{i,1} = tmp{i+1,1};
        i = i+1;
    end
    
    
    MESSAGE = extractBefore(MESSAGE_ADDR,LENGTH+1);
    In_Progress_Log_Set{CURRENT_MAX_NB_IN_PROGRESS_MESSAGES,1} = MESSAGE;
    
    
    return;
end