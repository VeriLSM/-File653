function [ index ] = CapacityofLogbook()
    global LOGBOOK_NUMBER;
    global MAX_LOGBOOK_NUMBER;

    %APEX_INTEGER index;
    if LOGBOOK_NUMBER < MAX_LOGBOOK_NUMBER
        index = LOGBOOK_NUMBER + 1;
        LOGBOOK_NUMBER = LOGBOOK_NUMBER + 1;
    else
        index = 0;
    end
    return;

end
