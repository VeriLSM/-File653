function  [index] = Invalid_Logbook_Name_in_Configuration(LOGBOOK_NAME)
    
    %APEX_INTEGER index;
    index = 1;

    return;
end