function [ ] = write_in_progress(MESSAGE_ADDR,LENGTH)
    global In_Progress_Log_Set;
    global CURRENT_MAX_NB_IN_PROGRESS_MESSAGES;
    
    index = 1;
    while index <= CURRENT_MAX_NB_IN_PROGRESS_MESSAGES
        content = In_Progress_Log_Set{index,1};
        content_length = strlength(content);
        if content_length <=1
            break;
        end
        index = index + 1;
    end
    
    
    MESSAGE = extractBefore(MESSAGE_ADDR,LENGTH+1);
    In_Progress_Log_Set{index,1} = MESSAGE;
    
    
    return;
end