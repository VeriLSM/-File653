function  [index] = Invalid_Max_nb_in_Progress_Message(MAX_NB_IN_PROGRESS_MESSAGES)
    global MAX_NB_IN_PROGRESS_MESSAGES_LIMITED;
    %APEX_INTEGER index;
    index = 1;
    
    if MAX_NB_IN_PROGRESS_MESSAGES <=0 || MAX_NB_IN_PROGRESS_MESSAGES >MAX_NB_IN_PROGRESS_MESSAGES_LIMITED
        index = 0;
    end

    return;
end