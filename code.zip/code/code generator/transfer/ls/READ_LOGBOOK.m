function [LENGTH,WRITE_STATUS,RETURN_CODE] = READ_LOGBOOK(LOGBOOK_ID,LOGBOOK_ENTRY,MESSAGE_ADDR)
    global RETURN_CODE_TYPE;
    global CURRENT_LOGBOOK_ID;
    global WRITE_STATUS_TYPE;
    global In_Progress_Log_Set;
    global Logbook_Set;
    global CURRENT_IN_PROGRESS_MESSAGE_NUMBER;
    if LOGBOOK_ID ~= CURRENT_LOGBOOK_ID
        LENGTH = 0;
        WRITE_STATUS = WRITE_STATUS_TYPE.NOUSE;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end
    
    if LOGBOOK_ENTRY > CURRENT_IN_PROGRESS_MESSAGE_NUMBER
        LENGTH = 0;
        WRITE_STATUS = WRITE_STATUS_TYPE.NOUSE;
        RETURN_CODE = RETURN_CODE_TYPE.INVALID_PARAM;
        return;
    end

    %APEX_INTEGER index1,index2;
    In_Progress_Log_Set2 = [In_Progress_Log_Set{:,1}];
    Logbook_Set2 = [Logbook_Set{:,1}];
    [~,index1] = ismember(MESSAGE_ADDR,In_Progress_Log_Set2);
    [~,index2] = ismember(MESSAGE_ADDR,Logbook_Set2);
    if index1 ~= 0
        LENGTH = strlength(In_Progress_Log_Set{index1,1});
        WRITE_STATUS = WRITE_STATUS_TYPE.IN_PROGRESS;
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        return;
    end

    if index2 ~= 0
        LENGTH = strlength(Logbook_Set{index2,1});
        WRITE_STATUS = WRITE_STATUS_TYPE.COMPLETE;
        RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
        return;
    end

    LENGTH = 0;
    WRITE_STATUS = WRITE_STATUS_TYPE.ABORTED;
    RETURN_CODE = RETURN_CODE_TYPE.NO_ERROR;
    return;

end

