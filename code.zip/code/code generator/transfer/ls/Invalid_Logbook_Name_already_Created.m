function  [index] = Invalid_Logbook_Name_already_Created(LOGBOOK_NAME)
    global CURRENT_LOGBOOK_NAME;
    %APEX_INTEGER index;
    index = 1;
    if LOGBOOK_NAME == CURRENT_LOGBOOK_NAME
        index = 0;
    end

    return;
end