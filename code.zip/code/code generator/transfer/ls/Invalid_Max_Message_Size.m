function  [index] = Invalid_Max_Message_Size(MAX_MESSAGE_SIZE)
    global MAX_MESSAGE_SIZE_LIMITED;
    %APEX_INTEGER index;
    index = 1;
    
    if MAX_MESSAGE_SIZE <=0 || MAX_MESSAGE_SIZE >MAX_MESSAGE_SIZE_LIMITED
        index = 0;
    end

    return;
end