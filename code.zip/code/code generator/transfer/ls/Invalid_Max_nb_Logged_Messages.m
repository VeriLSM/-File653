function  [index] = Invalid_Max_nb_Logged_Messages(MAX_NB_LOGGED_MESSAGES)
    global MAX_NB_LOGGED_MESSAGES_LIMITED;
    %APEX_INTEGER index;
    index = 1;
    
    if MAX_NB_LOGGED_MESSAGES <=0 || MAX_NB_LOGGED_MESSAGES >MAX_NB_LOGGED_MESSAGES_LIMITED
        index = 0;
    end

    return;
end